plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.soul.crack"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.soul.crack"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "4.2.0"

        // BuildConfig fields
        buildConfigField("String", "BASE_URL", "\"https://soul-panel.onrender.com\"")
        buildConfigField("String", "HMAC_SECRET", "\"295af957aad5514dd9772cd30ebe75391fd90401939e653a0e3f2fe3a2f28065\"")
        buildConfigField("String", "E2E_KEY_V1", "\"QtF8YDVUD0qo9vZKcoFSSvRFBCu/8K3T/PIyhgv9II=\"")
        buildConfigField("Boolean", "DISABLE_TAMPER_CHECK", "true")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}