#!/bin/bash

echo "=== HMAC Authentication Test ==="
echo ""

KEY="88A8941D18334609BF39DC16B0469B8A"
DEVICE_ID="00000000000000000000000000000000"
HMAC_SECRET="f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1"

echo "1. Testing /api/keys/verify endpoint"
SIGNATURE=$(echo -n "${KEY}|${DEVICE_ID}" | openssl dgst -sha256 -hmac "$HMAC_SECRET" | awk '{print $2}')
echo "   Signature: $SIGNATURE"
echo ""

echo "2. Calling /api/keys/verify with HMAC"
curl -s "https://soul-ddos-domain.shop/api/keys/verify?key=${KEY}&device_id=${DEVICE_ID}" \
  -H "X-Request-Sig: ${SIGNATURE}" | jq .
echo ""

echo "3. Testing /api/slot/status endpoint"
SLOT_SIG=$(echo -n "SLOT_STATUS|${DEVICE_ID}" | openssl dgst -sha256 -hmac "$HMAC_SECRET" | awk '{print $2}')
echo "   Signature: $SLOT_SIG"
echo ""

echo "4. Calling /api/slot/status with HMAC"
curl -s "https://soul-ddos-domain.shop/api/slot/status" \
  -H "X-Request-Sig: $SLOT_SIG" | jq .
echo ""

echo "5. Testing /api/cooldown/status endpoint"
COOLDOWN_SIG=$(echo -n "${KEY}|${DEVICE_ID}" | openssl dgst -sha256 -hmac "$HMAC_SECRET" | awk '{print $2}')
echo "   Signature: $COOLDOWN_SIG"
echo ""

echo "6. Calling /api/cooldown/status with HMAC"
curl -s "https://soul-ddos-domain.shop/api/cooldown/status?key=${KEY}" \
  -H "X-Request-Sig: $COOLDOWN_SIG" | jq .
echo ""

echo "=== Test Complete ==="
