#!/bin/bash
export E2E_KEY_V1='BjVlAOb2E4/Cccspv83IkSYvIFey5pC9T/ADVcKqpcc='
export HMAC_SECRET='f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1'
echo 'Building with keys:'
echo 'E2E_KEY_V1='
echo 'HMAC_SECRET='
./gradlew assembleRelease --no-daemon
