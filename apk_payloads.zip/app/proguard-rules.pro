# ============================================================
# TrafficCapture — ProGuard / R8 rules (release v3)
# ============================================================

# Strip verbose/debug/info/warn logging in release.
# IMPORTANT: keep Log.e so license/network errors stay visible in logcat.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
}

# Strip System.out / System.err
-assumenosideeffects class java.io.PrintStream {
    public *** println(...);
    public *** print(...);
}

# Aggressive obfuscation — repackage everything we can rename
-repackageclasses 'a'
-allowaccessmodification

# Keep entry-points & long-lived components only
-keep class com.soul.crack.ui.MainActivity { *; }
-keep class com.soul.crack.service.VpnCaptureService { *; }
-keep class com.soul.crack.service.OverlayService { *; }
-keep class com.soul.crack.App { *; }

# Keep BuildConfig values (constants — used by SecurityManager memory check)
-keepclassmembers class com.soul.crack.BuildConfig { *; }

# Crash reporter obfuscation friendliness
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations

# Compose runtime
-keep class androidx.compose.runtime.** { *; }
-dontwarn androidx.compose.runtime.**

# Room Database
-keep class * extends androidx.room.RoomDatabase
-keepclasseswithmembers class * {
    @androidx.room.* <methods>;
}
-keep @androidx.room.Entity class * { *; }

# Retrofit interfaces
-keep interface * extends retrofit2.Call
-keep public interface * extends retrofit2.Call { *; }

# Serializable classes
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Tink / Security crypto
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Misc warnings
-dontwarn com.google.api.client.**
-keep class com.google.api.client.** { *; }

# ============================================================
# HMAC Utility Protection (v2.1.0)
# ============================================================
# Keep HMAC utility class for signature generation
-keep class com.soul.crack.utils.HmacUtil { *; }
-keepclassmembers class com.soul.crack.utils.HmacUtil { *; }

# Obfuscate but don't remove utility classes
-keepnames class com.soul.crack.utils.** { *; }
