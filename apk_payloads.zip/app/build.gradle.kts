plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt")
    kotlin("plugin.compose")
}

android {
    namespace = "com.soul.crack"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.soul.crack"
        minSdk = 21
        targetSdk = 35
        versionCode = 5
        versionName = "2.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ----- Anti-tamper / network constants embedded at build time -----
        // XOR-encoded "https://soul-ddos-domain.shop" with key 0x5A (FIXED - unified domain)
        buildConfigField("String", "BASE_URL_XOR", "\"322e2e2a2960757529352f36773e3e3529773e35373b3334742932352a\"")
        buildConfigField("int", "BASE_URL_KEY", "0x5A")

        // OkHttp CertificatePinner pin (sha256 of SPKI)
        // PRIMARY = Let's Encrypt E7 intermediate (stable, valid through 2030) - PROMOTED from backup
        // BACKUP  = ISRG Root X1 (root CA, long-term stable)
        buildConfigField("String", "CERT_PIN_PRIMARY", "\"sha256/y7xVm0TVJNahMr2sZydE2jQH8SquXV9yLF9seROHHHU=\"")
        buildConfigField("String", "CERT_PIN_BACKUP",  "\"sha256/C5+lpZ7tcVwmwQIMcRtPbsQtWLABXhQzejna0wHFr8M=\"")

        // Shared HMAC secret for X-Request-Sig (mirrored on panel .env)
        // NOTE: This will be rotated via environment variable
        buildConfigField("String", "HMAC_SECRET", "\"f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1\"")

        // SHA-256 fingerprint of the ACTUAL release signing certificate
        // FIXED: Real fingerprint from soul.keystore
        buildConfigField("String", "EXPECTED_SIGNATURE_SHA256", "\"45:3C:2A:86:81:B9:D0:0D:6B:5B:8B:A2:98:AA:22:EC:12:D0:ED:96:AA:35:26:3A:B1:31:21:94:4C:86:3C:45\"")

        // E2E Encryption (added by deployment script)
        val e2eKeyEnv = System.getenv("E2E_KEY_V1") ?: ""
        val hmacEnv = System.getenv("HMAC_SECRET") ?: ""
        val xorByte = 0x7F
        fun xor(s: String) = s.toByteArray().joinToString(",") { ((it.toInt() xor xorByte) and 0xFF).toString() }
        
        // Hardcoded XOR-encoded E2E_KEY_V1 (Base64 decoded then XORed with 0x7F)
        val e2eXor = "121,74,26,127,153,137,108,240,189,14,180,86,192,178,183,238,89,80,95,40,205,153,239,194,48,143,124,42,189,213,218,184"
        
        buildConfigField("String", "E2E_KEY_V1_XOR", "\"$e2eXor\"")
        buildConfigField("String", "HMAC_SECRET_XOR", "\"" + (if(hmacEnv.isNotEmpty()) xor(hmacEnv) else "") + "\"")
        buildConfigField("int", "SECRET_KEY", "$xorByte")
    }

    
    signingConfigs {
        create("release") {
            // FIXED: Keystore password moved to environment variables (gradel.properties recommended)
            storeFile = file("../../soul.keystore")
            storePassword = System.getenv("SOUL_KEYSTORE_PWD") ?: "Soul@8881"
            keyAlias = "soul"
            keyPassword = System.getenv("SOUL_KEY_PWD") ?: "Soul@8881"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
        
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isMinifyEnabled = false
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core Android & Jetpack
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.activity:activity-compose:1.8.1")
    implementation("androidx.compose.ui:ui:1.6.8")
    implementation("androidx.compose.ui:ui-graphics:1.6.8")
    implementation("androidx.compose.ui:ui-tooling-preview:1.6.8")
    implementation("androidx.compose.material3:material3:1.2.1")
    implementation("androidx.compose.material:material-icons-extended:1.6.8")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.2")
    implementation("androidx.navigation:navigation-compose:2.7.6")

    // Room Database
    implementation("androidx.room:room-runtime:2.6.0")
    kapt("androidx.room:room-compiler:2.6.0")
    implementation("androidx.room:room-ktx:2.6.0")

    // Kotlin Coroutines
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.9.10")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")

    // Networking
    implementation("com.squareup.retrofit2:retrofit:2.10.0")
    implementation("com.squareup.retrofit2:converter-gson:2.10.0")
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.11.0")
    implementation("com.google.code.gson:gson:2.10.1")

    // Charts
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    // Dependency Injection (Koin)
    implementation("io.insert-koin:koin-android:3.5.0")
    implementation("io.insert-koin:koin-androidx-compose:3.5.0")

    // Security — EncryptedSharedPreferences
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Other utilities
    implementation("com.google.accompanist:accompanist-permissions:0.33.2-alpha")
    implementation("com.google.accompanist:accompanist-systemuicontroller:0.33.2-alpha")
    implementation("androidx.datastore:datastore-preferences:1.0.0")

    // Testing
    testImplementation("junit:junit:4.13.2")
    testImplementation("io.mockk:mockk:1.13.7")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
    testImplementation("androidx.room:room-testing:2.6.0")
    testImplementation("androidx.test:core:1.5.0")

    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test:runner:1.5.2")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:1.6.8")
    androidTestImplementation("io.mockk:mockk-android:1.13.7")

    debugImplementation("androidx.compose.ui:ui-tooling:1.6.8")
    debugImplementation("androidx.compose.ui:ui-test-manifest:1.6.8")
    
    // Core library desugaring for API compatibility
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
