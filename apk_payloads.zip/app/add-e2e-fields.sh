#!/bin/bash
# Simple script to add E2E BuildConfig fields
cd /home/ubuntu/apk/app

# Check if already added
if grep -q "E2E_KEY_V1_XOR" build.gradle.kts; then
    echo "✓ E2E fields already present"
    exit 0
fi

# Insert right after EXPECTED_SIGNATURE line
sed -i "/EXPECTED_SIGNATURE_SHA256/a\\
\\
        // E2E Encryption (added by deployment script)\\
        val e2eKeyEnv = System.getenv(\"E2E_KEY_V1\") ?: \"\"\\
        val hmacEnv = System.getenv(\"HMAC_SECRET\") ?: \"\"\\
        val xorByte = 0x7F\\
        fun xor(s: String) = s.toByteArray().joinToString(\",\") { ((it.toInt() xor xorByte) and 0xFF).toString() }\\
        buildConfigField(\"String\", \"E2E_KEY_V1_XOR\", \"\\\\\"\" + (if(e2eKeyEnv.isNotEmpty()) xor(e2eKeyEnv) else \"\") + \"\\\\\"\")\\
        buildConfigField(\"String\", \"HMAC_SECRET_XOR\", \"\\\\\"\" + (if(hmacEnv.isNotEmpty()) xor(hmacEnv) else \"\") + \"\\\\\"\")\\
        buildConfigField(\"int\", \"SECRET_KEY\", \"\$xorByte\")" build.gradle.kts

echo "✓ Added E2E fields to build.gradle.kts"
