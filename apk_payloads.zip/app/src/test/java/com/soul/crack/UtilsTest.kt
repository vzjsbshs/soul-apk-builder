package com.soul.crack.utils

import com.soul.crack.data.models.PacketEntity
import org.junit.Test
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertTrue

/**
 * Unit tests for utility functions
 */
class UtilsTest {

    @Test
    fun testFormatBytes() {
        assertEquals("512 B", 512L.formatBytes())
        assertEquals("1 KB", 1024L.formatBytes())
        assertEquals("1 MB", (1024 * 1024).toLong().formatBytes())
    }

    @Test
    fun testFormattedDate() {
        val timestamp = System.currentTimeMillis()
        val formatted = timestamp.toFormattedDate()
        
        assertTrue(formatted.contains(":"))
    }

    @Test
    fun testTruncate() {
        val longString = "This is a very long string that should be truncated"
        val truncated = longString.truncate(20)
        
        assertEquals(23, truncated.length) // 20 + "..."
        assertTrue(truncated.endsWith("..."))
    }

    @Test
    fun testMaskSensitiveData() {
        val data = "password=secret123&token=abc"
        val masked = data.maskSensitiveData()
        
        assertTrue(masked.contains("***"))
        assertTrue(!masked.contains("secret123"))
    }

    @Test
    fun testPacketDisplayText() {
        val packet = PacketEntity(
            id = 1,
            timestamp = System.currentTimeMillis(),
            protocol = "HTTP",
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 80,
            hostname = "example.com"
        )

        val displayText = packet.getDisplayText()
        assertTrue(displayText.contains("HTTP"))
        assertTrue(displayText.contains("192.168.1.100"))
        assertTrue(displayText.contains("93.184.216.34"))
    }
}
