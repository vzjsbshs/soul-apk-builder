package com.soul.crack.service

import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertNotNull
import junit.framework.TestCase.assertTrue
import org.junit.Test

/**
 * Unit tests for PacketParser
 */
class PacketParserTest {

    private val parser = PacketParser()

    @Test
    fun testParseHttpPacket() {
        val httpRequest = "GET /api/data HTTP/1.1\r\nHost: example.com\r\nContent-Length: 0\r\n\r\n".toByteArray()
        
        val packet = parser.parsePacket(
            data = httpRequest,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 80,
            direction = "→"
        )

        assertNotNull(packet)
        assertEquals("HTTP", packet?.protocol)
        assertEquals("192.168.1.100", packet?.sourceIp)
        assertEquals(12345, packet?.sourcePort)
    }

    @Test
    fun testDetectHttpsProtocol() {
        // TLS handshake starts with 0x16
        val tlsHandshake = byteArrayOf(0x16, 0x03, 0x03, 0x00, 0x4A)
        
        val packet = parser.parsePacket(
            data = tlsHandshake,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 443,
            direction = "→"
        )

        assertNotNull(packet)
        assertEquals("HTTPS", packet?.protocol)
    }

    @Test
    fun testEmptyPacket() {
        val emptyData = byteArrayOf()
        
        val packet = parser.parsePacket(
            data = emptyData,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 80,
            direction = "→"
        )

        // Should handle gracefully
        assertTrue(packet == null || packet.payloadSize == 0L)
    }

    @Test
    fun testPayloadSizeCalculation() {
        val testData = "test payload data".toByteArray()
        
        val packet = parser.parsePacket(
            data = testData,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 80,
            direction = "→"
        )

        assertEquals(testData.size.toLong(), packet?.payloadSize)
    }

    @Test
    fun testDifferentPorts() {
        // Test HTTP port detection
        val data = "GET / HTTP/1.1\r\n\r\n".toByteArray()
        
        val packet80 = parser.parsePacket(
            data = data,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 80,
            direction = "→"
        )

        assertEquals("HTTP", packet80?.protocol)

        val packet443 = parser.parsePacket(
            data = data,
            timestamp = System.currentTimeMillis(),
            sourceIp = "192.168.1.100",
            sourcePort = 12345,
            destinationIp = "93.184.216.34",
            destinationPort = 443,
            direction = "→"
        )

        // This should be detected as HTTPS or OTHER due to port
        assertNotNull(packet443)
    }
}
