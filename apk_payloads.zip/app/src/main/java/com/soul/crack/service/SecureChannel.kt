package com.soul.crack.service

import android.util.Base64
import android.util.Log
import com.soul.crack.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object SecureChannel {
    private const val TAG = "SecureChannel"
    
    // ⬇️ FIXED: Use your panel URL directly
    private const val BASE_URL = "https://soul-panel.onrender.com"
    
    // ⬇️ FIXED: Use BuildConfig values directly (not XOR decoded)
    private val e2eKey: ByteArray by lazy { 
        try {
            BuildConfig.E2E_KEY_V1.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get E2E_KEY: ${e.message}")
            ByteArray(32)
        }
    }
    
    private val hmacSecret: ByteArray by lazy { 
        try {
            BuildConfig.HMAC_SECRET.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get HMAC_SECRET: ${e.message}")
            ByteArray(32)
        }
    }
    
    private val client = OkHttpClient.Builder().build()
    private val random = SecureRandom()
    
    private fun generateNonce(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }
    
    suspend fun call(path: String, method: String, key: String, deviceId: String?, params: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("path", path)
                put("method", method)
                put("key", key)
                deviceId?.let { put("device_id", it) }
                params?.let { put("params", it) }
                put("nonce", generateNonce())
            }
            
            val ts = System.currentTimeMillis() / 1000
            val kid = "v1"
            val iv = ByteArray(12).also { random.nextBytes(it) }
            val aad = "soulddv4|$ts|$kid".toByteArray()
            
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val keySpec = SecretKeySpec(e2eKey, "AES")
            val gcmSpec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec)
            cipher.updateAAD(aad)
            
            val plaintext = payload.toString().toByteArray()
            val ciphertext = cipher.doFinal(plaintext)
            
            val ctLen = ciphertext.size - 16
            val ct = ciphertext.copyOfRange(0, ctLen)
            val tag = ciphertext.copyOfRange(ctLen, ciphertext.size)
            
            val envelope = JSONObject().apply {
                put("v", 1)
                put("iv", iv.joinToString("") { "%02x".format(it) })
                put("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
                put("tag", tag.joinToString("") { "%02x".format(it) })
                put("ts", ts)
                put("kid", kid)
            }
            
            // Generate envelope signature
            val sigData = "${envelope.getString("iv")}${envelope.getString("ct")}${envelope.getString("tag")}$ts"
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(hmacSecret, "HmacSHA256"))
            val sig = mac.doFinal(sigData.toByteArray()).joinToString("") { "%02x".format(it) }
            
            // Generate dummy signature for testing
            val panelSig = "dummy_signature_for_testing"
            
            val body = envelope.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL/api/x")
                .post(body)
                .addHeader("X-Request-Sig", sig)
                .addHeader("X-Panel-Sig", panelSig)
                .addHeader("X-Key-Id", kid)
                .addHeader("User-Agent", "okhttp/4.11.0")
                .build()
            
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e(TAG, "HTTP error: ${response.code}")
                return@withContext JSONObject().apply { 
                    put("ok", false)
                    put("reason", "http_error") 
                }
            }
            
            val responseBody = response.body?.string() ?: ""
            val responseEnv = JSONObject(responseBody)
            
            // If server returned a plain rejection, surface it directly
            if (!responseEnv.has("iv")) {
                Log.e(TAG, "Server rejection: code=${response.code} body=$responseBody")
                return@withContext responseEnv
            }
            
            val respIv = responseEnv.getString("iv").chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            val respCt = Base64.decode(responseEnv.getString("ct"), Base64.NO_WRAP)
            val respTag = responseEnv.getString("tag").chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            val respTs = responseEnv.getLong("ts")
            val respKid = responseEnv.getString("kid")
            val respAad = "soulddv4|$respTs|$respKid".toByteArray()
            
            val respCipher = Cipher.getInstance("AES/GCM/NoPadding")
            val respKeySpec = SecretKeySpec(e2eKey, "AES")
            val respGcmSpec = GCMParameterSpec(128, respIv)
            respCipher.init(Cipher.DECRYPT_MODE, respKeySpec, respGcmSpec)
            respCipher.updateAAD(respAad)
            
            val respCombined = respCt + respTag
            val respPlaintext = respCipher.doFinal(respCombined)
            
            JSONObject(String(respPlaintext))
        } catch (e: Exception) {
            Log.e(TAG, "SecureChannel error", e)
            JSONObject().apply { 
                put("ok", false)
                put("reason", "encryption_error: ${e.message}") 
            }
        }
    }
}