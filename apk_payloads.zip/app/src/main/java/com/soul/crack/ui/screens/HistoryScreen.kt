package com.soul.crack.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.data.StrikeHistoryStore
import com.soul.crack.ui.shell.EclipseBackdrop
import com.soul.crack.ui.shell.EclipseBrandBar
import com.soul.crack.ui.shell.EclipseCard
import com.soul.crack.ui.shell.EclipseLabel
import com.soul.crack.ui.theme.*

@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    var refreshKey by remember { mutableStateOf(0) }
    val list = remember(refreshKey) { StrikeHistoryStore.all(ctx) }
    val stats = remember(refreshKey) { StrikeHistoryStore.stats(ctx) }
    val buckets = remember(refreshKey) { StrikeHistoryStore.last7DaysBuckets(ctx) }

    Box(Modifier.fillMaxSize()) {
        EclipseBackdrop(accent = EclipseTeal)

        Column(Modifier.fillMaxSize()) {
            EclipseBrandBar(
                title = "HISTORY", kana = "歴 史 · OFFLINE LOG",
                badge = "${stats.totalStrikes}",
                badgeColor = EclipseTeal
            )

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile("TOTAL", "${stats.totalStrikes}", EclipseTeal, Modifier.weight(1f))
                        StatTile("TODAY", "${stats.today}", EclipseCoral, Modifier.weight(1f))
                        StatTile("7-DAY", "${stats.last7}", EclipseViolet, Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile("KATANA", "${stats.mode1}", EclipseCoral, Modifier.weight(1f))
                        StatTile("DUAL", "${stats.mode2}", EclipseTeal, Modifier.weight(1f))
                        StatTile("SECONDS", "${stats.totalSeconds}", EclipseAmber, Modifier.weight(1f))
                    }
                }
                item { ChartCard(buckets) }
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        EclipseLabel("RECENT STRIKES · 軌 跡")
                        Text(
                            "CLEAR ALL",
                            color = EclipseCoral,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                            modifier = Modifier.clickable {
                                StrikeHistoryStore.clear(ctx); refreshKey++
                            }
                        )
                    }
                }
                if (list.isEmpty()) {
                    item { EmptyState() }
                } else {
                    items(list) { e -> HistoryRow(e) }
                }
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, color: Color, modifier: Modifier) {
    EclipseCard(modifier = modifier, accent = color, elevation = 10, cornerRadius = 14) {
        Column(Modifier.padding(14.dp)) {
            Text(
                value, color = color, fontSize = 22.sp,
                fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(2.dp))
            Text(
                label, color = EclipseTextMid, fontSize = 8.sp,
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
private fun ChartCard(buckets: IntArray) {
    val max = (buckets.maxOrNull() ?: 0).coerceAtLeast(1)
    EclipseCard(accent = EclipseViolet, elevation = 14, cornerRadius = 18) {
        Column(Modifier.padding(18.dp)) {
            EclipseLabel("LAST 7 DAYS · 七 日")
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(120.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val n = buckets.size
                    val gap = 10f
                    val barW = (w - gap * (n - 1)) / n
                    buckets.forEachIndexed { i, v ->
                        val frac = v.toFloat() / max
                        val barH = h * frac
                        val x = i * (barW + gap)
                        // bg track
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.04f),
                            topLeft = Offset(x, 0f),
                            size = Size(barW, h),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                        )
                        if (barH > 0) {
                            drawRoundRect(
                                brush = Brush.verticalGradient(listOf(EclipseTeal, EclipseViolet)),
                                topLeft = Offset(x, h - barH),
                                size = Size(barW, barH),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("-6d", "-5d", "-4d", "-3d", "-2d", "-1d", "TODAY").forEach {
                    Text(
                        it, color = EclipseTextLow, fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace, letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(e: StrikeHistoryStore.Entry) {
    val accent = if (e.mode == 1) EclipseCoral else EclipseTeal
    Box(
        Modifier.fillMaxWidth()
            .background(EclipseShell, RoundedCornerShape(12.dp))
            .border(1.dp, EclipseEdge, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(8.dp)
                            .background(accent, RoundedCornerShape(2.dp))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (e.mode == 1) "KATANA" else "DUAL",
                        color = accent, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 3.sp
                    )
                }
                Text(
                    "${e.ip}${if (e.port > 0) ":${e.port}" else ""}",
                    color = EclipseTextHigh, fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold
                )
                Text(
                    e.prettyTime(),
                    color = EclipseTextLow, fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace, letterSpacing = 1.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${e.duration}s",
                    color = EclipseTextHigh, fontSize = 18.sp,
                    fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
                )
                Text(
                    e.status, color = EclipseMint, fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("⚔", fontSize = 48.sp, color = EclipseTextLow)
        Text(
            "NO STRIKES YET",
            color = EclipseTextMid, fontSize = 12.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 4.sp
        )
        Text(
            "Your offline strike log will appear here",
            color = EclipseTextLow, fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
