package com.soul.crack.service

import android.content.Context
import android.os.Build
import android.util.Log

/**
 * ENHANCED LICENSE CHECKER FOR v4.0
 * - Multi-device support (auto-bind)
 * - Device limit checking
 * - Better offline grace period handling
 */
data class LicenseResultV4(
    val valid: Boolean,
    val reason: String? = null,
    val expiresAt: String? = null,
    val deviceLimit: Int? = null,
    val devicesUsed: Int? = null,
    val usedOfflineGrace: Boolean = false
)

object LicenseCheckerV4 {
    private const val TAG = "LicenseCheckerV4"
    private const val OFFLINE_GRACE_MS = 24L * 60 * 60 * 1000 // 24h

    suspend fun verifyLicense(context: Context, licenseKey: String): LicenseResultV4 {
        val deviceId = AuthManager.getDeviceId(context)
        val deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}"
        
        Log.d(TAG, "Verifying license: key=$licenseKey deviceId=$deviceId model=$deviceModel")
        
        val result = try {
            PanelApiV4.verifyKey(context, licenseKey, deviceId, deviceModel)
        } catch (e: Exception) {
            Log.e(TAG, "verify failed: ${e.message}", e)
            return offlineGrace(context, licenseKey, e.message)
        }
        
        Log.d(TAG, "verify response: code=${result.code} body=${result.body}")
        
        if (result.body == null) {
            return offlineGrace(context, licenseKey, "empty_body_http_${result.code}")
        }
        
        val valid = result.body.optBoolean("valid", false)
        val reason = result.body.optString("reason", "").takeIf { it.isNotEmpty() && it != "null" }
        val expiresAt = result.body.optString("expires_at", "").takeIf { it.isNotEmpty() && it != "null" }
        val deviceLimit = result.body.optInt("device_limit", 1)
        val devicesUsed = result.body.optInt("devices_used", 0)
        
        if (valid) {
            AuthManager.touchVerified(context, expiresAt)
            Log.i(TAG, "License valid: expires=$expiresAt devices=$devicesUsed/$deviceLimit")
            return LicenseResultV4(
                valid = true,
                expiresAt = expiresAt,
                deviceLimit = deviceLimit,
                devicesUsed = devicesUsed
            )
        }
        
        Log.w(TAG, "License invalid: reason=$reason")
        return LicenseResultV4(valid = false, reason = reason, expiresAt = expiresAt)
    }
    
    private fun offlineGrace(context: Context, licenseKey: String, detail: String? = null): LicenseResultV4 {
        val saved = AuthManager.getLicense(context)
        val lastVerify = AuthManager.getLastVerify(context)
        val expiresAt = AuthManager.getExpiresAt(context)
        val within = System.currentTimeMillis() - lastVerify < OFFLINE_GRACE_MS
        
        return if (saved == licenseKey && lastVerify > 0 && within) {
            Log.i(TAG, "Using offline grace period (last verified ${(System.currentTimeMillis() - lastVerify) / 1000 / 60} min ago)")
            LicenseResultV4(valid = true, expiresAt = expiresAt, usedOfflineGrace = true)
        } else {
            val reason = if (!detail.isNullOrBlank()) "net:$detail" else "network_error"
            Log.e(TAG, "Offline grace denied: $reason")
            LicenseResultV4(valid = false, reason = reason, expiresAt = expiresAt)
        }
    }
}
