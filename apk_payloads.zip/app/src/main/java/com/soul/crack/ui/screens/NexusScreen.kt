package com.soul.crack.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.ui.shell.EclipseBackdrop
import com.soul.crack.ui.shell.EclipseBrandBar
import com.soul.crack.ui.shell.EclipseCard
import com.soul.crack.ui.shell.EclipseLabel
import com.soul.crack.ui.theme.*

@Composable
fun NexusScreen() {
    Box(Modifier.fillMaxSize()) {
        EclipseBackdrop(accent = EclipseViolet)
        Column(Modifier.fillMaxSize()) {
            EclipseBrandBar(
                title = "SoulCrack",
                kana = "tg - @soulcrack",
                badge = "v1",
                badgeColor = EclipseViolet
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                NexusHero()
                EclipseCard(accent = EclipseTeal) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        EclipseLabel("CORE FEATURES · 機 能")
                        Feature("⚔", "Server-Authoritative Slots", "Single source of truth, no double fires")
                        Feature("⏱", "Dual Strike Modes", "Katana 1×120s · Dual 4×240s")
                        Feature("📦", "Offline Strike Log", "200 entries kept on-device")
                        Feature("📊", "7-Day Activity Chart", "Visualise your usage at a glance")
                        Feature("🔒", "Hardware-bound Licensing", "Cryptographic key per device")
                        Feature("🌌", "Floating Overlay Panel", "Run strikes from any app")
                    }
                }
                EclipseCard(accent = EclipseAmber) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        EclipseLabel("SAFETY · 警 告")
                        BulletText("Use only on networks/devices you own or have explicit permission to test.")
                        BulletText("Stop captures when not in use to preserve battery and data.")
                        BulletText("Keep your license key private — it is bound to this device.")
                    }
                }
                EclipseCard(accent = EclipseViolet) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        EclipseLabel("BUILD · 識 別")
                        InfoLine("APP", "SoulCrack")
                        InfoLine("VERSION", "1.0")
                        InfoLine("CHANNEL", "STABLE")
                        InfoLine("BUILD", "ECLIPSE-NOIR-X")
                    }
                }
                ContactCard()
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun NexusHero() {
    val inf = rememberInfiniteTransition(label = "nh")
    val rim by inf.animateFloat(
        0.6f, 1f,
        infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "rim"
    )
    Box(
        Modifier.fillMaxWidth()
            .shadow(40.dp, RoundedCornerShape(24.dp), ambientColor = EclipseViolet.copy(0.5f), spotColor = EclipseTeal.copy(0.4f))
            .background(
                Brush.linearGradient(
                    listOf(EclipseShell, EclipseRaise, EclipseViolet.copy(0.10f))
                ),
                RoundedCornerShape(24.dp)
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(EclipseViolet.copy(rim), EclipseTeal.copy(rim * 0.6f), Color.Transparent)),
                RoundedCornerShape(24.dp)
            )
            .padding(28.dp)
    ) {
        Column(horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "SoulCrack",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(EclipseCoral, EclipseRose, EclipseTeal, EclipseViolet)),
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp,
                    letterSpacing = 6.sp
                )
            )
            Text(
                "tg - @soulcrack",
                color = EclipseTextMid,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp, letterSpacing = 4.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "A precision tool forged for network-traffic study, capture and analysis. Crafted with offline-first reliability and hardware-bound licensing.",
                color = EclipseTextMid,
                fontFamily = FontFamily.SansSerif,
                fontSize = 13.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}

@Composable
private fun Feature(glyph: String, title: String, desc: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.size(36.dp)
                .background(EclipseTeal.copy(0.10f), RoundedCornerShape(10.dp))
                .border(1.dp, EclipseTeal.copy(0.4f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(glyph, fontSize = 16.sp, color = EclipseTeal)
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                title, color = EclipseTextHigh, fontSize = 13.sp,
                fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
            Text(
                desc, color = EclipseTextMid, fontSize = 11.sp,
                fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal
            )
        }
    }
}

@Composable
private fun BulletText(t: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text("›", color = EclipseAmber, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.width(8.dp))
        Text(t, color = EclipseTextMid, fontSize = 12.sp, fontFamily = FontFamily.SansSerif)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = EclipseTextLow, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        Text(value, color = EclipseTextHigh, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun ContactCard() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    EclipseCard(accent = NeonAqua) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            EclipseLabel("CONTACT & SUPPORT · 連 絡")
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Telegram", color = EclipseTextLow, fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
                    )
                    Text(
                        "@soulcrack", color = NeonAqua, fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                }
                Box(
                    Modifier
                        .background(NeonAqua.copy(0.10f), RoundedCornerShape(8.dp))
                        .border(1.dp, NeonAqua.copy(0.55f), RoundedCornerShape(8.dp))
                        .clickable {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/soulcrack"))
                                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                ctx.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        "OPEN", color = NeonAqua, fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 3.sp
                    )
                }
            }
        }
    }
}
