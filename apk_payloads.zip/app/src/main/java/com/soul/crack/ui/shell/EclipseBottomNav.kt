package com.soul.crack.ui.shell

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.ui.theme.*

/* NEON ONI BOTTOM NAV — chamfered floating dock, chromatic rim,
 * active tab lifts on a glowing pedestal with neon underline blade. */

enum class NavTab(val label: String, val kana: String, val accent: Color, val icon: ImageVector) {
    STRIKE ("STRIKE",  "斬",  PlasmaKatana, Icons.Filled.FlashOn),
    HISTORY("HISTORY", "歴",  NeonCyanA,    Icons.Outlined.History),
    VAULT  ("VAULT",   "金",  EnergyGold,   Icons.Outlined.Shield),
    NEXUS  ("NEXUS",   "核",  VoidPurple,   Icons.Outlined.Memory)
}

@Composable
fun EclipseBottomNav(selected: NavTab, onSelect: (NavTab) -> Unit) {
    val shape = CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp, topEnd = 4.dp, bottomStart = 4.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .shadow(
                32.dp, shape,
                ambientColor = selected.accent.copy(0.40f),
                spotColor = selected.accent.copy(0.55f)
            )
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0C0712),
                        EclipseShell,
                        Color(0xFF08050F)
                    )
                ),
                shape
            )
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(
                        EclipseCoral.copy(0.75f),
                        selected.accent.copy(0.85f),
                        EclipseViolet.copy(0.55f)
                    )
                ),
                shape
            )
    ) {
        // Top hairline highlight
        Box(
            Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(0.25f), selected.accent.copy(0.45f), Color.Transparent)
                    )
                )
        )
        // Bottom neon rail
        Box(
            Modifier.fillMaxWidth().height(2.dp).align(Alignment.BottomCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            EclipseCoral.copy(0.4f),
                            selected.accent.copy(0.9f),
                            EclipseViolet.copy(0.4f),
                            Color.Transparent
                        )
                    )
                )
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavTab.values().forEach { tab ->
                NavItem(
                    tab = tab,
                    selected = tab == selected,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(tab) }
                )
            }
        }
    }
}

@Composable
private fun NavItem(tab: NavTab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (selected) tab.accent else AnimeTxtSecondary.copy(0.75f),
        tween(240), label = "nc"
    )
    val pillH by animateDpAsState(if (selected) 62.dp else 52.dp, tween(260), label = "ph")
    val inf = rememberInfiniteTransition(label = "navp")
    val pulse by inf.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pu"
    )

    val shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp, topEnd = 0.dp, bottomStart = 0.dp)
    Box(
        modifier
            .height(pillH)
            .padding(horizontal = 3.dp)
            .then(
                if (selected) Modifier.shadow(
                    20.dp, shape,
                    ambientColor = tab.accent.copy(0.6f),
                    spotColor = tab.accent.copy(0.7f)
                ) else Modifier
            )
            .background(
                if (selected) Brush.verticalGradient(
                    listOf(
                        tab.accent.copy(0.28f),
                        tab.accent.copy(0.08f),
                        Color.Transparent
                    )
                ) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
                shape
            )
            .border(
                if (selected) 1.2.dp else 0.8.dp,
                if (selected) Brush.linearGradient(
                    listOf(tab.accent.copy(0.95f), tab.accent.copy(0.25f), Color.Transparent)
                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)),
                shape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        // Active neon underblade
        if (selected) {
            Box(
                Modifier.fillMaxWidth(0.62f).height(2.5.dp).align(Alignment.BottomCenter)
                    .padding(bottom = 4.dp)
                    .shadow(10.dp, RoundedCornerShape(2.dp), ambientColor = tab.accent, spotColor = tab.accent)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, tab.accent, Color.Transparent)
                        ),
                        RoundedCornerShape(2.dp)
                    )
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Hex ring around icon when selected
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(32.dp)) {
                if (selected) {
                    Canvas(Modifier.fillMaxSize()) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val r = size.minDimension / 2.2f
                        drawCircle(
                            color = tab.accent.copy(alpha = 0.18f * pulse),
                            radius = r + 4f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = tab.accent.copy(alpha = 0.55f),
                            radius = r,
                            center = Offset(cx, cy),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f)
                        )
                    }
                }
                Icon(tab.icon, null, tint = tint, modifier = Modifier.size(if (selected) 20.dp else 18.dp))
            }
            Spacer(Modifier.height(2.dp))
            Text(
                tab.label,
                color = tint,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp,
                letterSpacing = 2.5.sp
            )
            if (selected) {
                Text(
                    tab.kana,
                    color = tint.copy(0.75f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
