package com.soul.crack.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.data.StrikeHistoryStore
import com.soul.crack.service.ApiSender
import com.soul.crack.service.AuthManager
import com.soul.crack.ui.shell.EclipseBackdrop
import com.soul.crack.ui.shell.EclipseBrandBar
import com.soul.crack.ui.shell.EclipseCard
import com.soul.crack.ui.shell.EclipseLabel
import com.soul.crack.ui.theme.*

private fun computeDaysLeft(expiresAt: String?): Int? {
    if (expiresAt.isNullOrBlank()) return null
    return runCatching {
        val s = expiresAt.take(19).replace("T", " ")
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")
        val exp = sdf.parse(s) ?: return@runCatching null
        ((exp.time - System.currentTimeMillis()) / 86_400_000L).toInt()
    }.getOrNull()
}

@Composable
fun VaultScreen(licenseExpiresAt: String?, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val key = remember { AuthManager.getLicense(ctx).orEmpty() }
    val masked = remember(key) {
        if (key.length <= 8) key else "${key.take(4)}····${key.takeLast(4)}"
    }
    var historyCount by remember { mutableStateOf(StrikeHistoryStore.all(ctx).size) }
    val daysLeft = remember(licenseExpiresAt) { computeDaysLeft(licenseExpiresAt) }
    val showExpiry = daysLeft != null && daysLeft < 3

    Box(Modifier.fillMaxSize()) {
        EclipseBackdrop(accent = EclipseAmber)
        Column(Modifier.fillMaxSize()) {
            EclipseBrandBar(
                title = "VAULT", kana = "蔵 · LICENSE & PREFS",
                badge = licenseStatus(licenseExpiresAt).first,
                badgeColor = licenseStatus(licenseExpiresAt).second
            )
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AnimatedVisibility(showExpiry, enter = fadeIn()) {
                    ExpiryWarningBanner(daysLeft ?: 0)
                }
                // License card
                EclipseCard(accent = EclipseAmber, elevation = 18) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        EclipseLabel("LICENSE KEY · 鍵")
                        Spacer(Modifier.height(10.dp))
                        Box(
                            Modifier.fillMaxWidth()
                                .background(EclipseRaise, RoundedCornerShape(10.dp))
                                .border(1.dp, EclipseEdge, RoundedCornerShape(10.dp))
                                .padding(14.dp)
                        ) {
                            Text(
                                masked.ifBlank { "—" },
                                color = EclipseAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp, letterSpacing = 4.sp
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "EXPIRES",
                            color = EclipseTextLow, fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
                        )
                        Text(
                            licenseExpiresAt ?: "OFFLINE GRACE",
                            color = EclipseTextHigh, fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace, letterSpacing = 1.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ActionPill("COPY KEY", EclipseTeal, Modifier.weight(1f)) {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                cm?.setPrimaryClip(ClipData.newPlainText("license", key))
                                Toast.makeText(ctx, "Key copied", Toast.LENGTH_SHORT).show()
                            }
                            ActionPill("LOGOUT", EclipseCoral, Modifier.weight(1f)) {
                                onLogout()
                            }
                        }
                    }
                }

                // Capture preferences
                EclipseCard(accent = EclipseTeal) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        EclipseLabel("CAPTURE PREFS · 設 定")
                        Spacer(Modifier.height(10.dp))
                        InfoRow("DEFAULT MODE", if (ApiSender.selectedOption.value == 1) "KATANA · I" else "DUAL · II")
                        InfoRow("DEFAULT TIME", "${ApiSender.getTime(ctx) ?: "—"}s")
                        InfoRow("MAX KATANA", "120s")
                        InfoRow("MAX DUAL", "240s")
                    }
                }

                // Local data
                EclipseCard(accent = EclipseViolet) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        EclipseLabel("OFFLINE DATA · 蔵 庫")
                        Spacer(Modifier.height(10.dp))
                        InfoRow("STRIKE LOG", "$historyCount entries")
                        InfoRow("STORAGE", "On-device only")
                        Spacer(Modifier.height(12.dp))
                        ActionPill("CLEAR HISTORY", EclipseCoral, Modifier.fillMaxWidth()) {
                            StrikeHistoryStore.clear(ctx)
                            historyCount = 0
                            Toast.makeText(ctx, "History cleared", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun ExpiryWarningBanner(daysLeft: Int) {
    val inf = rememberInfiniteTransition(label = "expw")
    val pulse by inf.animateFloat(
        0.4f, 1f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "p"
    )
    val text = when {
        daysLeft <= 0 -> "⚠ KEY EXPIRED — RENEW NOW"
        daysLeft == 1 -> "⚠ KEY EXPIRES IN 1 DAY"
        else -> "⚠ KEY EXPIRES IN $daysLeft DAYS"
    }
    Box(
        Modifier.fillMaxWidth()
            .background(EclipseAmber.copy(0.10f * pulse + 0.04f), RoundedCornerShape(12.dp))
            .border(1.dp, EclipseAmber.copy(pulse), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            text,
            color = EclipseAmber.copy(0.6f + pulse * 0.4f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label, color = EclipseTextLow, fontSize = 9.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium,
            letterSpacing = 2.sp
        )
        Text(
            value, color = EclipseTextHigh, fontSize = 12.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun ActionPill(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(46.dp)
            .background(
                Brush.verticalGradient(listOf(color.copy(0.18f), color.copy(0.04f))),
                RoundedCornerShape(12.dp)
            )
            .border(1.dp, color.copy(0.6f), RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = color, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.sp
        )
    }
}
