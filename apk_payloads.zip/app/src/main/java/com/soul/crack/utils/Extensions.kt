package com.soul.crack.utils

import com.soul.crack.data.models.PacketEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Extension functions for commonly used operations
 */

fun Long.toFormattedDate(): String {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return sdf.format(Date(this))
}

fun Long.toFormattedFullDate(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    return sdf.format(Date(this))
}

fun Long.formatBytes(): String {
    return when {
        this < 1024 -> "$this B"
        this < 1024 * 1024 -> "${this / 1024} KB"
        this < 1024 * 1024 * 1024 -> "${this / (1024 * 1024)} MB"
        else -> "${this / (1024 * 1024 * 1024)} GB"
    }
}

fun PacketEntity.getDisplayText(): String {
    val time = timestamp.toFormattedDate()
    return "$time | $protocol | $sourceIp:$sourcePort → $destinationIp:$destinationPort"
}

fun String.truncate(maxLength: Int = 50): String {
    return if (this.length > maxLength) {
        this.substring(0, maxLength) + "..."
    } else {
        this
    }
}

fun Map<String, String>.toJsonString(): String {
    return entries.joinToString(",\n") { (k, v) -> "\"$k\": \"$v\"" }
}

fun String.maskSensitiveData(): String {
    return this
        .replace(Regex("(password|token|authorization)\\s*=\\s*([^&,\\s]*)"), "$1=***")
        .replace(Regex("(\"password|\"token)\"\\s*:\\s*\"([^\"]*)\""), "$1\":\"***\"")
}
