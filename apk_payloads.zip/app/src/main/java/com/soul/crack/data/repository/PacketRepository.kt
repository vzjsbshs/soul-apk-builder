package com.soul.crack.data.repository

import com.soul.crack.data.db.PacketDao
import com.soul.crack.data.models.PacketEntity
import kotlinx.coroutines.flow.Flow

/**
 * Repository for managing packet data access
 */
class PacketRepository(private val packetDao: PacketDao) {

    fun getAllPackets(): Flow<List<PacketEntity>> = packetDao.getAll()

    fun getPacketsPaginated(limit: Int): Flow<List<PacketEntity>> = 
        packetDao.getAllPaginated(limit)

    fun getPacketsByProtocol(protocol: String): Flow<List<PacketEntity>> =
        packetDao.getByProtocol(protocol)

    fun getPacketsByHostname(hostname: String): Flow<List<PacketEntity>> =
        packetDao.getByHostname("%$hostname%")

    fun getPacketsByIp(ip: String): Flow<List<PacketEntity>> =
        packetDao.getByIp(ip)

    fun getPacketsByTimeRange(startTime: Long, endTime: Long): Flow<List<PacketEntity>> =
        packetDao.getByTimeRange(startTime, endTime)

    fun getFailedRequests(): Flow<List<PacketEntity>> =
        packetDao.getFailedRequests()

    fun getPacketCount(): Flow<Int> = packetDao.getCount()

    fun getPacketCountByProtocol(protocol: String): Flow<Int> =
        packetDao.getCountByProtocol(protocol)

    fun getTotalBytes(): Flow<Long?> = packetDao.getTotalBytes()

    fun getAverageLatency(): Flow<Long> = packetDao.getAverageLatency()

    suspend fun getPacketById(id: Long): PacketEntity? = packetDao.getById(id)

    suspend fun insertPacket(packet: PacketEntity): Long = packetDao.insert(packet)

    suspend fun insertPackets(packets: List<PacketEntity>) = packetDao.insertAll(packets)

    suspend fun updatePacket(packet: PacketEntity) = packetDao.update(packet)

    suspend fun deletePacket(packet: PacketEntity) = packetDao.delete(packet)

    suspend fun deletePacketById(id: Long) = packetDao.deleteById(id)

    suspend fun deleteOlderPackets(timestampThreshold: Long) = 
        packetDao.deleteOlderThan(timestampThreshold)

    suspend fun deleteAllPackets() = packetDao.deleteAll()

    fun searchPackets(query: String? = null, limit: Int = 1000): Flow<List<PacketEntity>> =
        packetDao.search(query, limit)
}

