package com.soul.crack.ui.theme
import androidx.compose.ui.graphics.Color

/* ====================================================================
 *  OBSIDIAN PULSE v10 — Feb 2026
 *  Pure void-black canvas, plasma cyan + plasma magenta accents,
 *  acid-lime success pulse, solar amber cooldown, hologram violet
 *  sigil. Tighter chromatic edges, deeper black, sharper neon.
 *  All prior aliases preserved for back-compat.
 * ==================================================================== */

// ── DEEP CARBON BACKGROUNDS (true black, obsidian-tinted) ───────────
val AnimeVoid       = Color(0xFF000000)   // pure void
val AnimeMidnight   = Color(0xFF030308)
val AnimeFog        = Color(0xFF06060F)
val AnimePanel      = Color(0xFF0A0A14)   // primary card
val AnimeElevated   = Color(0xFF12121F)   // raised / hover
val AnimeSurface    = Color(0xFF181828)   // input field
val AnimeHeat       = Color(0xFF180414)   // magenta-tinted deep
val AnimeWarm       = Color(0xFF1A1206)   // amber-tinted deep
val AnimeCool       = Color(0xFF001218)   // cyan-tinted deep
val AnimeSakura     = Color(0xFF18061A)

// ── PRIMARY ACCENTS (Plasma Cyan × Plasma Magenta × Hologram Violet)
val PlasmaKatana    = Color(0xFFFF1FB4)   // plasma magenta — primary STRIKE
val PlasmaCrimson   = Color(0xFFFF3D74)   // sharp danger / abort
val PlasmaGlowRed   = Color(0xFFFF85C4)

val SakuraPink      = Color(0xFFFF5AC8)
val SakuraDeep      = Color(0xFFD8208E)
val SakuraGlow      = Color(0xFFFF9DDA)

val NeonCyanA       = Color(0xFF00B4FF)   // plasma cyan — info, ready, license
val NeonCyanDim     = Color(0xFF0080B8)
val NeonCyanGlow    = Color(0xFF7CDCFF)

val EnergyGold      = Color(0xFFFFAA00)   // solar amber — cooldown, premium
val EnergyGoldDim   = Color(0xFFB57700)
val EnergyGoldGlow  = Color(0xFFFFD06A)

val VoidPurple      = Color(0xFFB400FF)   // hologram violet — sigil glow
val VoidPurpleDim   = Color(0xFF7600A8)
val VoidPurpleGlow  = Color(0xFFD97AFF)

val AnimeGreen      = Color(0xFFC7FF00)   // acid lime — success pulse
val AnimeRed        = Color(0xFFFF1FB4)
val AnimeAmber      = Color(0xFFFFAA00)

// ── GLASS + EDGES ───────────────────────────────────────────────────
val AnimeGlassLight   = Color(0x14FFFFFF)
val AnimeGlassMid     = Color(0x24FFFFFF)
val AnimeGlassBright  = Color(0x33FFFFFF)
val AnimeEdgeLine     = Color(0x2AFFFFFF)
val AnimeEdgeKatana   = Color(0x66FF1FB4)
val AnimeEdgeCyan     = Color(0x5900B4FF)
val AnimeEdgeSakura   = Color(0x55FF5AC8)
val AnimeEdgeBright   = Color(0x80FFFFFF)

// ── TEXT (pure white → muted slate) ─────────────────────────────────
val AnimeTxtPrimary   = Color(0xFFFFFFFF)
val AnimeTxtSecondary = Color(0xFF98A0BC)
val AnimeTxtDim       = Color(0xFF484C62)
val AnimeTxtKana      = Color(0xFF6A6F8A)
val AnimeTxtKatana    = Color(0xFFFF85C4)

// ── GLOW TOKENS ─────────────────────────────────────────────────────
val GlowKatana    = PlasmaKatana
val GlowSakura    = SakuraPink
val GlowCyanNeo   = NeonCyanA
val GlowGold      = EnergyGold
val GlowSigil     = VoidPurple
val GlowSuccess   = AnimeGreen
val GlowDanger    = AnimeRed

/* ====================================================================
 *  BACK-COMPAT ALIASES (DO NOT REMOVE — referenced across screens)
 * ==================================================================== */
val ForgeVoid     = AnimeVoid
val ForgeDeep     = AnimeMidnight
val ForgePanel    = AnimePanel
val ForgeRaised   = AnimeElevated
val ForgeSurface  = AnimeSurface
val ForgeHeat     = AnimeHeat
val ForgeWarm     = AnimeWarm
val ForgeCool     = AnimeCool

val PlasmaOrange  = PlasmaKatana
val PlasmaHot     = PlasmaCrimson
val PlasmaGlow    = SakuraPink

val IceBlue       = NeonCyanA
val IceDim        = NeonCyanDim
val IceGlow       = NeonCyanGlow

val ForgeGreen    = AnimeGreen
val ForgeRed      = AnimeRed
val ForgeAmber    = EnergyGold

val GlassLight    = AnimeGlassLight
val GlassMid      = AnimeGlassMid
val GlassBright   = AnimeGlassBright
val EdgeLine      = AnimeEdgeLine
val EdgeHot       = AnimeEdgeKatana
val EdgeIce       = AnimeEdgeCyan
val EdgeBright    = AnimeEdgeBright

val ForgeTxtPrimary   = AnimeTxtPrimary
val ForgeTxtSecondary = AnimeTxtSecondary
val ForgeTxtDim       = AnimeTxtDim
val ForgeTxtHeat      = SakuraPink

val GlowPlasma    = GlowKatana
val GlowIce       = GlowCyanNeo
val GlowGreen     = GlowSuccess
val GlowRed       = GlowDanger
val GlowAmber     = GlowGold

val BgDeep = AnimeVoid; val BgBase = AnimeMidnight; val BgCard = AnimePanel
val BgCardHover = AnimeElevated; val GlassWhite = AnimeGlassLight; val GlassBorder = AnimeEdgeLine
val AccentPrimary = NeonCyanA; val AccentSecondary = SakuraPink
val AccentGreen = AnimeGreen; val AccentRed = AnimeRed; val AccentAmber = EnergyGold
val AccentOrange = PlasmaKatana; val TextPrimary = AnimeTxtPrimary
val TextSecondary = AnimeTxtSecondary; val TextMuted = AnimeTxtDim
val GlowIndigo = VoidPurple; val GlowCyan = GlowCyanNeo
val NeonCyan = NeonCyanA; val NeonPurple = VoidPurple; val NeonPink = SakuraPink
val NeonMagenta = PlasmaKatana; val NeonGreen = AnimeGreen; val NeonYellow = EnergyGold
val NeonOrange = PlasmaKatana; val SpaceBlack = AnimeVoid; val DeepSpace = AnimeMidnight
val MidnightPurple = AnimeFog; val NebulaPurple = AnimePanel; val PrimaryDark = AnimePanel
val PrimaryDarker = AnimeMidnight; val GlassSurface = AnimeGlassLight
val GlassCyan = Color(0x2400B4FF); val GlassPurple = Color(0x24B400FF); val GlassPink = Color(0x24FF1FB4)
val AccentCyan = NeonCyanA; val SuccessGreen = AnimeGreen; val WarningOrange = EnergyGold
val ErrorPink = SakuraPink; val BackgroundDark = AnimeVoid
val ColorHttp = AnimeGreen; val ColorHttps = NeonCyanA; val ColorDns = EnergyGold
val ColorTcp = NeonCyanA; val ColorUdp = PlasmaKatana; val ColorOther = AnimeTxtSecondary

val VoidBlack = AnimeVoid; val VoidDeep = AnimeMidnight; val VoidPanel = AnimePanel
val VoidRaised = AnimeElevated; val VoidHot = AnimeHeat; val VoidWarm = AnimeWarm
val VoidCyan = NeonCyanA; val VoidRed = AnimeRed; val VoidAmber = EnergyGold
val VoidGreen = AnimeGreen; val VoidOrange = PlasmaKatana; val VoidWhite = AnimeTxtPrimary
val VoidTxtPrimary = AnimeTxtPrimary; val VoidTxtSecondary = AnimeTxtSecondary
val VoidTxtDim = AnimeTxtDim; val GlowTeal = GlowCyanNeo

fun colorForPort(port: Int): Color = when {
    port in 0..1023      -> AnimeRed
    port in 1024..9999   -> EnergyGold
    port in 10000..19999 -> NeonCyanA
    port in 20000..29999 -> AnimeGreen
    port in 30000..49999 -> PlasmaKatana
    else -> AnimeTxtPrimary
}

val PhantomVoid       = AnimeVoid
val PhantomPanel      = AnimePanel
val PhantomElevated   = AnimeElevated
val PhantomSurface    = AnimeSurface
val PhantomMidnight   = AnimeMidnight
val PhantomFog        = AnimeFog
val PhantomHeat       = AnimeHeat
val PhantomWarm       = AnimeWarm
val PhantomCool       = AnimeCool

val PhantomKatana     = PlasmaKatana
val PhantomCrimson    = PlasmaCrimson
val PhantomCyan       = NeonCyanA
val PhantomCyanDim    = NeonCyanDim
val PhantomGold       = EnergyGold
val PhantomGoldDim    = EnergyGoldDim
val PhantomSakura     = SakuraPink
val PhantomGreen      = AnimeGreen
val PhantomRed        = AnimeRed
val PhantomAmber      = EnergyGold

val PhantomTxtPrimary   = AnimeTxtPrimary
val PhantomTxtSecondary = AnimeTxtSecondary
val PhantomTxtDim       = AnimeTxtDim

val PhantomGlowKatana = GlowKatana
val PhantomGlowCyan   = GlowCyanNeo
val PhantomGlowGold   = GlowGold
val PhantomGlowRed    = GlowDanger

val PlainBg     = AnimeVoid
val PlainPanel  = AnimePanel
val PlainText   = AnimeTxtPrimary
val PlainAccent = NeonCyanA
val PlainHot    = PlasmaKatana

// ── ECLIPSE v9 TOKENS (public names used by shell & screens) ────────
val EclipseInk        = AnimeVoid
val EclipseShell      = AnimePanel
val EclipseRaise      = AnimeElevated
val EclipseTeal       = NeonCyanA
val EclipseCoral      = PlasmaKatana
val EclipseViolet     = VoidPurple
val EclipseAmber      = EnergyGold
val EclipseMint       = AnimeGreen
val EclipseRose       = SakuraPink
val EclipseTextHigh   = AnimeTxtPrimary
val EclipseTextMid    = AnimeTxtSecondary
val EclipseTextLow    = AnimeTxtDim
val EclipseEdge       = AnimeEdgeLine
val EclipseEdgeBright = AnimeEdgeBright
val EclipseOk         = AnimeGreen

val NeonAqua = NeonCyanA
