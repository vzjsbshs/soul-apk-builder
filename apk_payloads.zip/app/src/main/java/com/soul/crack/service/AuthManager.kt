package com.soul.crack.service

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/**
 * Stores license key, device id, and verification metadata.
 * Backed by EncryptedSharedPreferences (Jetpack Security).
 *
 * Login/register related fields are intentionally absent — the app no longer
 * uses username/password authentication.
 */
object AuthManager {
    private const val PREFS = "auth_prefs_enc"
    private const val KEY_LICENSE = "license_key"
    private const val KEY_DEVICE_ID = "device_id"
    private const val KEY_LAST_VERIFY = "last_verify_ts"
    private const val KEY_EXPIRES_AT = "expires_at"

    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val p = try {
                val mk = MasterKey.Builder(ctx.applicationContext)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                EncryptedSharedPreferences.create(
                    ctx.applicationContext,
                    PREFS,
                    mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (_: Throwable) {
                // Fallback to plain prefs if Tink/keystore isn't available (very old devices).
                ctx.applicationContext.getSharedPreferences(PREFS + "_fb", Context.MODE_PRIVATE)
            }
            cached = p
            return p
        }
    }

    fun clearAll(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }

    fun saveLicense(ctx: Context, key: String, expiresAt: String?) {
        prefs(ctx).edit()
            .putString(KEY_LICENSE, key)
            .putString(KEY_EXPIRES_AT, expiresAt)
            .putLong(KEY_LAST_VERIFY, System.currentTimeMillis())
            .apply()
    }

    fun clearLicense(ctx: Context) {
        prefs(ctx).edit().remove(KEY_LICENSE).remove(KEY_EXPIRES_AT).remove(KEY_LAST_VERIFY).apply()
    }

    fun getLicense(ctx: Context): String? = prefs(ctx).getString(KEY_LICENSE, null)
    fun getExpiresAt(ctx: Context): String? = prefs(ctx).getString(KEY_EXPIRES_AT, null)
    fun getLastVerify(ctx: Context): Long = prefs(ctx).getLong(KEY_LAST_VERIFY, 0L)

    fun touchVerified(ctx: Context, expiresAt: String?) {
        prefs(ctx).edit()
            .putLong(KEY_LAST_VERIFY, System.currentTimeMillis())
            .apply {
                if (expiresAt != null) putString(KEY_EXPIRES_AT, expiresAt)
            }
            .apply()
    }

    /** Stable device id: Settings.Secure.ANDROID_ID, else persisted UUID. */
    fun getDeviceId(ctx: Context): String {
        val p = prefs(ctx)
        p.getString(KEY_DEVICE_ID, null)?.let { return it }
        val androidId = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Throwable) { null }
        val id = if (!androidId.isNullOrBlank() && androidId != "9774d656d561d556") androidId
                 else UUID.randomUUID().toString()
        p.edit().putString(KEY_DEVICE_ID, id).apply()
        return id
    }
}
