package com.soul.crack.utils

/**
 * Centralised, declarative app configuration.
 *
 * All user-facing strings, labels, slot/timing limits and animation timings
 * live here so the entire app can be re-branded by editing a single file.
 */
object AppConfig {
    // Identity — SoulCrack · Eclipse Noir X
    const val APP_NAME       = "SoulCrack"
    const val APP_VERSION    = "v1"
    const val APP_FULL_NAME  = "SoulCrack"
    const val APP_TAGLINE    = "tg - @soulcrack"

    // Telegram
    const val TG_HANDLE      = "@soulcrack"
    const val TG_URL         = "https://t.me/soulcrack"

    // Options
    const val OPT1_LABEL     = "KATANA"
    const val OPT1_SLOTS     = 1
    const val OPT1_MAX_TIME  = 120
    const val OPT1_SUBTITLE  = "1 SLOT · 120s"

    const val OPT2_LABEL     = "DUAL"
    const val OPT2_SLOTS     = 4
    const val OPT2_MAX_TIME  = 240
    const val OPT2_SUBTITLE  = "4 SLOTS · 240s"

    // Stat / section labels
    const val LABEL_PACKETS       = "PACKETS"
    const val LABEL_DATA          = "DATA"
    const val LABEL_STATUS        = "STATUS"
    const val LABEL_SESSIONS      = "SESSIONS"
    const val LABEL_ALL_TIME      = "ALL-TIME"
    const val LABEL_LIVE_FEED     = "LIVE FEED"
    const val LABEL_API_OPTION    = "STRIKE CLASS"
    const val LABEL_ATTACK_SLOTS  = "SLOT STATUS"
    const val LABEL_COOLDOWN      = "REARM DELAY"
    const val LABEL_CHART         = "PACKETS / 10s"
    const val LABEL_LOGOUT        = "// exit"
    const val LABEL_SAVE          = "SET"
    const val LABEL_SAVED         = "✓ SET"

    // Buttons
    const val BTN_LAUNCH       = "EXECUTE"
    const val BTN_STOP         = "ABORT"
    const val BTN_SLOT_FULL    = "NO SLOTS"
    const val BTN_ACTIVATE     = "AUTHENTICATE"
    const val OVERLAY_TITLE    = "⚔ SoulCrack"

    // License screen
    const val LICENSE_FIELD_LABEL  = "ACCESS KEY"
    const val LICENSE_TAGLINE      = "// tg - @soulcrack"
    const val SECURITY_FAILED_TEXT = "⚠  INTEGRITY CHECK FAILED"

    // Filter protocols
    val PROTOCOLS = listOf("ALL", "HTTP", "HTTPS", "DNS", "TCP", "UDP")

    // Animations (ms)
    const val PULSE_MS       = 700
    const val SHIMMER_MS     = 3500
    const val CHART_ANIM_MS  = 300
    const val EMPTY_PULSE_MS = 900
}
