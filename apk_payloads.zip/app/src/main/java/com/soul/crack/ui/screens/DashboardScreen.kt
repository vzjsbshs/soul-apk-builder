package com.soul.crack.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.data.StrikeHistoryStore
import com.soul.crack.data.TargetPresetStore
import com.soul.crack.service.ApiSender
import com.soul.crack.ui.shell.EclipseBackdrop
import com.soul.crack.ui.shell.EclipseBrandBar
import com.soul.crack.ui.shell.EclipseCard
import com.soul.crack.ui.shell.EclipseLabel
import com.soul.crack.ui.theme.*
import com.soul.crack.viewmodel.DashboardViewModel

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    isOverlayOpen: Boolean = false,
    onOpenFloatingPanel: () -> Unit = {},
    onStartCapture: (String?) -> Unit = {},
    onStopCapture: () -> Unit = {},
    licenseExpiresAt: String? = null
) {
    val context = LocalContext.current
    val isCapturing     by viewModel.isCapturing.collectAsState()
    val slotBusy        by ApiSender.slotBusy.collectAsState()
    val isAttacking     by ApiSender.isAttacking.collectAsState()
    val attackRemaining by ApiSender.remainingSeconds.collectAsState()
    val cooldownSecs    by ApiSender.cooldownSeconds.collectAsState()
    val selectedOption  by ApiSender.selectedOption.collectAsState()
    val slotsTotal      by ApiSender.slotsTotal.collectAsState()
    val slotsBusy       by ApiSender.slotsBusy.collectAsState()
    val firedIp         by ApiSender.lastFiredIp.collectAsState()
    val firedPort       by ApiSender.lastFiredPort.collectAsState()
    val apiOk           by ApiSender.apiCallSuccess.collectAsState()

    var savedTime by remember { mutableStateOf(ApiSender.getTime(context)) }
    var timeInput by remember { mutableStateOf(savedTime ?: "") }
    var savedTick by remember { mutableStateOf(false) }

    // Persist successful strikes locally (offline)
    LaunchedEffect(apiOk) {
        if (apiOk) {
            val dur = (savedTime ?: timeInput).toIntOrNull() ?: 0
            StrikeHistoryStore.add(
                context,
                StrikeHistoryStore.Entry(
                    ts = System.currentTimeMillis(),
                    mode = selectedOption,
                    duration = dur,
                    ip = firedIp.ifBlank { "—" },
                    port = firedPort,
                    status = "ENGAGED"
                )
            )
        }
    }

    val accent = if (isAttacking || isCapturing) EclipseCoral else EclipseTeal

    Box(Modifier.fillMaxSize()) {
        EclipseBackdrop(accent = accent)

        Column(
            Modifier.fillMaxSize()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
        ) {
            EclipseBrandBar(
                title = "SOULCRACK",
                kana = "v10 · 黒 曜 · OBSIDIAN PULSE",
                badge = licenseStatus(licenseExpiresAt).first,
                badgeColor = licenseStatus(licenseExpiresAt).second
            )

            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    HeroPanel(
                        isAttacking = isAttacking,
                        attackRemaining = attackRemaining,
                        cooldownSecs = cooldownSecs,
                        slotsTotal = slotsTotal,
                        slotsBusy = slotsBusy
                    )
                }
                item {
                    TargetTelemetryCard(
                        ip = firedIp,
                        port = firedPort,
                        time = savedTime ?: timeInput,
                        active = isAttacking,
                        onSavePreset = {
                            if (firedIp.isNotBlank() && firedPort > 0) {
                                TargetPresetStore.save(
                                    context, "$firedIp:$firedPort", firedIp, firedPort
                                )
                            }
                        }
                    )
                }
                item {
                    PresetRail(
                        presets = remember(firedIp, firedPort) { TargetPresetStore.all(context) }
                    )
                }
                item {
                    StrikeModePanel(
                        selected = selectedOption,
                        enabled = !isCapturing && !isAttacking
                    ) { opt ->
                        ApiSender.setOption(context, opt)
                        val cap = ApiSender.maxTimeFor(opt)
                        val cur = (savedTime ?: timeInput).toIntOrNull()
                        if (cur != null && cur > cap) {
                            ApiSender.setTime(context, cap.toString())
                            savedTime = cap.toString(); timeInput = cap.toString()
                        }
                    }
                }
                item {
                    DurationCard(
                        timeInput = timeInput,
                        selectedOption = selectedOption,
                        savedTick = savedTick,
                        onChange = {
                            timeInput = it.filter { c -> c.isDigit() }.take(5)
                            savedTick = false
                        },
                        onSave = {
                            val t = timeInput.trim()
                            if (t.isNotEmpty()) {
                                val cap = ApiSender.maxTimeFor(selectedOption)
                                val n = t.toIntOrNull()?.coerceIn(1, cap) ?: cap
                                val s = n.toString()
                                ApiSender.setTime(context, s); savedTime = s; timeInput = s
                                savedTick = true
                            }
                        }
                    )
                }
                item {
                    AnimatedVisibility(
                        isAttacking && attackRemaining > 0,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        ActiveStrikeBanner(attackRemaining)
                    }
                }
                item {
                    AnimatedVisibility(
                        cooldownSecs > 0,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        CooldownCard(cooldownSecs)
                    }
                }
            }

            Box(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                EclipseExecuteButton(
                    isCapturing = isCapturing,
                    slotBusy = slotBusy,
                    cooldownSecs = cooldownSecs,
                    enabled = savedTime != null && !slotBusy && cooldownSecs == 0,
                    onStart = {
                        if (slotBusy || cooldownSecs > 0) return@EclipseExecuteButton
                        onStartCapture(null); onOpenFloatingPanel()
                    },
                    onStop = onStopCapture
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────
@Composable
private fun HeroPanel(
    isAttacking: Boolean,
    attackRemaining: Int,
    cooldownSecs: Int,
    slotsTotal: Int,
    slotsBusy: Int
) {
    val accent = when {
        isAttacking -> EclipseCoral
        cooldownSecs > 0 -> EclipseAmber
        else -> EclipseTeal
    }
    val statusLabel = when {
        isAttacking -> "ENGAGED"
        cooldownSecs > 0 -> "COOLING"
        else -> "READY"
    }
    val pulse = pulse(0.55f, 1f, 700)

    EclipseCard(accent = accent, elevation = 22, cornerRadius = 22) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(10.dp)
                            .shadow(8.dp, RoundedCornerShape(50.dp), ambientColor = accent, spotColor = accent)
                            .background(accent.copy(pulse), RoundedCornerShape(50.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    EclipseLabel("CORE STATUS · 状 態")
                }
                Text(
                    statusLabel,
                    color = accent,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp,
                    letterSpacing = 5.sp
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                BigStat(
                    value = if (isAttacking) "${attackRemaining}s"
                            else if (cooldownSecs > 0) "${cooldownSecs}s"
                            else "0s",
                    label = if (cooldownSecs > 0 && !isAttacking) "REARM" else "REMAIN",
                    color = accent,
                    modifier = Modifier.weight(1.4f)
                )
                BigStat(
                    value = "$slotsBusy/$slotsTotal",
                    label = "SLOTS",
                    color = EclipseViolet,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(14.dp))
            // Slot dots row
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(slotsTotal.coerceIn(1, 8)) { i ->
                    val active = i < slotsBusy
                    Box(
                        Modifier
                            .weight(1f)
                            .height(6.dp)
                            .background(
                                if (active) Brush.horizontalGradient(listOf(accent, accent.copy(0.5f)))
                                else Brush.horizontalGradient(listOf(EclipseEdge, EclipseEdge.copy(0.4f))),
                                RoundedCornerShape(3.dp)
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun BigStat(value: String, label: String, color: Color, modifier: Modifier) {
    Box(
        modifier
            .background(
                Brush.verticalGradient(listOf(color.copy(0.10f), Color.Transparent)),
                RoundedCornerShape(14.dp)
            )
            .border(1.dp, color.copy(0.30f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Column {
            Text(
                value,
                color = color,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 28.sp,
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(2.dp))
            Text(
                label,
                color = EclipseTextMid,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
                letterSpacing = 3.sp
            )
        }
    }
}

@Composable
private fun StrikeModePanel(selected: Int, enabled: Boolean, onSelect: (Int) -> Unit) {
    EclipseCard(accent = if (selected == 1) EclipseCoral else EclipseTeal) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EclipseLabel("STRIKE MODE · 流 派")
                EclipseLabel("CHOOSE WEAPON", color = EclipseTextLow)
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ModeTile(
                    glyph = "壱", title = "KATANA", spec1 = "1 SLOT", spec2 = "120s MAX",
                    desc = "Solo focused single-target precision",
                    accent = EclipseCoral,
                    selected = selected == 1, enabled = enabled,
                    modifier = Modifier.weight(1f)
                ) { onSelect(1) }
                ModeTile(
                    glyph = "弐", title = "DUAL", spec1 = "4 SLOTS", spec2 = "240s MAX",
                    desc = "Parallel multi-stream dispersion",
                    accent = EclipseTeal,
                    selected = selected == 2, enabled = enabled,
                    modifier = Modifier.weight(1f)
                ) { onSelect(2) }
            }
        }
    }
}

@Composable
private fun ModeTile(
    glyph: String, title: String, spec1: String, spec2: String, desc: String,
    accent: Color, selected: Boolean, enabled: Boolean,
    modifier: Modifier, onClick: () -> Unit
) {
    val anim by animateColorAsState(if (selected) accent else EclipseTextLow, label = "ma")
    Box(
        modifier
            .height(150.dp)
            .shadow(if (selected) 18.dp else 4.dp, RoundedCornerShape(14.dp), ambientColor = accent.copy(0.5f), spotColor = accent.copy(0.5f))
            .background(
                if (selected) Brush.linearGradient(
                    listOf(accent.copy(0.18f), EclipseRaise),
                    start = Offset(0f, 0f), end = Offset(0f, 400f)
                ) else Brush.linearGradient(listOf(EclipseShell, EclipseRaise.copy(0.7f))),
                RoundedCornerShape(14.dp)
            )
            .border(
                if (selected) 1.5.dp else 1.dp,
                if (selected) Brush.linearGradient(listOf(accent.copy(0.85f), accent.copy(0.25f)))
                else Brush.linearGradient(listOf(EclipseEdge, Color.Transparent)),
                RoundedCornerShape(14.dp)
            )
            .clickable(enabled = enabled) { onClick() }
            .padding(14.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    glyph, color = anim, fontSize = 30.sp,
                    fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
                )
                if (selected) {
                    val p = pulse(0.4f, 1f, 600)
                    Box(
                        Modifier.size(8.dp)
                            .background(accent.copy(p), RoundedCornerShape(50.dp))
                    )
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    title,
                    color = if (selected) EclipseTextHigh else EclipseTextMid,
                    fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp, letterSpacing = 3.sp
                )
                Text(
                    desc, color = EclipseTextLow,
                    fontFamily = FontFamily.Monospace, fontSize = 9.sp,
                    letterSpacing = 0.5.sp, fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SpecChip(spec1, anim)
                    SpecChip(spec2, anim.copy(0.6f))
                }
            }
        }
    }
}

@Composable
private fun SpecChip(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(0.10f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            text, color = color, fontSize = 8.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun DurationCard(
    timeInput: String, selectedOption: Int, savedTick: Boolean,
    onChange: (String) -> Unit, onSave: () -> Unit
) {
    val accent = if (savedTick) EclipseMint else EclipseTeal
    EclipseCard(accent = accent) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                EclipseLabel("DURATION · 時")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("MAX ", color = EclipseTextLow, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        "${ApiSender.maxTimeFor(selectedOption)}s",
                        color = EclipseTextMid, fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.weight(1f).height(58.dp)
                        .background(EclipseRaise, RoundedCornerShape(12.dp))
                        .border(
                            1.dp,
                            if (timeInput.isNotBlank()) accent.copy(0.6f) else EclipseEdge,
                            RoundedCornerShape(12.dp)
                        )
                ) {
                    OutlinedTextField(
                        value = timeInput, onValueChange = onChange,
                        placeholder = {
                            Text(
                                "${ApiSender.maxTimeFor(selectedOption)}",
                                color = EclipseTextLow, fontSize = 20.sp, fontFamily = FontFamily.Monospace
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp),
                        textStyle = TextStyle(
                            color = accent, fontFamily = FontFamily.Monospace,
                            fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            cursorColor = accent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    Modifier.size(width = 88.dp, height = 58.dp)
                        .shadow(16.dp, RoundedCornerShape(12.dp), ambientColor = accent.copy(0.4f), spotColor = accent.copy(0.6f))
                        .background(
                            Brush.verticalGradient(listOf(accent.copy(0.22f), accent.copy(0.08f))),
                            RoundedCornerShape(12.dp)
                        )
                        .border(1.dp, accent.copy(0.7f), RoundedCornerShape(12.dp))
                        .clickable { onSave() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (savedTick) "✓ SET" else "SET",
                        color = accent, fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
                    )
                }
            }
            // Quick presets
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf(30, 60, 120, ApiSender.maxTimeFor(selectedOption)).distinct().forEach { v ->
                    Box(
                        Modifier
                            .background(EclipseTeal.copy(0.06f), RoundedCornerShape(8.dp))
                            .border(1.dp, EclipseEdge, RoundedCornerShape(8.dp))
                            .clickable { onChange(v.toString()) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "${v}s", color = EclipseTextMid,
                            fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveStrikeBanner(remaining: Int) {
    val frac by animateFloatAsState(
        (remaining.coerceAtLeast(0) / 240f).coerceIn(0f, 1f),
        tween(900, easing = LinearEasing), label = "frac"
    )
    EclipseCard(accent = EclipseCoral, elevation = 26) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val a = pulse(0.5f, 1f, 480)
                    Box(
                        Modifier.size(10.dp)
                            .shadow(10.dp, RoundedCornerShape(50.dp), ambientColor = EclipseCoral, spotColor = EclipseCoral)
                            .background(EclipseCoral.copy(a), RoundedCornerShape(50.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "STRIKE ACTIVE · 攻 撃",
                        color = EclipseCoral, fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, letterSpacing = 4.sp
                    )
                }
                Text(
                    "${remaining}s",
                    color = EclipseCoral, fontSize = 30.sp,
                    fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
                )
            }
            Box(
                Modifier.fillMaxWidth().height(4.dp)
                    .background(EclipseEdge, RoundedCornerShape(2.dp))
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(frac)
                        .background(
                            Brush.horizontalGradient(listOf(EclipseCoral, EclipseRose)),
                            RoundedCornerShape(2.dp)
                        )
                )
            }
        }
    }
}

@Composable
private fun CooldownCard(secs: Int) {
    val frac by animateFloatAsState(
        (secs.coerceAtLeast(0) / 60f).coerceIn(0f, 1f),
        tween(300), label = "rp"
    )
    EclipseCard(accent = EclipseAmber) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    EclipseLabel("REARM DELAY · 鍛 錬")
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "FORGE COOLING", color = EclipseTextLow,
                        fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 2.sp
                    )
                }
                Text(
                    "${secs}s", color = EclipseAmber, fontSize = 38.sp,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold
                )
            }
            Box(
                Modifier.fillMaxWidth().height(4.dp)
                    .background(EclipseEdge, RoundedCornerShape(2.dp))
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(frac)
                        .background(
                            Brush.horizontalGradient(listOf(EclipseAmber, EclipseCoral)),
                            RoundedCornerShape(2.dp)
                        )
                )
            }
        }
    }
}

@Composable
private fun EclipseExecuteButton(
    isCapturing: Boolean, slotBusy: Boolean, cooldownSecs: Int,
    enabled: Boolean, onStart: () -> Unit, onStop: () -> Unit
) {
    val inCooldown = cooldownSecs > 0 && !slotBusy && !isCapturing
    val slotsFull = slotBusy && !isCapturing
    val breath = pulse(0.965f, 1.015f, 1800)
    val hotPulse = pulse(0.55f, 1f, 700)

    val (bg, accent, label) = when {
        slotsFull -> Triple(
            Brush.linearGradient(listOf(EclipseRaise, EclipseShell)),
            EclipseTextMid,
            "✗  NO SLOTS · 満 員"
        )
        inCooldown -> Triple(
            Brush.linearGradient(listOf(AnimeWarm, EclipseShell)),
            EclipseAmber,
            "⚒  REARM · ${cooldownSecs}s"
        )
        isCapturing -> Triple(
            Brush.linearGradient(listOf(AnimeHeat, EclipseCoral.copy(0.22f), EclipseShell)),
            EclipseCoral,
            "■  ABORT · 退"
        )
        else -> Triple(
            Brush.linearGradient(listOf(EclipseCoral.copy(0.28f), EclipseTeal.copy(0.18f), EclipseViolet.copy(0.18f), EclipseShell)),
            EclipseTeal,
            "⚔  EXECUTE STRIKE · 斬"
        )
    }

    val shape = androidx.compose.foundation.shape.CutCornerShape(
        topStart = 18.dp, bottomEnd = 18.dp, topEnd = 4.dp, bottomStart = 4.dp
    )

    Box(
        Modifier.fillMaxWidth().height(84.dp)
            .scale(if (enabled && !slotsFull && !isCapturing && !inCooldown) breath else 1f)
            .shadow(
                if (slotsFull) 4.dp else 40.dp,
                shape,
                ambientColor = accent.copy(0.7f),
                spotColor = accent.copy(0.7f)
            )
            .background(bg, shape)
            .border(
                if (isCapturing || enabled) 1.6.dp else 1.dp,
                Brush.linearGradient(
                    listOf(
                        EclipseCoral.copy(if (enabled || isCapturing) 0.9f else 0.3f),
                        accent.copy(0.95f),
                        EclipseViolet.copy(if (enabled || isCapturing) 0.75f else 0.25f)
                    )
                ),
                shape
            )
            .clickable(enabled = enabled || isCapturing) {
                if (isCapturing) onStop() else onStart()
            },
        contentAlignment = Alignment.Center
    ) {
        // Top hairline
        Box(
            Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(0.26f), accent.copy(0.45f), Color.Transparent)
                    )
                )
        )
        // Bottom blade rail
        Box(
            Modifier.fillMaxWidth().height(2.dp).align(Alignment.BottomCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, EclipseCoral.copy(0.55f), accent.copy(0.85f), EclipseViolet.copy(0.55f), Color.Transparent)
                    )
                )
        )
        // Pulse dot left
        if (enabled || isCapturing) {
            Box(
                Modifier.padding(start = 14.dp).size(8.dp).align(Alignment.CenterStart)
                    .shadow(10.dp, RoundedCornerShape(50.dp), ambientColor = accent, spotColor = accent)
                    .background(accent.copy(hotPulse), RoundedCornerShape(50.dp))
            )
            Box(
                Modifier.padding(end = 14.dp).size(8.dp).align(Alignment.CenterEnd)
                    .shadow(10.dp, RoundedCornerShape(50.dp), ambientColor = EclipseCoral, spotColor = EclipseCoral)
                    .background(EclipseCoral.copy(hotPulse), RoundedCornerShape(50.dp))
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when {
                isCapturing -> Icon(Icons.Default.Stop, null, tint = accent, modifier = Modifier.size(22.dp))
                !slotsFull && !inCooldown -> Icon(Icons.Default.PlayArrow, null, tint = accent, modifier = Modifier.size(26.dp))
            }
            Text(
                label,
                color = accent,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                letterSpacing = 5.sp
            )
        }
    }
}

@Composable
private fun pulse(min: Float, max: Float, durationMs: Int): Float {
    val t = rememberInfiniteTransition(label = "p$durationMs")
    return t.animateFloat(
        min, max,
        infiniteRepeatable(tween(durationMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pv"
    ).value
}

internal fun licenseStatus(expiresAt: String?): Pair<String, Color> {
    if (expiresAt.isNullOrBlank()) return "OFFLINE" to EclipseTextMid
    return try {
        val ms = java.time.Instant.parse(expiresAt).toEpochMilli()
        val d = ((ms - System.currentTimeMillis()) / 86400000L).toInt()
        when {
            d < 0 -> "EXPIRED" to EclipseCoral
            d <= 7 -> "${d}D LEFT" to EclipseAmber
            else -> "${d}D LEFT" to EclipseMint
        }
    } catch (_: Throwable) {
        "LIVE" to EclipseMint
    }
}

// ─────────────────────────────────────────────────────────────────────
//  v10 OBSIDIAN PULSE — TARGET TELEMETRY CARD
//  Shows live IP / PORT / TIME on the in-app screen (was on overlay).
// ─────────────────────────────────────────────────────────────────────
@Composable
private fun TargetTelemetryCard(
    ip: String,
    port: Int,
    time: String,
    active: Boolean,
    onSavePreset: () -> Unit
) {
    val accent = if (active) EclipseCoral else EclipseTeal
    EclipseCard(accent = accent) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EclipseLabel("TARGET TELEMETRY · 標 的")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val a = pulse(0.5f, 1f, 700)
                    Box(
                        Modifier.size(7.dp)
                            .background(accent.copy(a), RoundedCornerShape(50.dp))
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        if (active) "LIVE · 攻 撃" else "STANDBY · 待 機",
                        color = accent,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 9.sp,
                        letterSpacing = 3.sp
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryCell("IP", ip.ifBlank { "—" }, EclipseCoral, modifier = Modifier.weight(2f))
                TelemetryCell("PORT", if (port > 0) "$port" else "—", EclipseTeal, modifier = Modifier.weight(1f))
                TelemetryCell(
                    "TIME",
                    if (time.isNotBlank()) "${time}s" else "—",
                    EclipseAmber,
                    modifier = Modifier.weight(1f)
                )
            }
            // Save preset (offline)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                val canSave = ip.isNotBlank() && port > 0
                Box(
                    Modifier
                        .background(
                            if (canSave) EclipseMint.copy(0.10f) else EclipseEdge,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (canSave) EclipseMint.copy(0.50f) else EclipseEdge,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(enabled = canSave) { onSavePreset() }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        "+  SAVE PRESET",
                        color = if (canSave) EclipseMint else EclipseTextLow,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryCell(label: String, value: String, color: Color, modifier: Modifier) {
    Column(
        modifier
            .background(color.copy(0.08f), RoundedCornerShape(10.dp))
            .border(1.dp, color.copy(0.30f), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            label,
            color = EclipseTextLow,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 8.sp,
            letterSpacing = 3.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )
    }
}

// ─────────────────────────────────────────────────────────────────────
//  v10 OBSIDIAN PULSE — OFFLINE PRESET RAIL
//  Saved IP:Port pairs, horizontally scrollable, fully offline.
// ─────────────────────────────────────────────────────────────────────
@Composable
private fun PresetRail(presets: List<TargetPresetStore.Preset>) {
    if (presets.isEmpty()) return
    EclipseCard(accent = EclipseViolet) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                EclipseLabel("PRESETS · 蓄 え", color = EclipseViolet.copy(0.85f))
                Text(
                    "${presets.size} OFFLINE",
                    color = EclipseTextLow,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.sp
                )
            }
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(presets) { p ->
                    Box(
                        Modifier
                            .background(
                                Brush.verticalGradient(listOf(EclipseViolet.copy(0.14f), Color.Transparent)),
                                RoundedCornerShape(10.dp)
                            )
                            .border(1.dp, EclipseViolet.copy(0.40f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Column {
                            Text(
                                p.ip,
                                color = EclipseTextHigh,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                letterSpacing = 1.sp
                            )
                            Text(
                                ":${p.port}",
                                color = EclipseViolet,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
