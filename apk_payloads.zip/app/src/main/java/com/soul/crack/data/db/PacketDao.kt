package com.soul.crack.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.soul.crack.data.models.PacketEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for Packet entities
 */
@Dao
interface PacketDao {
    
    @Insert
    suspend fun insert(packet: PacketEntity): Long

    @Insert
    suspend fun insertAll(packets: List<PacketEntity>)

    @Update
    suspend fun update(packet: PacketEntity)

    @Delete
    suspend fun delete(packet: PacketEntity)

    @Query("SELECT * FROM packets WHERE id = :id")
    suspend fun getById(id: Long): PacketEntity?

    @Query("SELECT * FROM packets ORDER BY timestamp DESC LIMIT :limit")
    fun getAllPaginated(limit: Int): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets ORDER BY timestamp DESC")
    fun getAll(): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets WHERE protocol = :protocol ORDER BY timestamp DESC")
    fun getByProtocol(protocol: String): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets WHERE hostname LIKE :hostname ORDER BY timestamp DESC")
    fun getByHostname(hostname: String): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets WHERE sourceIp = :ip OR destinationIp = :ip ORDER BY timestamp DESC")
    fun getByIp(ip: String): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets WHERE timestamp BETWEEN :startTime AND :endTime ORDER BY timestamp DESC")
    fun getByTimeRange(startTime: Long, endTime: Long): Flow<List<PacketEntity>>

    @Query("SELECT * FROM packets WHERE statusCode >= 400 ORDER BY timestamp DESC")
    fun getFailedRequests(): Flow<List<PacketEntity>>

    @Query("SELECT COUNT(*) FROM packets")
    fun getCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM packets WHERE protocol = :protocol")
    fun getCountByProtocol(protocol: String): Flow<Int>

    @Query("SELECT SUM(payloadSize) FROM packets")
    fun getTotalBytes(): Flow<Long?>

    @Query("SELECT AVG(durationMs) FROM packets WHERE durationMs > 0")
    fun getAverageLatency(): Flow<Long>

    @Query("DELETE FROM packets WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM packets WHERE timestamp < :timestampThreshold")
    suspend fun deleteOlderThan(timestampThreshold: Long)

    @Query("DELETE FROM packets")
    suspend fun deleteAll()

    @Query("SELECT * FROM packets WHERE (:query IS NULL OR hostname LIKE :query OR sourceIp LIKE :query OR destinationIp LIKE :query) ORDER BY timestamp DESC LIMIT :limit")
    fun search(query: String?, limit: Int): Flow<List<PacketEntity>>
}

