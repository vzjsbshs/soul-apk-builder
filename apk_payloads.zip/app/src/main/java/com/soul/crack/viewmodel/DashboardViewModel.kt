package com.soul.crack.viewmodel

import android.content.Context
import android.os.Environment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.soul.crack.App
import com.soul.crack.data.models.CaptureStats
import com.soul.crack.data.models.PacketEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class DashboardViewModel : ViewModel() {
    private val repository = App.repository

    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _packetCount = MutableStateFlow(0)
    val packetCount: StateFlow<Int> = _packetCount.asStateFlow()

    private val _stats = MutableStateFlow(CaptureStats())
    val stats: StateFlow<CaptureStats> = _stats.asStateFlow()

    private val _totalBytes = MutableStateFlow(0L)
    val totalBytes: StateFlow<Long> = _totalBytes.asStateFlow()

    private val _recentPackets = MutableStateFlow<List<PacketEntity>>(emptyList())
    val recentPackets: StateFlow<List<PacketEntity>> = _recentPackets.asStateFlow()

    private val _protocolFilter = MutableStateFlow("ALL")
    val protocolFilter: StateFlow<String> = _protocolFilter.asStateFlow()

    /** Last 6 buckets of packets-per-10s window */
    private val _chart = MutableStateFlow(IntArray(6) { 0 })
    val chart: StateFlow<IntArray> = _chart.asStateFlow()

    private val _sessionsCount = MutableStateFlow(0)
    val sessionsCount: StateFlow<Int> = _sessionsCount.asStateFlow()

    private val _historyBytes = MutableStateFlow(0L)
    val historyBytes: StateFlow<Long> = _historyBytes.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(0)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private var timerJob: Job? = null
    private var chartJob: Job? = null
    private var lastBaseline = 0

    init {
        observeStats()
        observeRecent()
        startChartTicker()
    }

    fun startCapture() {
        _isCapturing.value = true
        _sessionsCount.value = _sessionsCount.value + 1
    }

    fun stopCapture() {
        _isCapturing.value = false
        timerJob?.cancel()
        _remainingSeconds.value = 0
    }

    fun setProtocolFilter(p: String) {
        _protocolFilter.value = p
    }

    fun startSessionTimer(seconds: Int, onElapsed: () -> Unit) {
        timerJob?.cancel()
        _remainingSeconds.value = seconds
        timerJob = viewModelScope.launch {
            while (_remainingSeconds.value > 0 && _isCapturing.value) {
                delay(1000)
                _remainingSeconds.value = _remainingSeconds.value - 1
            }
            if (_remainingSeconds.value == 0 && _isCapturing.value) onElapsed()
        }
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteAllPackets()
                _packetCount.value = 0
                _totalBytes.value = 0L
                _historyBytes.value = 0L
                _sessionsCount.value = 0
                _recentPackets.value = emptyList()
                _chart.value = IntArray(6) { 0 }
                lastBaseline = 0
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun exportCsv(context: Context, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = _recentPackets.value
                if (list.isEmpty()) {
                    onResult(false, "Nothing to export"); return@launch
                }
                val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloads.exists()) downloads.mkdirs()
                val f = File(downloads, "soul_dd_${System.currentTimeMillis()}.csv")
                val sb = StringBuilder()
                sb.appendLine("id,ts,protocol,src_ip,src_port,dst_ip,dst_port,host,method,path,status,size")
                list.forEach { p ->
                    sb.appendLine(
                        listOf(
                            p.id, p.timestamp, p.protocol, p.sourceIp, p.sourcePort,
                            p.destinationIp, p.destinationPort,
                            p.hostname.replace(",", " "), p.method,
                            p.path.replace(",", " "), p.statusCode, p.payloadSize
                        ).joinToString(",")
                    )
                }
                f.writeText(sb.toString())
                onResult(true, f.absolutePath)
            } catch (e: Exception) {
                onResult(false, e.message ?: "Export failed")
            }
        }
    }

    private fun observeStats() {
        viewModelScope.launch {
            try {
                repository.getPacketCount().collect { count ->
                    _packetCount.value = count ?: 0
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        viewModelScope.launch {
            try {
                repository.getTotalBytes().collect { bytes ->
                    val v = bytes ?: 0L
                    _totalBytes.value = v
                    if (v > _historyBytes.value) _historyBytes.value = v
                }
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private fun observeRecent() {
        viewModelScope.launch {
            try {
                repository.getPacketsPaginated(20).collect { list ->
                    _recentPackets.value = list
                }
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private fun startChartTicker() {
        chartJob = viewModelScope.launch {
            while (true) {
                delay(10_000)
                val current = _packetCount.value
                val delta = (current - lastBaseline).coerceAtLeast(0)
                lastBaseline = current
                val arr = _chart.value.copyOfRange(1, _chart.value.size) + delta
                _chart.value = arr
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        chartJob?.cancel()
    }
}
