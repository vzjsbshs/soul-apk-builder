package com.soul.crack.ui.shell

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.ui.theme.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

/* ====================================================================
 *  NEON ONI FORGE v9 — SHELL COMPONENTS
 *  Backdrop  : animated hex grid + chromatic bloom + particle drift
 *              + diagonal katana sweep + scanlines + corner brackets
 *  Card      : chamfered katana-cut shape, chromatic red×cyan border,
 *              top hairline highlight + bottom inner shadow
 *  BrandBar  : HUD header with dual glyph ticks + neon badge pill
 * ==================================================================== */

/* ── Chamfered "katana-cut" shape (top-left & bottom-right cut) ───── */
private fun katanaCut(cut: Float) = GenericShape { size, _ ->
    val c = cut
    moveTo(c, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width, size.height - c)
    lineTo(size.width - c, size.height)
    lineTo(0f, size.height)
    lineTo(0f, c)
    close()
}

@Composable
fun EclipseBackdrop(modifier: Modifier = Modifier, accent: Color = EclipseTeal) {
    val inf = rememberInfiniteTransition(label = "neon-oni-bd")
    val drift by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(7000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val sweep by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    val hexFade by inf.animateFloat(
        0.35f, 1f,
        infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "hex"
    )

    Box(modifier.fillMaxSize().background(EclipseInk)) {

        // Deep vertical wash — black → carbon → black
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xFF000000), Color(0xFF0A0612), Color(0xFF000000))
                )
            )
        )

        // Chromatic bloom — crimson top-right
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(EclipseCoral.copy(alpha = 0.16f + 0.06f * drift), Color.Transparent),
                    center = Offset(Float.POSITIVE_INFINITY, 0f),
                    radius = 1100f
                )
            )
        )
        // Hologram magenta bloom — bottom-left
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(EclipseViolet.copy(alpha = 0.14f + 0.05f * (1f - drift)), Color.Transparent),
                    center = Offset(0f, Float.POSITIVE_INFINITY),
                    radius = 900f
                )
            )
        )
        // Kami cyan spark — center
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(accent.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(0.5f * 1080f, 0.55f * 2400f),
                    radius = 620f
                )
            )
        )

        // Animated hex grid
        Canvas(Modifier.fillMaxSize()) {
            val r = 22.dp.toPx()
            val w = r * 1.732f
            val h = r * 1.5f
            val rows = (size.height / h).toInt() + 2
            val cols = (size.width / w).toInt() + 2
            val stroke = Stroke(width = 0.8f)
            for (row in -1..rows) {
                for (col in -1..cols) {
                    val cx = col * w + if (row % 2 == 0) 0f else w / 2f
                    val cy = row * h
                    val d = abs((cx / size.width) - 0.5f) + abs((cy / size.height) - 0.5f)
                    val alpha = (0.028f * (1f - d) + 0.004f) * hexFade
                    val path = Path().apply {
                        for (i in 0..5) {
                            val ang = PI / 3 * i + PI / 6
                            val px = cx + (r * 0.95f) * cos(ang).toFloat()
                            val py = cy + (r * 0.95f) * sin(ang).toFloat()
                            if (i == 0) moveTo(px, py) else lineTo(px, py)
                        }
                        close()
                    }
                    drawPath(path, Color.White.copy(alpha = alpha.coerceAtLeast(0f)), style = stroke)
                }
            }
        }

        // Diagonal katana sweep — thin neon beam that moves across
        Canvas(Modifier.fillMaxSize()) {
            val x = size.width * (sweep * 1.6f - 0.3f)
            val beam = Path().apply {
                moveTo(x, 0f)
                lineTo(x + 140f, 0f)
                lineTo(x + 140f - 260f, size.height)
                lineTo(x - 260f, size.height)
                close()
            }
            drawPath(
                beam,
                Brush.linearGradient(
                    listOf(Color.Transparent, EclipseCoral.copy(0.10f), EclipseTeal.copy(0.10f), Color.Transparent),
                    start = Offset(x - 260f, 0f),
                    end = Offset(x + 140f, size.height)
                )
            )
        }

        // Scanlines — crisp horizontal
        Canvas(Modifier.fillMaxSize()) {
            val gap = 3.dp.toPx()
            var y = 0f
            while (y < size.height) {
                drawRect(
                    Color.White.copy(alpha = 0.014f),
                    Offset(0f, y),
                    Size(size.width, 1f)
                )
                y += gap
            }
        }

        // Particle dots
        Canvas(Modifier.fillMaxSize()) {
            val sp = 42.dp.toPx()
            var x = 0f
            var ix = 0
            while (x < size.width) {
                var y = 0f
                var iy = 0
                while (y < size.height) {
                    val jitter = ((ix * 37 + iy * 91) % 13) / 13f
                    val c = when ((ix + iy) % 5) {
                        0    -> EclipseCoral
                        1    -> EclipseTeal
                        2    -> EclipseViolet
                        3    -> EclipseAmber
                        else -> Color.White
                    }
                    drawCircle(
                        c.copy(alpha = 0.06f + 0.05f * jitter),
                        0.9f + jitter * 0.6f,
                        Offset(x + jitter * 6f, y + jitter * 6f)
                    )
                    y += sp
                    iy++
                }
                x += sp
                ix++
            }
        }

        // Corner HUD brackets
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val len = 22.dp.toPx()
            val t = 1.6f
            val col = EclipseCoral.copy(0.55f)
            val col2 = EclipseTeal.copy(0.55f)
            // top-left coral
            drawLine(col, Offset(0f, 0f), Offset(len, 0f), t)
            drawLine(col, Offset(0f, 0f), Offset(0f, len), t)
            // top-right cyan
            drawLine(col2, Offset(size.width - len, 0f), Offset(size.width, 0f), t)
            drawLine(col2, Offset(size.width, 0f), Offset(size.width, len), t)
            // bottom-left cyan
            drawLine(col2, Offset(0f, size.height - len), Offset(0f, size.height), t)
            drawLine(col2, Offset(0f, size.height), Offset(len, size.height), t)
            // bottom-right coral
            drawLine(col, Offset(size.width - len, size.height), Offset(size.width, size.height), t)
            drawLine(col, Offset(size.width, size.height - len), Offset(size.width, size.height), t)
        }
    }
}

/** Chamfered katana-cut glass card with chromatic red×cyan border. */
@Composable
fun EclipseCard(
    modifier: Modifier = Modifier,
    accent: Color = EclipseTeal,
    elevation: Int = 14,
    cornerRadius: Int = 18,
    content: @Composable () -> Unit
) {
    // cornerRadius is reinterpreted as the chamfer size for the katana cut
    val cut = cornerRadius.coerceAtLeast(10)
    val shape = CutCornerShape(topStart = cut.dp, bottomEnd = cut.dp, topEnd = 0.dp, bottomStart = 0.dp)
    Box(
        modifier
            .shadow(
                elevation.dp, shape,
                ambientColor = accent.copy(0.35f),
                spotColor = accent.copy(0.28f)
            )
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF0D0815),
                        EclipseShell,
                        EclipseRaise,
                        Color(0xFF0A0612)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(0f, 600f)
                ),
                shape
            )
            .border(
                1.4.dp,
                Brush.linearGradient(
                    listOf(
                        EclipseCoral.copy(0.85f),
                        accent.copy(0.95f),
                        EclipseViolet.copy(0.70f),
                        accent.copy(0.35f)
                    )
                ),
                shape
            )
            .clip(shape)
    ) {
        // Top hairline highlight
        Box(
            Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(0.18f), accent.copy(0.35f), Color.Transparent)
                    )
                )
        )
        // Faint accent stripe on the left edge
        Box(
            Modifier.fillMaxHeight().width(2.dp).align(Alignment.CenterStart)
                .background(
                    Brush.verticalGradient(
                        listOf(EclipseCoral.copy(0.50f), accent.copy(0.35f), EclipseViolet.copy(0.50f))
                    )
                )
        )
        content()
    }
}

/** Tiny uppercase metadata label. */
@Composable
fun EclipseLabel(text: String, color: Color = EclipseTextMid) {
    Text(
        text,
        color = color,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 3.sp
    )
}

/** HUD-style brand bar with chromatic glyph + neon badge. */
@Composable
fun EclipseBrandBar(
    title: String,
    kana: String,
    badge: String? = null,
    badgeColor: Color = EclipseTeal,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Dual glyph bar: coral on top, cyan on bottom
            Column(
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Box(
                    Modifier.size(width = 5.dp, height = 10.dp)
                        .shadow(10.dp, RoundedCornerShape(1.dp), ambientColor = EclipseCoral, spotColor = EclipseCoral)
                        .background(
                            Brush.verticalGradient(listOf(EclipseCoral, EclipseRose))
                        )
                )
                Box(
                    Modifier.size(width = 5.dp, height = 14.dp)
                        .shadow(10.dp, RoundedCornerShape(1.dp), ambientColor = EclipseTeal, spotColor = EclipseTeal)
                        .background(
                            Brush.verticalGradient(listOf(EclipseTeal, EclipseViolet))
                        )
                )
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    title,
                    color = EclipseTextHigh,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 5.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(4.dp)
                            .background(EclipseCoral, RoundedCornerShape(50.dp))
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        kana,
                        color = EclipseTextMid.copy(0.80f),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 9.sp,
                        letterSpacing = 4.sp
                    )
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    "tg · @soulcrack",
                    color = EclipseTeal.copy(0.85f),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 8.sp,
                    letterSpacing = 3.sp
                )
            }
        }
        if (badge != null) {
            Box(
                Modifier
                    .shadow(
                        14.dp,
                        CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp, topEnd = 0.dp, bottomStart = 0.dp),
                        ambientColor = badgeColor.copy(0.55f),
                        spotColor = badgeColor.copy(0.45f)
                    )
                    .background(
                        Brush.linearGradient(
                            listOf(badgeColor.copy(0.22f), badgeColor.copy(0.06f))
                        ),
                        CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp, topEnd = 0.dp, bottomStart = 0.dp)
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(badgeColor.copy(0.85f), badgeColor.copy(0.30f))
                        ),
                        CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp, topEnd = 0.dp, bottomStart = 0.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(5.dp)
                            .shadow(6.dp, RoundedCornerShape(50.dp), ambientColor = badgeColor, spotColor = badgeColor)
                            .background(badgeColor, RoundedCornerShape(50.dp))
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        badge, color = badgeColor, fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black,
                        letterSpacing = 3.sp
                    )
                }
            }
        }
    }
}
