package com.soul.crack.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.service.AuthManager
import com.soul.crack.service.LicenseCheckerV4
import com.soul.crack.ui.shell.EclipseBackdrop
import com.soul.crack.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LicenseScreen(onActivated: () -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var key by remember { mutableStateOf(AuthManager.getLicense(ctx) ?: "") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var statusOk by remember { mutableStateOf(false) }
    var infoOpen by remember { mutableStateOf(false) }
    var securityFailed by remember { mutableStateOf(false) }

    var failCount by rememberSaveable { mutableStateOf(0) }
    var cooldownEndsAt by rememberSaveable {
        mutableStateOf(
            ctx.getSharedPreferences("license_lockout", Context.MODE_PRIVATE)
                .getLong("cooldown_ends_at", 0L)
        )
    }
    var nowTick by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(cooldownEndsAt) {
        while (cooldownEndsAt > System.currentTimeMillis()) {
            nowTick = System.currentTimeMillis(); delay(500)
        }
        nowTick = System.currentTimeMillis()
    }
    val cooldownLeft = ((cooldownEndsAt - nowTick) / 1000).toInt().coerceAtLeast(0)
    val locked = cooldownLeft > 0

    val onAuthenticate: () -> Unit = {
        if (key.isBlank()) {
            status = "ENTER A LICENSE KEY"; statusOk = false
        } else {
            loading = true; status = null
            scope.launch {
                val r = LicenseCheckerV4.verifyLicense(ctx, key.trim())
                loading = false
                if (r.valid) {
                    AuthManager.saveLicense(ctx, key.trim(), r.expiresAt)
                    failCount = 0
                    // Clear any persisted lockout on a successful verify
                    ctx.getSharedPreferences("license_lockout", Context.MODE_PRIVATE)
                        .edit().remove("cooldown_ends_at").apply()
                    cooldownEndsAt = 0L
                    status = if (r.usedOfflineGrace) "OFFLINE — USING CACHED VERIFICATION" else "LICENSE ACTIVE"
                    statusOk = true
                    onActivated()
                } else {
                    if (r.reason == "bad_signature" || r.reason == "tamper") securityFailed = true
                    failCount += 1
                    if (failCount >= 5) {
                        val ends = System.currentTimeMillis() + 60_000L
                        cooldownEndsAt = ends
                        ctx.getSharedPreferences("license_lockout", Context.MODE_PRIVATE)
                            .edit().putLong("cooldown_ends_at", ends).apply()
                        failCount = 0
                    }
                    status = licenseReason(r.reason)
                    statusOk = false
                }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        EclipseBackdrop(accent = EclipseTeal)

        Column(
            Modifier.fillMaxSize()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            BootHeader()
            EclipseLogo()

            AnimatedVisibility(securityFailed, enter = slideInVertically { -it } + fadeIn()) {
                SecurityBanner()
            }

            KeyInputCard(
                key = key, loading = loading,
                onKeyChange = { key = it },
                onPaste = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val txt = cm?.primaryClip?.getItemAt(0)?.text?.toString().orEmpty().trim()
                    if (txt.isNotEmpty()) key = txt.uppercase()
                }
            )

            ActivateButton(
                key = key, loading = loading, locked = locked,
                cooldownLeft = cooldownLeft, onAuthenticate = onAuthenticate
            )

            AnimatedVisibility(
                status != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                StatusChip(status.orEmpty(), statusOk)
            }

            AnimatedVisibility(locked) { LockoutDisplay(cooldownLeft) }

            InfoAccordion(infoOpen) { infoOpen = !infoOpen }

            Text(
                "// logout",
                color = EclipseTextLow, fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 2.sp,
                modifier = Modifier.clickable { onLogout() }
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun BootHeader() {
    val inf = rememberInfiniteTransition(label = "bh")
    val cursorA by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "ca")
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            "// soulcrack  ·  tg - @soulcrack  ·  v1",
            color = EclipseTextLow, fontSize = 9.sp,
            fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
        )
        Row {
            Text(
                "// AWAITING SOUL KEY  魂",
                color = EclipseTextMid, fontSize = 9.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 2.sp
            )
            Text(
                "▌", color = EclipseTeal.copy(alpha = cursorA), fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun EclipseLogo() {
    val inf = rememberInfiniteTransition(label = "el")
    val rim by inf.animateFloat(0.5f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse), label = "r")
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.size(110.dp)
                .shadow(60.dp, RoundedCornerShape(50.dp), ambientColor = EclipseTeal.copy(rim * 0.7f), spotColor = EclipseCoral.copy(rim * 0.5f))
                .background(
                    Brush.radialGradient(listOf(EclipseRaise, EclipseShell)),
                    RoundedCornerShape(50.dp)
                )
                .border(
                    1.5.dp,
                    Brush.linearGradient(listOf(EclipseTeal.copy(rim), EclipseCoral.copy(rim * 0.7f), EclipseViolet.copy(rim * 0.5f))),
                    RoundedCornerShape(50.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "⚔", color = EclipseCoral, fontSize = 56.sp,
                fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
            )
        }
        Text(
            "SoulCrack",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(EclipseCoral, EclipseRose, EclipseTeal, EclipseViolet)),
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 26.sp,
                letterSpacing = 8.sp
            )
        )
        Text(
            "tg - @soulcrack",
            color = EclipseTextMid, fontSize = 10.sp,
            fontFamily = FontFamily.Monospace, letterSpacing = 5.sp
        )
    }
}

@Composable
private fun SecurityBanner() {
    Box(
        Modifier.fillMaxWidth()
            .background(EclipseCoral.copy(0.10f), RoundedCornerShape(12.dp))
            .border(1.dp, EclipseCoral.copy(0.55f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            "⚠  封 印 — INTEGRITY CHECK FAILED",
            color = EclipseCoral, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.sp
        )
    }
}

@Composable
private fun KeyInputCard(
    key: String, loading: Boolean,
    onKeyChange: (String) -> Unit, onPaste: () -> Unit
) {
    val accent = if (key.isNotBlank()) EclipseTeal else EclipseEdge
    Box(
        Modifier.fillMaxWidth()
            .shadow(20.dp, RoundedCornerShape(16.dp), ambientColor = accent.copy(0.3f), spotColor = accent.copy(0.2f))
            .background(EclipseShell, RoundedCornerShape(16.dp))
            .border(1.dp, accent, RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "ACCESS KEY · 魂",
                    color = EclipseTextMid, fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
                    letterSpacing = 4.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(EclipseTeal.copy(0.10f), RoundedCornerShape(6.dp))
                        .border(1.dp, EclipseTeal.copy(0.4f), RoundedCornerShape(6.dp))
                        .clickable { onPaste() }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Outlined.ContentPaste, null, tint = EclipseTeal, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(
                        "PASTE", color = EclipseTeal, fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                }
            }
            OutlinedTextField(
                value = key,
                onValueChange = { onKeyChange(it.uppercase().take(64)) },
                placeholder = {
                    Text(
                        "XXXX-XXXX-XXXX-XXXX",
                        color = EclipseTextLow, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                },
                singleLine = true,
                enabled = !loading,
                shape = RoundedCornerShape(10.dp),
                textStyle = TextStyle(
                    color = EclipseTeal,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp, letterSpacing = 2.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EclipseTeal,
                    unfocusedBorderColor = EclipseEdge,
                    cursorColor = EclipseTeal,
                    focusedContainerColor = EclipseRaise,
                    unfocusedContainerColor = EclipseRaise
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ActivateButton(
    key: String, loading: Boolean, locked: Boolean,
    cooldownLeft: Int, onAuthenticate: () -> Unit
) {
    var dots by remember { mutableStateOf(1) }
    LaunchedEffect(loading) {
        if (loading) while (true) {
            delay(400)
            dots = (dots % 3) + 1
        } else dots = 1
    }

    val canClick = !locked && !loading && key.isNotBlank()
    val accent = when {
        locked -> EclipseAmber
        !canClick -> EclipseTextLow
        else -> EclipseTeal
    }

    Box(
        Modifier.fillMaxWidth().height(64.dp)
            .shadow(if (canClick) 30.dp else 0.dp, RoundedCornerShape(16.dp), ambientColor = accent.copy(0.5f), spotColor = accent.copy(0.4f))
            .background(
                if (canClick) Brush.linearGradient(listOf(EclipseTeal.copy(0.18f), EclipseViolet.copy(0.12f), EclipseShell))
                else Brush.linearGradient(listOf(EclipseShell, EclipseRaise)),
                RoundedCornerShape(16.dp)
            )
            .border(
                1.5.dp,
                Brush.linearGradient(listOf(accent.copy(0.85f), accent.copy(0.25f))),
                RoundedCornerShape(16.dp)
            )
            .clickable(enabled = canClick) { onAuthenticate() },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (locked) Icon(Icons.Outlined.Lock, null, tint = accent, modifier = Modifier.size(16.dp))
            Text(
                when {
                    locked -> "封 印  ${cooldownLeft}s"
                    loading -> "VERIFYING ${"·".repeat(dots)}"
                    else -> "⚔  ACTIVATE FORGE"
                },
                color = accent,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp, letterSpacing = 5.sp
            )
        }
    }
}

@Composable
private fun StatusChip(message: String, ok: Boolean) {
    val color = if (ok) EclipseMint else EclipseCoral
    Box(
        Modifier.fillMaxWidth()
            .background(color.copy(0.10f), RoundedCornerShape(12.dp))
            .border(1.dp, color, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            "${if (ok) "✓" else "✗"}  $message",
            color = color, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp
        )
    }
}

@Composable
private fun LockoutDisplay(secs: Int) {
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            "ACCESS SUSPENDED · 封 印",
            color = EclipseTextMid, fontSize = 9.sp,
            fontFamily = FontFamily.Monospace, letterSpacing = 4.sp
        )
        Text(
            "$secs", color = EclipseAmber, fontSize = 56.sp,
            fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold
        )
        Text(
            "SECONDS REMAINING",
            color = EclipseTextLow, fontSize = 9.sp,
            fontFamily = FontFamily.Monospace, letterSpacing = 4.sp
        )
    }
}

@Composable
private fun InfoAccordion(open: Boolean, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(EclipseEdge))
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clickable { onToggle() },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "// SYSTEM INFO",
                color = EclipseTextMid, fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 3.sp
            )
            Icon(
                if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                null, tint = EclipseTextMid, modifier = Modifier.size(16.dp)
            )
        }
        AnimatedVisibility(open, enter = expandVertically(), exit = shrinkVertically()) {
            Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(
                    "› License is bound to this device fingerprint",
                    "› 5 failed attempts trigger a 60s lockout",
                    "› Strike history is stored locally — never uploaded",
                    "› Contact support if your key is not accepted"
                ).forEach {
                    Text(
                        it, color = EclipseTextMid, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace, letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

internal fun licenseReason(r: String?): String = when {
    r == null -> "VERIFICATION FAILED"
    r == "invalid_key" -> "INVALID LICENSE KEY"
    r == "expired" -> "LICENSE HAS EXPIRED"
    r == "revoked" -> "LICENSE HAS BEEN REVOKED"
    r == "wrong_device" -> "KEY IS BOUND TO ANOTHER DEVICE"
    r == "network_error" -> "NETWORK ERROR — TRY AGAIN"
    r == "missing_params" -> "REQUEST MISSING PARAMETERS"
    r == "bad_signature" -> "SIGNATURE REJECTED"
    r.startsWith("net:") -> "Network Error: ${r.substringAfter("net:")}"
    else -> r.uppercase()
}
