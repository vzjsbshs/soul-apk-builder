package com.soul.crack

import android.app.Application
import android.util.Log
import com.soul.crack.data.db.AppDatabase
import com.soul.crack.data.repository.PacketRepository
import com.soul.crack.service.ApiSender
import com.soul.crack.utils.Constants

/**
 * Application class for global setup and dependency initialization
 */
class App : Application() {

    companion object {
        lateinit var instance: App
            private set

        lateinit var database: AppDatabase
            private set

        lateinit var repository: PacketRepository
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize database
        database = AppDatabase.getInstance(this)
        repository = PacketRepository(database.packetDao())

        // Start server polling for slot/cooldown status
        ApiSender.startPolling(this)

        Log.d(Constants.TAG_UI, "App initialized - server polling active")
    }
}
