﻿package com.soul.crack.utils

/**
 * Constants used throughout the application
 */
object Constants {
    // VPN Configuration
    const val VPN_SERVICE_PACKAGE = "com.soul.crack"
    const val VPN_MTU = 1500
    const val VPN_ADDRESS = "10.0.0.1"
    const val VPN_ROUTE = "0.0.0.0/0"

    // Database
    const val DATABASE_NAME = "soul_dd.db"
    const val DATABASE_VERSION = 1

    // Packet Capture
    const val MAX_PACKETS_IN_MEMORY = 10000
    const val PACKET_BUFFER_SIZE = 8192
    const val PACKET_TIMEOUT_MS = 5000L
    const val MAX_PAYLOAD_SIZE = 10 * 1024 * 1024 // 10MB
    
    // UDP Port Range Filtering
    const val UDP_PORT_MIN = 10000
    const val UDP_PORT_MAX = 30000

    // UI
    const val REFRESH_RATE_MS = 100L
    const val MAX_PACKETS_PER_UPDATE = 100
    const val SCROLL_BUFFER = 50

    // Storage
    const val AUTO_PURGE_DAYS = 30
    const val AUTO_PURGE_SIZE_MB = 500
    const val CACHE_DIR = "soul_dd_captures"

    // Permissions
    const val VPN_PERMISSION_REQUEST_CODE = 100
    const val STORAGE_PERMISSION_REQUEST_CODE = 101
    const val NOTIFICATION_PERMISSION_REQUEST_CODE = 102

    // Protocols
    enum class Protocol {
        HTTP, HTTPS, DNS, TCP, UDP, UNKNOWN
    }

    // Log Tags
    const val TAG_VPN = "SoulVPN"
    const val TAG_PARSER = "SoulParser"
    const val TAG_DB = "SoulDB"
    const val TAG_EXPORT = "SoulExporter"
    const val TAG_UI = "SoulUI"

    // Ports
    const val HTTP_PORT = 80
    const val HTTPS_PORT = 443
    const val DNS_PORT = 53
    const val DOH_PORT = 443
    const val DOT_PORT = 853

    // Preferences
    const val PREF_LAST_CAPTURE_MODE = "last_capture_mode"
    const val PREF_AUTO_PURGE_ENABLED = "auto_purge_enabled"
    const val PREF_DARK_THEME = "dark_theme"
}

/**
 * Network protocol definitions
 */
object NetworkConstants {
    const val IP_HEADER_SIZE = 20
    const val TCP_HEADER_SIZE = 20
    const val UDP_HEADER_SIZE = 8
    const val TCP_PORT_HTTP = 80
    const val TCP_PORT_HTTPS = 443
    const val UDP_PORT_DNS = 53
}

/**
 * Regex patterns for parsing
 */
object RegexPatterns {
    val HTTP_REQUEST = Regex("^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\\s+(.+?)\\s+HTTP/")
    val HTTP_RESPONSE = Regex("^HTTP/\\d\\.\\d\\s+(\\d{3})")
    val HEADER_LINE = Regex("^([\\w-]+):\\s*(.*)$")
    val HOST_HEADER = Regex("Host:\\s*([\\w.:\\-]+)")
    val CONTENT_LENGTH = Regex("Content-Length:\\s*(\\d+)")
}



