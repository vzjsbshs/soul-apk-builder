package com.soul.crack.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.soul.crack.App
import com.soul.crack.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class VpnCaptureService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val isRunning = AtomicBoolean(false)
    private val parser = PacketParser()
    private val repository by lazy { App.repository }
    private var scope = CoroutineScope(Dispatchers.IO + Job())

    private var captureThread: Thread? = null
    private var inputStream: FileInputStream? = null
    private var outputStream: FileOutputStream? = null
    private val outLock = Any()

    // Active UDP relays keyed by "srcIp:srcPort->dstIp:dstPort"
    private val udpRelays = ConcurrentHashMap<String, UdpRelay>()

    companion object {
        var targetPackage: String? = null
        private val BLOCKED_CAPTURE_PORTS = setOf(53, 443, 80, 8700, 20000, 20001, 20002, 17500, 9031, 8080, 8081)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            Log.d(Constants.TAG_VPN, "STOP action received")
            performStop()
            return START_NOT_STICKY
        }
        targetPackage = intent?.getStringExtra("target_package")
        Log.d(Constants.TAG_VPN, "VPN Service started")
        startForegroundNotification()
        if (!isRunning.get()) {
            isRunning.set(true)
            scope = CoroutineScope(Dispatchers.IO + Job())
            captureThread = Thread { startVpnTunnel() }.apply {
                isDaemon = true
                start()
            }
        }
        return START_NOT_STICKY
    }

    private fun performStop() {
        isRunning.set(false)
        // close relays
        udpRelays.values.forEach { it.close() }
        udpRelays.clear()
        try { vpnInterface?.close(); vpnInterface = null } catch (_: Exception) {}
        captureThread?.interrupt()
        try { scope.cancel() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundNotification() {
        val channelId = "vpn_capture"
        val channel = NotificationChannel(channelId, "VPN Capture", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("DAEMONxDDOS v1 Capture Running")
            .setContentText("Capturing UDP ports 10000-30000")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notification)
    }

    private fun startVpnTunnel() {
        try {
            val builder = Builder()
            builder.setSession("TrafficCapture")
            builder.addAddress("10.0.0.2", 32)
            builder.addRoute("0.0.0.0", 0)
            builder.addDnsServer("8.8.8.8")
            builder.addDnsServer("8.8.4.4")
            builder.setMtu(1500)
            builder.setBlocking(false)
            // Prevent our own app traffic from looping through VPN
            try { builder.addDisallowedApplication(packageName) } catch (_: Exception) {}
            // If a target package is provided, only that app's traffic goes through
            // the VPN — all other apps keep normal internet untouched.
            val tp = targetPackage
            if (!tp.isNullOrBlank()) {
                try { builder.addAllowedApplication(tp) } catch (e: Exception) {
                    Log.e(Constants.TAG_VPN, "addAllowedApplication failed: ${e.message}")
                }
            }
            vpnInterface = builder.establish()
            if (vpnInterface != null) {
                Log.d(Constants.TAG_VPN, "VPN tunnel established successfully")
                readPackets()
            } else {
                // establish() returns null if VPN permission was not granted
                Log.e(Constants.TAG_VPN, "establish() returned null — VPN permission not granted or revoked")
                isRunning.set(false)
                stopSelf()
            }
        } catch (e: SecurityException) {
            Log.e(Constants.TAG_VPN, "SecurityException — VPN permission missing: ${e.message}", e)
            isRunning.set(false)
            stopSelf()
        } catch (e: Exception) {
            Log.e(Constants.TAG_VPN, "startVpnTunnel error: ${e.message}", e)
            isRunning.set(false)
        }
    }

    private fun readPackets() {
        try {
            val fd = vpnInterface!!.fileDescriptor
            inputStream = FileInputStream(fd)
            outputStream = FileOutputStream(fd)
            val buffer = ByteArray(32767)
            while (isRunning.get() && !Thread.currentThread().isInterrupted) {
                try {
                    val len = inputStream!!.read(buffer)
                    if (len <= 0) {
                        Thread.sleep(2)
                        continue
                    }
                    val copy = buffer.copyOf(len)
                    // Dispatch to relay - which also handles forwarding + capturing
                    scope.launch { if (isRunning.get()) handleIpPacket(copy, len) }
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                } catch (e: Exception) {
                    if (isRunning.get()) Log.e(Constants.TAG_VPN, "Read error: ${e.message}")
                    break
                }
            }
        } catch (e: Exception) {
            Log.e(Constants.TAG_VPN, "readPackets error: ${e.message}", e)
        } finally {
            cleanupStreams()
        }
    }

    private suspend fun handleIpPacket(data: ByteArray, length: Int) {
        try {
            if (length < 28) return
            val versionIhl = data[0].toInt() and 0xFF
            if ((versionIhl shr 4) != 4) return
            val ipHeaderLen = (versionIhl and 0xF) * 4
            val protocol = data[9].toInt() and 0xFF
            if (protocol != 17) return  // UDP only; TCP dropped
            if (length < ipHeaderLen + 8) return

            val srcIpBytes = data.copyOfRange(12, 16)
            val dstIpBytes = data.copyOfRange(16, 20)
            val srcIp = bytesToIp(srcIpBytes)
            val dstIp = bytesToIp(dstIpBytes)
            val srcPort = ((data[ipHeaderLen].toInt() and 0xFF) shl 8) or (data[ipHeaderLen + 1].toInt() and 0xFF)
            val dstPort = ((data[ipHeaderLen + 2].toInt() and 0xFF) shl 8) or (data[ipHeaderLen + 3].toInt() and 0xFF)
            val payloadStart = ipHeaderLen + 8
            val payload = if (payloadStart < length) data.copyOfRange(payloadStart, length) else ByteArray(0)

            // 1) Forward packet to real internet via protect()-ed socket
            val key = "$srcIp:$srcPort->$dstIp:$dstPort"
            val relay = udpRelays.getOrPut(key) {
                UdpRelay(srcIp, srcPort, srcIpBytes, dstIp, dstPort, dstIpBytes)
            }
            relay.touch()
            relay.sendOut(payload)

            // 2) Capture if in desired range AND not blocked
            val inRange = (srcPort in Constants.UDP_PORT_MIN..Constants.UDP_PORT_MAX) ||
                    (dstPort in Constants.UDP_PORT_MIN..Constants.UDP_PORT_MAX)
            if (!inRange) return
            if (srcPort in BLOCKED_CAPTURE_PORTS || dstPort in BLOCKED_CAPTURE_PORTS) return
            if (dstIp == "8.8.8.8" || dstIp == "8.8.4.4" || srcIp == "8.8.8.8" || srcIp == "8.8.4.4") return
            if (payload.isEmpty()) return

            val packet = parser.parsePacket(
                payload, System.currentTimeMillis(),
                srcIp, srcPort, dstIp, dstPort
            )
            if (packet != null) repository.insertPacket(packet)

            // Relay the captured bytes to the local api.
            ApiSender.sendPacket(applicationContext, dstIp, dstPort, payload)
        } catch (e: Exception) {
            Log.e(Constants.TAG_VPN, "handleIpPacket error: ${e.message}")
        }
    }

    /* ------------------------------------------------------------ */
    /* UDP Relay: forwards outbound UDP via a real protect()-ed socket
     * and injects replies back into the TUN fd as IP+UDP packets.    */
    private inner class UdpRelay(
        val srcIp: String, val srcPort: Int, val srcIpBytes: ByteArray,
        val dstIp: String, val dstPort: Int, val dstIpBytes: ByteArray
    ) {
        private val socket = DatagramSocket().also { protect(it) }
        @Volatile private var lastUsed = System.currentTimeMillis()
        private val dstAddr: InetAddress = try {
            InetAddress.getByAddress(dstIpBytes)
        } catch (_: Exception) {
            InetAddress.getByName(dstIp)
        }

        private val recvJob = scope.launch {
            val buf = ByteArray(32767)
            while (isRunning.get()) {
                try {
                    val pkt = DatagramPacket(buf, buf.size)
                    socket.receive(pkt)
                    lastUsed = System.currentTimeMillis()
                    val payload = pkt.data.copyOfRange(pkt.offset, pkt.offset + pkt.length)
                    val replyIp = buildIpv4UdpPacket(
                        srcIp = dstIpBytes, srcPort = dstPort,
                        dstIp = srcIpBytes, dstPort = srcPort,
                        payload = payload
                    )
                    synchronized(outLock) { outputStream?.write(replyIp) }
                } catch (e: Exception) {
                    if (!isRunning.get()) break
                    // socket closed or network error
                    break
                }
            }
        }

        fun touch() { lastUsed = System.currentTimeMillis() }

        fun sendOut(payload: ByteArray) {
            try {
                socket.send(DatagramPacket(payload, payload.size, dstAddr, dstPort))
            } catch (e: Exception) {
                Log.e(Constants.TAG_VPN, "relay send err: ${e.message}")
            }
        }

        fun close() {
            try { recvJob.cancel() } catch (_: Exception) {}
            try { socket.close() } catch (_: Exception) {}
        }
    }

    /* Build IPv4 + UDP packet with correct IP checksum.
     * UDP checksum is set to 0 (allowed for IPv4). */
    private fun buildIpv4UdpPacket(
        srcIp: ByteArray, srcPort: Int,
        dstIp: ByteArray, dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val total = 20 + 8 + payload.size
        val buf = ByteBuffer.allocate(total).order(ByteOrder.BIG_ENDIAN)
        // IPv4 header
        buf.put(((4 shl 4) or 5).toByte())   // ver/ihl
        buf.put(0)                            // DSCP/ECN
        buf.putShort(total.toShort())         // total length
        buf.putShort(0)                       // id
        buf.putShort(0x4000.toShort())        // flags=DF, frag=0
        buf.put(64)                           // TTL
        buf.put(17)                           // UDP
        buf.putShort(0)                       // checksum placeholder
        buf.put(srcIp)
        buf.put(dstIp)
        // UDP header
        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putShort((8 + payload.size).toShort())
        buf.putShort(0) // UDP checksum 0 (optional for IPv4)
        buf.put(payload)

        val out = buf.array()
        // IP checksum
        val sum = checksum16(out, 0, 20)
        out[10] = ((sum shr 8) and 0xFF).toByte()
        out[11] = (sum and 0xFF).toByte()
        return out
    }

    private fun checksum16(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            if (sum and 0xFFFF0000.toInt() != 0) {
                sum = (sum and 0xFFFF) + 1
            }
            i += 2
        }
        if (i < end) {
            sum += (data[i].toInt() and 0xFF) shl 8
            if (sum and 0xFFFF0000.toInt() != 0) {
                sum = (sum and 0xFFFF) + 1
            }
        }
        return sum.inv() and 0xFFFF
    }

    private fun bytesToIp(b: ByteArray): String =
        "${b[0].toInt() and 0xFF}.${b[1].toInt() and 0xFF}.${b[2].toInt() and 0xFF}.${b[3].toInt() and 0xFF}"

    private fun cleanupStreams() {
        try { inputStream?.close(); inputStream = null } catch (_: Exception) {}
        try { outputStream?.close(); outputStream = null } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(Constants.TAG_VPN, "VPN onDestroy called")
        performStop()
        Log.d(Constants.TAG_VPN, "VPN Service destroyed")
    }
}


