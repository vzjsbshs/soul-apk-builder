package com.soul.crack.service

import android.util.Log
import com.soul.crack.data.models.PacketEntity
import com.soul.crack.utils.Constants

class PacketParser {

    fun parsePacket(
        data: ByteArray,
        timestamp: Long,
        sourceIp: String,
        sourcePort: Int,
        destinationIp: String,
        destinationPort: Int,
        direction: String = "?"
    ): PacketEntity? {
        return try {
            if (data.isEmpty()) return null

            val isOutgoing = sourceIp.startsWith("10.0.") ||
                    sourceIp.startsWith("192.168.") ||
                    sourceIp.startsWith("172.")
            val directionLabel = if (isOutgoing) "SENT" else "RECEIVED"

            val hexPayload = data.joinToString(" ") { "%02X".format(it) }
            val hexDisplay = if (hexPayload.length > 100) hexPayload.take(100) + "..." else hexPayload

            val bodyDisplay = "\nHEX: $hexDisplay\nSize: ${data.size} bytes"

            PacketEntity(
                timestamp = timestamp,
                protocol = "UDP",
                sourceIp = sourceIp,
                sourcePort = sourcePort,
                destinationIp = destinationIp,
                destinationPort = destinationPort,
                hostname = destinationIp,
                payloadSize = data.size.toLong(),
                direction = directionLabel,
                requestBody = bodyDisplay
            )
        } catch (e: Exception) {
            Log.e(Constants.TAG_PARSER, "Error parsing packet", e)
            null
        }
    }
}
