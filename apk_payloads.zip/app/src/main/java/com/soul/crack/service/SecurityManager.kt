object SecurityManager {
    fun runStartupChecks(activity: Activity) {
        // Security checks disabled for testing
        Log.d("SOULCHECK", "Security checks disabled")
        return
    }
}