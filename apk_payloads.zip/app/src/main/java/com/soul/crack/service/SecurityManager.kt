package com.soul.crack.service

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.util.Log
import android.widget.Toast
import com.soul.crack.BuildConfig
import java.io.File
import java.security.MessageDigest

object SecurityManager {

    fun runStartupChecks(activity: Activity) {
        Log.e("SOULCHECK", "=== started DEBUG=${BuildConfig.DEBUG} ===")
        
        // FIXED: Downgraded rooted check to warning only (test-keys false positive removed)
        if (isRootedStrict()) {
            Toast.makeText(activity, "Warning: device appears to be rooted", Toast.LENGTH_LONG).show()
        }

        if (!BuildConfig.DEBUG) {
            val dbg = Debug.isDebuggerConnected() || Debug.waitingForDebugger()
            Log.e("SOULCHECK", "debugger=$dbg")
            if (dbg) { 
                Toast.makeText(activity, "Debugger detected — closing", Toast.LENGTH_LONG).show()
                activity.finishAffinity()
                return 
            }

            // FIXED: Tightened emulator detection to reduce false positives
            val emu = isEmulatorStrict()
            Log.e("SOULCHECK", "emulator=$emu fp=${Build.FINGERPRINT} model=${Build.MODEL} mfr=${Build.MANUFACTURER}")
            if (emu) { 
                Toast.makeText(activity, "Emulator not supported", Toast.LENGTH_LONG).show()
                activity.finishAffinity()
                return 
            }

            // FIXED: Better boundary-aware checks for Frida/Xposed
            val frida = isFridaPresentSafe()
            val xposed = isXposedPresentSafe()
            Log.e("SOULCHECK", "frida=$frida xposed=$xposed")
            if (frida || xposed) { 
                Toast.makeText(activity, "Hooking framework detected", Toast.LENGTH_LONG).show()
                activity.finishAffinity()
                return 
            }

            val memOk = memoryIntegrityOk()
            Log.e("SOULCHECK", "memOk=$memOk hmacLen=${BuildConfig.HMAC_SECRET.length}")
            if (!memOk) { 
                Toast.makeText(activity, "Integrity check failed", Toast.LENGTH_LONG).show()
                AuthManager.clearLicense(activity)
                activity.finishAffinity()
                return 
            }
        }

        // FIXED: Signature check now compares against the REAL fingerprint
        // No sentinel bypass needed - the build.gradle.kts now has the correct hash
        val expectedSig = BuildConfig.EXPECTED_SIGNATURE_SHA256
        val actual = getSignatureFingerprint(activity)
        Log.e("SOULCHECK", "expected=$expectedSig")
        Log.e("SOULCHECK", "actual=$actual")
        
        if (expectedSig.isNotEmpty()) {
            if (actual == null || !actual.equals(expectedSig, ignoreCase = true)) {
                Toast.makeText(activity, "Tampered APK detected", Toast.LENGTH_LONG).show()
                activity.finishAffinity()
            }
        }
    }

    private fun memoryIntegrityOk(): Boolean {
        if (BuildConfig.HMAC_SECRET.length != 64) return false
        return try { 
            val raw = hexToBytes(BuildConfig.BASE_URL_XOR)
            val url = xorDecode(raw, BuildConfig.BASE_URL_KEY.toByte())
            url.startsWith("https://")
        } catch (_: Throwable) { 
            false 
        }
    }

    private fun hexToBytes(s: String): ByteArray {
        val out = ByteArray(s.length / 2)
        for (i in out.indices) { 
            out[i] = ((Character.digit(s[i * 2], 16) shl 4) or Character.digit(s[i * 2 + 1], 16)).toByte() 
        }
        return out
    }

    // FIXED: Tightened emulator detection - removed "unknown" fingerprint check
    fun isEmulatorStrict(): Boolean = (
        Build.FINGERPRINT.startsWith("generic") || 
        Build.MODEL.contains("google_sdk") || 
        Build.MODEL.contains("Emulator") || 
        Build.MODEL.contains("Android SDK built for x86") || 
        Build.MANUFACTURER.contains("Genymotion") || 
        (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")) || 
        "google_sdk" == Build.PRODUCT
    )

    // FIXED: Boundary-aware Frida detection with safe fallback
    fun isFridaPresentSafe(): Boolean = try { 
        val maps = File("/proc/self/maps").readText()
        // Use word boundaries to avoid false positives
        maps.split('\n').any { line ->
            line.contains(Regex("\\bfrida\\b", RegexOption.IGNORE_CASE)) ||
            line.contains(Regex("\\bgum-js\\b", RegexOption.IGNORE_CASE)) ||
            line.contains(Regex("\\blinjector\\b", RegexOption.IGNORE_CASE))
        }
    } catch (_: Throwable) { 
        false 
    }

    // FIXED: Safe Xposed detection with null safety
    fun isXposedPresentSafe(): Boolean = try { 
        throw RuntimeException() 
    } catch (e: RuntimeException) { 
        try {
            e.stackTrace?.any { 
                it.className?.contains("xposed", ignoreCase = true) == true 
            } ?: false
        } catch (_: Throwable) {
            false
        }
    }

    // FIXED: Removed test-keys check - too many false positives on real OEM devices
    private fun isRootedStrict(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk", 
            "/sbin/su", 
            "/system/bin/su", 
            "/system/xbin/su", 
            "/data/local/xbin/su", 
            "/data/local/bin/su", 
            "/system/sd/xbin/su", 
            "/system/bin/failsafe/su", 
            "/data/local/su", 
            "/su/bin/su", 
            "/system/xbin/which"
        )
        for (p in paths) if (File(p).exists()) return true
        return try { 
            Runtime.getRuntime().exec(arrayOf("which", "su")).inputStream.bufferedReader().readLine() != null 
        } catch (_: Throwable) { 
            false 
        }
    }

    @Suppress("DEPRECATION")
    private fun getSignatureFingerprint(ctx: Context): String? = try {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) { 
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners 
        } else { 
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures 
        }
        val first = sigs?.firstOrNull() ?: return null
        val md = MessageDigest.getInstance("SHA-256")
        md.update(first.toByteArray())
        md.digest().joinToString(":") { "%02X".format(it) }
    } catch (_: Throwable) { 
        null 
    }

    fun xorDecode(encoded: ByteArray, key: Byte): String { 
        val out = ByteArray(encoded.size)
        for (i in encoded.indices) out[i] = (encoded[i].toInt() xor key.toInt()).toByte()
        return String(out, Charsets.UTF_8) 
    }

    fun hmacSha256Hex(secret: String, message: String): String { 
        val mac = javax.crypto.Mac.getInstance("HmacSHA256")
        mac.init(javax.crypto.spec.SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(message.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) } 
    }
}
