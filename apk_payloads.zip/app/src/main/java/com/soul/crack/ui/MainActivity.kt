package com.soul.crack.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.soul.crack.service.ApiSender
import com.soul.crack.service.AuthManager
import com.soul.crack.service.LicenseChecker
import com.soul.crack.service.LicenseCheckerV4
import com.soul.crack.service.OverlayService
import com.soul.crack.service.SecurityManager
import com.soul.crack.service.VpnCaptureService
import com.soul.crack.ui.screens.DashboardScreen
import com.soul.crack.ui.screens.HistoryScreen
import com.soul.crack.ui.screens.LicenseScreen
import com.soul.crack.ui.screens.NexusScreen
import com.soul.crack.ui.screens.VaultScreen
import com.soul.crack.ui.shell.EclipseBottomNav
import com.soul.crack.ui.shell.NavTab
import com.soul.crack.ui.theme.EclipseAmber
import com.soul.crack.ui.theme.EclipseCoral
import com.soul.crack.ui.theme.EclipseInk
import com.soul.crack.ui.theme.EclipseOk
import com.soul.crack.ui.theme.EclipseTeal
import com.soul.crack.ui.theme.EclipseTextMid
import com.soul.crack.ui.theme.TrafficCaptureTheme
import com.soul.crack.viewmodel.DashboardViewModel

private enum class Stage { LICENSE, VERIFYING, DASHBOARD }

class MainActivity : ComponentActivity() {
    // Lifecycle-safe ViewModel via the activity-ktx delegate
    private val dashboardVM: DashboardViewModel by viewModels()
    private val isOverlayOpenState = mutableStateOf(false)

    private val autoClearReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.soul.crack.AUTO_CLEAR_DATA") {
                dashboardVM.clearAllData()
            }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startVpnService()
        else Toast.makeText(this, "VPN permission denied", Toast.LENGTH_SHORT).show()
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        if (canDrawOverlays()) launchOverlayAndHome()
        else Toast.makeText(this, "Overlay permission required for floating window", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        SecurityManager.runStartupChecks(this)

        val filter = IntentFilter("com.soul.crack.AUTO_CLEAR_DATA")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(autoClearReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(autoClearReceiver, filter)
        }

        setContent {
            TrafficCaptureTheme {
                var stage by remember {
                    mutableStateOf(
                        when {
                            AuthManager.getLicense(this@MainActivity).isNullOrBlank() -> Stage.LICENSE
                            else -> Stage.VERIFYING
                        }
                    )
                }

                LaunchedEffect(Unit) {
                    if (stage == Stage.VERIFYING) {
                        val key = AuthManager.getLicense(this@MainActivity)!!
                        val r = LicenseCheckerV4.verifyLicense(this@MainActivity, key)
                        stage = if (r.valid) Stage.DASHBOARD
                        else {
                            if (r.reason == "wrong_device" || r.reason == "revoked" || r.reason == "invalid_key") {
                                AuthManager.clearLicense(this@MainActivity)
                                Toast.makeText(this@MainActivity, "License invalid: ${r.reason}", Toast.LENGTH_LONG).show()
                            }
                            Stage.LICENSE
                        }
                    }
                }

                var tab by rememberSaveable { mutableStateOf(NavTab.STRIKE) }

                // One-time-per-session welcome dialog
                var showWelcome by rememberSaveable { mutableStateOf(true) }

                // Live connection error banner (SSL / network)
                val connError by ApiSender.connectionError.collectAsState()

                Box(Modifier.fillMaxSize().systemBarsPadding().background(EclipseInk)) {
                    when (stage) {
                        Stage.LICENSE -> LicenseScreen(
                            onActivated = { stage = Stage.DASHBOARD },
                            onLogout = {
                                AuthManager.clearAll(this@MainActivity)
                                stage = Stage.LICENSE
                            }
                        )
                        Stage.VERIFYING -> Box(Modifier.fillMaxSize().background(Color.Black))
                        Stage.DASHBOARD -> Column(Modifier.fillMaxSize()) {
                            Box(Modifier.weight(1f).fillMaxSize()) {
                                AnimatedContent(
                                    targetState = tab,
                                    transitionSpec = {
                                        (fadeIn(tween(220)) togetherWith fadeOut(tween(180)))
                                    },
                                    label = "tabs"
                                ) { current ->
                                    when (current) {
                                        NavTab.STRIKE -> DashboardScreen(
                                            viewModel = dashboardVM,
                                            isOverlayOpen = isOverlayOpenState.value,
                                            onOpenFloatingPanel = { toggleFloatingPanel() },
                                            onStartCapture = { requestVpnPermission() },
                                            onStopCapture = { stopVpnService() },
                                            licenseExpiresAt = AuthManager.getExpiresAt(this@MainActivity)
                                        )
                                        NavTab.HISTORY -> HistoryScreen()
                                        NavTab.VAULT -> VaultScreen(
                                            licenseExpiresAt = AuthManager.getExpiresAt(this@MainActivity),
                                            onLogout = {
                                                AuthManager.clearAll(this@MainActivity)
                                                stage = Stage.LICENSE
                                            }
                                        )
                                        NavTab.NEXUS -> NexusScreen()
                                    }
                                }
                            }

                            // Connection error banner pinned above bottom nav
                            AnimatedVisibility(connError != null) {
                                ConnectionErrorBanner(connError.orEmpty()) {
                                    ApiSender.clearConnectionError()
                                }
                            }

                            EclipseBottomNav(
                                selected = tab,
                                onSelect = { tab = it }
                            )
                        }
                    }

                    // Welcome dialog (once per session) on dashboard
                    if (stage == Stage.DASHBOARD && showWelcome) {
                        val licExpiry = AuthManager.getExpiresAt(this@MainActivity)
                        WelcomeDialog(
                            expiresAt = licExpiry,
                            onTelegram = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/soulcrack"))
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(this@MainActivity, "Could not open link", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onDismiss = { showWelcome = false }
                        )
                    }
                }
            }
        }
    }

    private fun canDrawOverlays(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun toggleFloatingPanel() {
        if (ApiSender.slotBusy.value) {
            Toast.makeText(this, "Cooldown active — wait until it ends", Toast.LENGTH_SHORT).show()
            return
        }
        if (isOverlayOpenState.value) {
            val i = Intent(this, OverlayService::class.java).apply { action = OverlayService.ACTION_HIDE }
            startService(i)
            isOverlayOpenState.value = false
            return
        }
        if (!canDrawOverlays()) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlayPermissionLauncher.launch(intent)
            return
        }
        launchOverlayAndHome()
    }

    private fun launchOverlayAndHome() {
        val i = Intent(this, OverlayService::class.java)
        startForegroundService(i)
        isOverlayOpenState.value = true
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME); flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
    }

    private fun requestVpnPermission() {
        try {
            val intent = VpnService.prepare(this)
            if (intent != null) vpnPermissionLauncher.launch(intent) else startVpnService()
        } catch (e: Exception) {
            Toast.makeText(this, "VPN error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, VpnCaptureService::class.java).apply { action = "START" }
        startForegroundService(intent)
        dashboardVM.startCapture()
    }

    private fun stopVpnService() {
        val intent = Intent(this, VpnCaptureService::class.java).apply { action = "STOP" }
        startService(intent)
        dashboardVM.stopCapture()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(autoClearReceiver) } catch (_: Exception) {}
    }
}

@Composable
private fun ConnectionErrorBanner(message: String, onDismiss: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(EclipseCoral.copy(0.18f))
            .border(1.dp, EclipseCoral.copy(0.55f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "⚠  CONNECTION: Check network or certificate error in logs",
            color = EclipseCoral,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp,
            modifier = Modifier.weight(1f, fill = false)
        )
        Box(
            Modifier
                .padding(start = 10.dp)
                .background(EclipseCoral.copy(0.10f), RoundedCornerShape(8.dp))
                .border(1.dp, EclipseCoral.copy(0.5f), RoundedCornerShape(8.dp))
                .clickable { onDismiss() }
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                "DISMISS",
                color = EclipseCoral,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
fun WelcomeDialog(
    expiresAt: String?,
    onTelegram: () -> Unit,
    onDismiss: () -> Unit
) {
    val daysLeft = remember(expiresAt) {
        expiresAt?.runCatching {
            val s = take(19).replace("T", " ")
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
            sdf.timeZone = java.util.TimeZone.getTimeZone("UTC")
            val exp = sdf.parse(s) ?: return@runCatching null
            ((exp.time - System.currentTimeMillis()) / 86_400_000L).toInt()
        }?.getOrNull()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .clickable(enabled = false) { /* swallow taps on backdrop */ },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .fillMaxWidth(0.88f)
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF0d0d15), Color(0xFF050508))),
                    RoundedCornerShape(16.dp)
                )
                .border(1.dp, EclipseCoral.copy(0.5f), RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {

                // Title
                Text(
                    "⚔ SoulCrack",
                    color = EclipseCoral,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                )

                // Owner
                Text(
                    "tg - @soulcrack  ·  https://t.me/soulcrack",
                    color = EclipseTextMid,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )

                Divider(color = EclipseCoral.copy(0.2f), thickness = 1.dp)

                // Key expiry
                val expiryColor = when {
                    daysLeft == null -> EclipseTextMid
                    daysLeft <= 0 -> EclipseCoral
                    daysLeft <= 3 -> EclipseAmber
                    else -> EclipseOk
                }
                val expiryText = when {
                    daysLeft == null -> "EXPIRY: UNKNOWN"
                    daysLeft <= 0 -> "⚠ KEY EXPIRED"
                    daysLeft <= 3 -> "⚠ KEY EXPIRES IN $daysLeft DAY${if (daysLeft == 1) "" else "S"}"
                    else -> "KEY VALID · $daysLeft DAYS REMAINING"
                }
                Text(
                    expiryText,
                    color = expiryColor,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )

                // Telegram join
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF229ED9).copy(0.12f), RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFF229ED9).copy(0.5f), RoundedCornerShape(10.dp))
                        .clickable { onTelegram() }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "JOIN CHANNEL  →  t.me/soulcrack",
                        color = Color(0xFF229ED9),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                }

                // Buttons
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Close
                    Box(
                        Modifier
                            .weight(1f)
                            .height(44.dp)
                            .background(EclipseCoral.copy(0.08f), RoundedCornerShape(10.dp))
                            .border(1.dp, EclipseCoral.copy(0.4f), RoundedCornerShape(10.dp))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("CLOSE", color = EclipseCoral, fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp)
                    }
                    // OK
                    Box(
                        Modifier
                            .weight(1f)
                            .height(44.dp)
                            .background(EclipseTeal.copy(0.12f), RoundedCornerShape(10.dp))
                            .border(1.dp, EclipseTeal.copy(0.5f), RoundedCornerShape(10.dp))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("OK", color = EclipseTeal, fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp)
                    }
                }
            }
        }
    }
}
