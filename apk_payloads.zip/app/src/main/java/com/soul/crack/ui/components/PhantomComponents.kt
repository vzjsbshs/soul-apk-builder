package com.soul.crack.ui.components

/* ====================================================================
 *  PHANTOM BLADE — DEPTH / FX COMPONENT LIBRARY
 *  All shared 3D, particle, scanline, energy & pulse helpers used across
 *  DashboardScreen + LicenseScreen + Overlay.  No external assets.
 * ==================================================================== */

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.soul.crack.ui.theme.IceBlue
import com.soul.crack.ui.theme.PlasmaKatana
import kotlin.math.cos
import kotlin.math.sin

/**
 * pulseAlpha — single shared infinite-pulse alpha value.
 * Used everywhere a soft breath / glow is required.
 */
@Composable
fun pulseAlpha(min: Float = 0.4f, max: Float = 1f, durationMs: Int = 800): Float {
    val t = rememberInfiniteTransition(label = "pa$durationMs")
    return t.animateFloat(
        min, max,
        infiniteRepeatable(tween(durationMs), RepeatMode.Reverse),
        label = "pav"
    ).value
}

/**
 * ScanlineBackground — full-screen subtle horizontal scanlines + a
 * diagonal cross-hatch overlay.  Drop on every screen as the very
 * first child of the root Box.
 */
@Composable
fun ScanlineBackground(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        // Horizontal scanlines (every 3px)
        var y = 0f
        while (y < size.height) {
            drawRect(
                color = Color.White.copy(alpha = 0.020f),
                topLeft = Offset(0f, y),
                size = androidx.compose.ui.geometry.Size(size.width, 1f)
            )
            y += 3f
        }
        // Diagonal cross-hatch (two opposing diagonals every 24px)
        val step = 24f
        var d = -size.height
        while (d < size.width) {
            drawLine(
                color = Color.White.copy(alpha = 0.010f),
                start = Offset(d, 0f),
                end   = Offset(d + size.height, size.height),
                strokeWidth = 0.7f
            )
            drawLine(
                color = Color.White.copy(alpha = 0.010f),
                start = Offset(d, size.height),
                end   = Offset(d + size.height, 0f),
                strokeWidth = 0.7f
            )
            d += step
        }
    }
}

/**
 * Layered radial glow — red top-right + cyan bottom-left.
 * Adds atmospheric depth without overwhelming dark content.
 */
@Composable
fun LayeredRadialGlow(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(PlasmaKatana.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(Float.POSITIVE_INFINITY, 0f),
                    radius = 900f
                )
            )
            .background(
                Brush.radialGradient(
                    colors = listOf(IceBlue.copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(0f, Float.POSITIVE_INFINITY),
                    radius = 700f
                )
            )
    )
}

/**
 * EnergyPulse — radiating concentric rings that fade outward.
 * Place on top of any active button (capturing / firing) by
 * stacking in the same Box.
 */
@Composable
fun EnergyPulse(
    color: Color,
    modifier: Modifier = Modifier,
    ringCount: Int = 3,
    durationMs: Int = 1600
) {
    val inf = rememberInfiniteTransition(label = "ep")
    val phase by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(durationMs, easing = LinearEasing)),
        label = "epp"
    )
    Canvas(modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val maxR = kotlin.math.min(size.width, size.height) * 0.6f
        for (i in 0 until ringCount) {
            val p = ((phase + i / ringCount.toFloat()) % 1f)
            val radius = p * maxR + 4f
            val alpha = (1f - p) * 0.55f
            drawCircle(
                color = color.copy(alpha = alpha),
                radius = radius,
                center = Offset(cx, cy),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f)
            )
        }
    }
}

/**
 * ParticleStream — left-to-right horizontal particle flow.
 * Plug into any panel that should feel "alive".  Particles wrap
 * around continuously.
 */
@Composable
fun ParticleStream(
    color: Color,
    modifier: Modifier = Modifier,
    particleCount: Int = 18,
    durationMs: Int = 4500
) {
    val seeds = remember(particleCount) {
        List(particleCount) {
            Triple(
                (it.toFloat() / particleCount),                  // x phase
                (kotlin.math.sin(it * 1.317f) + 1f) / 2f,        // y position
                (kotlin.math.cos(it * 0.731f) + 1.2f) * 0.7f     // size factor
            )
        }
    }
    val inf = rememberInfiniteTransition(label = "ps")
    val flow by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(durationMs, easing = LinearEasing)),
        label = "psf"
    )
    Canvas(modifier.fillMaxSize()) {
        seeds.forEach { (xp, yp, sz) ->
            val x = ((xp + flow) % 1f) * size.width
            val y = yp * size.height
            val r = (1.2f + sz * 1.6f)
            val alpha = 0.35f + 0.55f * (sin((xp + flow) * 6.28f).toFloat() * 0.5f + 0.5f)
            drawCircle(
                color = color.copy(alpha = alpha * 0.6f),
                radius = r,
                center = Offset(x, y)
            )
        }
    }
}

/**
 * CrossHatchOverlay — alternative pure cross-hatch pass without scanlines.
 */
@Composable
fun CrossHatchOverlay(modifier: Modifier = Modifier, alpha: Float = 0.012f) {
    Canvas(modifier.fillMaxSize()) {
        val step = 28f
        var d = -size.height
        while (d < size.width) {
            drawLine(
                color = Color.White.copy(alpha = alpha),
                start = Offset(d, 0f),
                end   = Offset(d + size.height, size.height),
                strokeWidth = 0.6f
            )
            drawLine(
                color = Color.White.copy(alpha = alpha),
                start = Offset(d, size.height),
                end   = Offset(d + size.height, 0f),
                strokeWidth = 0.6f
            )
            d += step
        }
    }
}

@Suppress("unused")
private fun unusedRefs() {
    // Keep cos/sin imports used (defensive against ProGuard reordering)
    cos(0.0); sin(0.0)
}

