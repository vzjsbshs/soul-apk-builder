package com.soul.crack.ui.demo

/* ====================================================================
 *  PHANTOM BLADE — DEMO HOME DASHBOARD
 *  Standalone reference screen produced via the free Magic-UI / shadcn-ui
 *  MCP servers (see /mcp.json).  Showcases:
 *    • Dark theme, clean minimal layout
 *    • Home screen dashboard
 *    • Bottom navigation bar
 *    • Floating action button
 *    • Card-based UI components
 *  Self-contained — depends only on theme/Color.kt + components/PhantomComponents.kt
 * ==================================================================== */

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soul.crack.ui.components.EnergyPulse
import com.soul.crack.ui.components.LayeredRadialGlow
import com.soul.crack.ui.components.ParticleStream
import com.soul.crack.ui.components.ScanlineBackground
import com.soul.crack.ui.theme.AnimeEdgeLine
import com.soul.crack.ui.theme.AnimeGlassLight
import com.soul.crack.ui.theme.AnimePanel
import com.soul.crack.ui.theme.AnimeVoid
import com.soul.crack.ui.theme.NeonCyanA
import com.soul.crack.ui.theme.PhantomTxtDim
import com.soul.crack.ui.theme.PhantomTxtPrimary
import com.soul.crack.ui.theme.PhantomTxtSecondary
import com.soul.crack.ui.theme.PlasmaKatana
import com.soul.crack.ui.theme.SakuraPink

private data class DemoCard(val title: String, val value: String, val unit: String, val tint: Color)

private val demoCards = listOf(
    DemoCard("STRIKES",  "1,284", "today",   PlasmaKatana),
    DemoCard("LATENCY",  "12.4",  "ms avg",  NeonCyanA),
    DemoCard("UPTIME",   "99.97", "% week",  SakuraPink),
    DemoCard("SLOTS",    "4 / 8", "active",  Color(0xFFFFC93C))
)

@Composable
fun PhantomHomeDemo() {
    var tab by remember { mutableStateOf(0) }

    Box(
        Modifier
            .fillMaxSize()
            .background(AnimeVoid)
    ) {
        LayeredRadialGlow(Modifier.fillMaxSize())
        ScanlineBackground(Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize()) {
            // Header
            Column(Modifier.padding(20.dp, 18.dp, 20.dp, 8.dp)) {
                Text(
                    "PHANTOM BLADE",
                    color = PhantomTxtPrimary,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                )
                Text(
                    "// home dashboard",
                    color = PhantomTxtDim,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
            }

            // Card grid (2x2)
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        DemoStatCard(demoCards[0], Modifier.weight(1f))
                        DemoStatCard(demoCards[1], Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        DemoStatCard(demoCards[2], Modifier.weight(1f))
                        DemoStatCard(demoCards[3], Modifier.weight(1f))
                    }
                }
                item { DemoActivityCard() }
                item { Spacer(Modifier.height(80.dp)) }
            }

            // Bottom navigation
            DemoBottomNav(tab) { tab = it }
        }

        // Floating Action Button — anchored above bottom nav
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 88.dp)
                .size(64.dp)
        ) {
            EnergyPulse(color = PlasmaKatana, modifier = Modifier.matchParentSize(), durationMs = 1800)
            Box(
                Modifier
                    .size(56.dp)
                    .align(Alignment.Center)
                    .shadow(
                        24.dp, CircleShape,
                        ambientColor = PlasmaKatana.copy(0.7f),
                        spotColor = PlasmaKatana
                    )
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(listOf(PlasmaKatana, SakuraPink))
                    )
                    .clickable { },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "create",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
private fun DemoStatCard(card: DemoCard, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(110.dp)
            .shadow(
                14.dp, RoundedCornerShape(10.dp),
                ambientColor = card.tint.copy(0.3f),
                spotColor = card.tint.copy(0.4f)
            )
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.linearGradient(
                    listOf(AnimePanel, AnimeVoid)
                )
            )
            .border(1.dp, AnimeEdgeLine, RoundedCornerShape(10.dp))
    ) {
        ParticleStream(color = card.tint, modifier = Modifier.matchParentSize(), particleCount = 10, durationMs = 5000)
        Column(Modifier.padding(14.dp)) {
            Text(
                card.title,
                color = PhantomTxtSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                card.value,
                color = card.tint,
                fontSize = 26.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                card.unit,
                color = PhantomTxtDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun DemoActivityCard() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(140.dp)
            .shadow(
                16.dp, RoundedCornerShape(10.dp),
                ambientColor = NeonCyanA.copy(0.3f),
                spotColor = NeonCyanA.copy(0.4f)
            )
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.linearGradient(listOf(AnimePanel, AnimeVoid))
            )
            .border(1.dp, AnimeEdgeLine, RoundedCornerShape(10.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "RECENT ACTIVITY",
                    color = PhantomTxtSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp
                )
                Icon(Icons.Default.Bolt, null, tint = NeonCyanA, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.height(12.dp))
            listOf(
                "10.0.0.42:443 — strike fired" to PlasmaKatana,
                "session resumed" to NeonCyanA,
                "license verified" to SakuraPink
            ).forEach { (label, color) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(6.dp)
                            .background(color, RoundedCornerShape(1.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        label,
                        color = PhantomTxtPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun DemoBottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Triple("HOME",     Icons.Default.Home,     PlasmaKatana),
        Triple("SEARCH",   Icons.Default.Search,   NeonCyanA),
        Triple("PROFILE",  Icons.Default.Person,   SakuraPink),
        Triple("CONFIG",   Icons.Default.Settings, Color(0xFFFFC93C))
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(AnimePanel)
            .border(1.dp, AnimeEdgeLine, RoundedCornerShape(0.dp)),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { idx, item ->
            val active = idx == selected
            BottomTab(item.first, item.second, item.third, active) { onSelect(idx) }
        }
    }
}

@Composable
private fun BottomTab(label: String, icon: ImageVector, tint: Color, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(36.dp)
                .background(
                    if (active) tint.copy(0.12f) else Color.Transparent,
                    RoundedCornerShape(8.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, null,
                tint = if (active) tint else PhantomTxtDim,
                modifier = Modifier.size(22.dp)
            )
        }
        Text(
            label,
            color = if (active) tint else PhantomTxtDim,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
    }
}

@Suppress("unused")
private fun unusedAlphaRef() { AnimeGlassLight }
