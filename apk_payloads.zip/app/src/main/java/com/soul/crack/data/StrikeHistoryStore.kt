package com.soul.crack.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * StrikeHistoryStore — fully offline strike history.
 * Persists every strike (timestamp, mode, duration, ip, port) into
 * SharedPreferences as a rolling JSON list (max 200 entries).
 */
object StrikeHistoryStore {
    private const val PREFS = "eclipse_history"
    private const val KEY = "log"
    private const val MAX = 200

    data class Entry(
        val ts: Long,
        val mode: Int,
        val duration: Int,
        val ip: String,
        val port: Int,
        val status: String
    ) {
        fun prettyTime(): String =
            SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault()).format(Date(ts))
        fun day(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ts))
    }

    suspend fun add(ctx: Context, e: Entry) = withContext(Dispatchers.IO) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]") ?: "[]")
        val obj = JSONObject().apply {
            put("ts", e.ts); put("mode", e.mode); put("duration", e.duration)
            put("ip", e.ip); put("port", e.port); put("status", e.status)
        }
        // newest first
        val merged = JSONArray().apply {
            put(obj)
            for (i in 0 until arr.length().coerceAtMost(MAX - 1)) put(arr.get(i))
        }
        sp.edit().putString(KEY, merged.toString()).apply()
    }

    fun all(ctx: Context): List<Entry> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]") ?: "[]")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Entry(
                ts = o.optLong("ts"),
                mode = o.optInt("mode", 1),
                duration = o.optInt("duration", 0),
                ip = o.optString("ip", "—"),
                port = o.optInt("port", 0),
                status = o.optString("status", "OK")
            )
        }
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    data class Stats(
        val totalStrikes: Int, val totalSeconds: Int,
        val mode1: Int, val mode2: Int,
        val today: Int, val last7: Int
    )

    fun stats(ctx: Context): Stats {
        val list = all(ctx)
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L
        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(now))
        return Stats(
            totalStrikes = list.size,
            totalSeconds = list.sumOf { it.duration },
            mode1 = list.count { it.mode == 1 },
            mode2 = list.count { it.mode == 2 },
            today = list.count { it.day() == todayKey },
            last7 = list.count { now - it.ts <= 7 * dayMs }
        )
    }

    /** 7 buckets, oldest → newest, count of strikes per day. */
    fun last7DaysBuckets(ctx: Context): IntArray {
        val list = all(ctx)
        val out = IntArray(7)
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L
        list.forEach {
            val daysAgo = ((now - it.ts) / dayMs).toInt()
            if (daysAgo in 0..6) out[6 - daysAgo] += 1
        }
        return out
    }
}
