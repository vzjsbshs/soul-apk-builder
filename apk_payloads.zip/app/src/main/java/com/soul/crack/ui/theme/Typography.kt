package com.soul.crack.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/* ====================================================================
 *  NEON ONI FORGE v9 — TYPOGRAPHY
 *  Display : SansSerif Black (HUD headline feel)
 *  Body    : SansSerif Medium / Regular
 *  Mono    : Monospace for codes, timers, kana glyphs
 *  Aggressive letter-spacing for a cinematic, neo-Tokyo HUD cadence.
 * ==================================================================== */

private val DisplayFamily = FontFamily.SansSerif
private val BodyFamily    = FontFamily.SansSerif
private val MonoFamily    = FontFamily.Monospace

val TrafficCaptureTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = DisplayFamily, fontWeight = FontWeight.Black,
        fontSize = 30.sp, letterSpacing = 6.sp, color = AnimeTxtPrimary
    ),
    displayMedium = TextStyle(
        fontFamily = DisplayFamily, fontWeight = FontWeight.ExtraBold,
        fontSize = 22.sp, letterSpacing = 5.sp, color = AnimeTxtPrimary
    ),
    headlineSmall = TextStyle(
        fontFamily = DisplayFamily, fontWeight = FontWeight.Bold,
        fontSize = 17.sp, letterSpacing = 3.sp, color = AnimeTxtPrimary
    ),
    bodyLarge = TextStyle(
        fontFamily = BodyFamily, fontWeight = FontWeight.Medium,
        fontSize = 15.sp, letterSpacing = 0.5.sp, color = AnimeTxtPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = BodyFamily, fontWeight = FontWeight.Normal,
        fontSize = 13.sp, letterSpacing = 0.4.sp, color = AnimeTxtSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = MonoFamily, fontWeight = FontWeight.Medium,
        fontSize = 11.sp, letterSpacing = 1.2.sp, color = AnimeTxtSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = MonoFamily, fontWeight = FontWeight.Black,
        fontSize = 12.sp, letterSpacing = 5.sp, color = NeonCyanA
    )
)
