package com.soul.crack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

/**
 * Model representing a captured network packet
 */
@Entity(tableName = "packets")
data class PacketEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long,
    val protocol: String, // HTTP, HTTPS, DNS, TCP, UDP
    val sourceIp: String,
    val sourcePort: Int,
    val destinationIp: String,
    val destinationPort: Int,
    val hostname: String = "",
    val method: String = "", // For HTTP: GET, POST, etc.
    val path: String = "",
    val statusCode: Int = 0,
    val requestHeaders: String = "", // JSON string
    val requestBody: String = "",
    val responseHeaders: String = "", // JSON string
    val responseBody: String = "",
    val payloadSize: Long = 0,
    val direction: String = "→", // → for outgoing, ← for incoming
    val durationMs: Long = 0,
    val tlsVersion: String = "",
    val tlsCipher: String = "",
    val certificateIssuer: String = "",
    val certificateSubject: String = "",
    val certificateValidFrom: String = "",
    val certificateValidUntil: String = "",
    val hasError: Boolean = false,
    val errorMessage: String = ""
) : Serializable

/**
 * DTO for displaying packet data in UI
 */
data class PacketDto(
    val id: Long,
    val timestamp: Long,
    val protocol: String,
    val source: String, // "192.168.1.100:54321"
    val destination: String, // "api.example.com:443"
    val hostname: String,
    val method: String,
    val path: String,
    val statusCode: Int,
    val payloadSize: Long,
    val direction: String,
    val durationMs: Long,
    val displayText: String // For quick display in list
)

/**
 * Summary statistics for capture session
 */
data class CaptureStats(
    val totalPackets: Int = 0,
    val totalBytes: Long = 0,
    val httpPackets: Int = 0,
    val httpsPackets: Int = 0,
    val dnsPackets: Int = 0,
    val otherPackets: Int = 0,
    val failedPackets: Int = 0,
    val averageLatency: Long = 0,
    val captureDuration: Long = 0
)

/**
 * Export configuration
 */
data class ExportConfig(
    val format: ExportFormat = ExportFormat.TXT,
    val includeHeaders: Boolean = true,
    val includeBody: Boolean = true,
    val includeCertificate: Boolean = true,
    val filterProtocol: String? = null,
    val filterHost: String? = null,
    val timeRange: Pair<Long, Long>? = null
)

enum class ExportFormat {
    TXT, JSON, CSV, PCAP
}

/**
 * Capture mode configuration
 */
enum class CaptureMode {
    AUTO, VPN, ROOT, NONE
}
