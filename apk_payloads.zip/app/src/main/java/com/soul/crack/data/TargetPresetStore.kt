package com.soul.crack.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * TargetPresetStore — fully offline target presets (IP:Port).
 * Lets the user save & one-tap reuse common targets without any
 * network round-trip. Persisted in SharedPreferences as a rolling
 * JSON list (max 24 entries, newest first).
 */
object TargetPresetStore {
    private const val PREFS = "obsidian_presets"
    private const val KEY = "list"
    private const val MAX = 24

    data class Preset(
        val name: String,
        val ip: String,
        val port: Int,
        val ts: Long
    )

    fun all(ctx: Context): List<Preset> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]") ?: "[]")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Preset(
                name = o.optString("name", "preset"),
                ip = o.optString("ip", "—"),
                port = o.optInt("port", 0),
                ts = o.optLong("ts", 0L)
            )
        }
    }

    fun save(ctx: Context, name: String, ip: String, port: Int) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]") ?: "[]")
        // de-dup on (ip, port)
        val merged = JSONArray().apply {
            put(JSONObject().apply {
                put("name", name.ifBlank { "$ip:$port" })
                put("ip", ip); put("port", port)
                put("ts", System.currentTimeMillis())
            })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("ip") == ip && o.optInt("port") == port) continue
                if (length() >= MAX) break
                put(o)
            }
        }
        sp.edit().putString(KEY, merged.toString()).apply()
    }

    fun remove(ctx: Context, ip: String, port: Int) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]") ?: "[]")
        val merged = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("ip") == ip && o.optInt("port") == port) continue
            merged.put(o)
        }
        sp.edit().putString(KEY, merged.toString()).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
