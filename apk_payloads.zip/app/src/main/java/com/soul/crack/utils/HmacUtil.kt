package com.soul.crack.utils

import android.util.Log
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * HMAC-SHA256 Signature Generator for Panel API v4
 * 
 * Generates cryptographic signatures to prevent key stealing attacks.
 * Required for: /api/keys/verify, /api/slot/status, /api/cooldown/status
 * 
 * Algorithm: signature = HMAC-SHA256("{key}|{device_id}", HMAC_SECRET)
 * Output: 64-character hex string
 */
object HmacUtil {
    private const val TAG = "HmacUtil"
    
    // CRITICAL: This must match HMAC_SECRET in panel .env
    private const val HMAC_SECRET = "f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1"

    /**
     * Generate HMAC-SHA256 signature for API requests
     * @param key License key value
     * @param deviceId Device ID (32-char hex UUID without dashes)
     * @return Hex-encoded signature (64 chars) or empty string on error
     */
    fun generateSignature(key: String, deviceId: String): String {
        return try {
            val mac = Mac.getInstance("HmacSHA256")
            val secretKey = SecretKeySpec(HMAC_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256")
            mac.init(secretKey)

            // Format: "{key}|{device_id}"
            val data = "$key|$deviceId"
            val signature = mac.doFinal(data.toByteArray(Charsets.UTF_8))

            // Convert to hex string (64 characters)
            val hexSignature = signature.joinToString("") { "%02x".format(it) }
            
            if (Log.isLoggable(TAG, Log.DEBUG)) {
                Log.d(TAG, "Generated signature for data length: ${data.length}")
            }
            
            hexSignature
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate signature: ${e.message}", e)
            ""
        }
    }

    /**
     * Generate signature for endpoints that don't use a real key
     * (e.g., slot status check before having a valid key)
     * @param endpoint Endpoint identifier (e.g., "SLOT_STATUS", "COOLDOWN")
     * @param deviceId Device ID or dummy ID (32 zeros if no device ID yet)
     * @return Hex-encoded signature
     */
    fun generateDummySignature(endpoint: String, deviceId: String = "00000000000000000000000000000000"): String {
        return generateSignature(endpoint, deviceId)
    }
}
