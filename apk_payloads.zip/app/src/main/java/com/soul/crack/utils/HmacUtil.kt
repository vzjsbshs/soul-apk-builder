package com.soul.crack.utils

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object HmacUtil {
    fun generateSignature(key: String, deviceId: String): String {
        val data = "$key:$deviceId"
        val secret = "295af957aad5514dd9772cd30ebe75391fd90401939e653a0e3f2fe3a2f28065"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}