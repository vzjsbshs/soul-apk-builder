package com.soul.crack.service

import android.content.Context
import android.util.Log
import com.soul.crack.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Network gateway to the licensing panel.
 * - Base URL is XOR-decoded at runtime (BuildConfig.BASE_URL_XOR / BASE_URL_KEY).
 * - TLS is pinned via OkHttp CertificatePinner.
 * - Verify request includes HMAC-SHA256 signature header X-Request-Sig.
 */
object PanelApi {
    val BASE_URL: String by lazy { decodeBaseUrl() }
    private const val HOST = "soul-ddos-domain.shop"

    private fun decodeBaseUrl(): String {
        val enc = BuildConfig.BASE_URL_XOR
        val key = BuildConfig.BASE_URL_KEY.toInt().toByte()
        val bytes = ByteArray(enc.length / 2) {
            ((Character.digit(enc[it * 2], 16) shl 4) + Character.digit(enc[it * 2 + 1], 16)).toByte()
        }
        return SecurityManager.xorDecode(bytes, key)
    }

    private val client: OkHttpClient by lazy {
        val pinner = CertificatePinner.Builder()
            .add(HOST, BuildConfig.CERT_PIN_PRIMARY)
            .apply {
                if (BuildConfig.CERT_PIN_BACKUP.isNotEmpty()) add(HOST, BuildConfig.CERT_PIN_BACKUP)
            }
            .build()
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .certificatePinner(pinner)
            .build()
    }

    data class Result(val ok: Boolean, val code: Int, val body: JSONObject?)

    suspend fun get(path: String, headers: Map<String, String> = emptyMap()): Result =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url("$BASE_URL$path")
                .get()
                .apply { headers.forEach { (k, v) -> addHeader(k, v) } }
                .build()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                val obj = runCatching { JSONObject(text) }.getOrNull()
                Result(resp.isSuccessful, resp.code, obj)
            }
        }
}

data class LicenseResult(
    val valid: Boolean,
    val reason: String? = null,
    val expiresAt: String? = null,
    val usedOfflineGrace: Boolean = false
)

object LicenseChecker {

    private const val OFFLINE_GRACE_MS = 24L * 60 * 60 * 1000 // 24h

    suspend fun verifyLicense(context: Context, licenseKey: String): LicenseResult {
        val deviceId = AuthManager.getDeviceId(context)
        val keyEnc = URLEncoder.encode(licenseKey, "UTF-8")
        val devEnc = URLEncoder.encode(deviceId, "UTF-8")
        val path = "/api/keys/verify?key=$keyEnc&device_id=$devEnc"

        // HMAC over "<key>|<device_id>"
        val sig = SecurityManager.hmacSha256Hex(BuildConfig.HMAC_SECRET, "$licenseKey|$deviceId")
        val headers = mapOf("X-Request-Sig" to sig, "X-Device-Id" to deviceId)

        val r = try {
            PanelApi.get(path, headers)
        } catch (e: Exception) {
            Log.e("SOULNET", "verify failed: ${e.javaClass.simpleName}: ${e.message}", e)
            return offlineGrace(context, licenseKey, "${e.javaClass.simpleName}: ${e.message ?: ""}")
        }

        Log.e("SOULNET", "verify resp code=${r.code} body=${r.body}")
        if (r.body == null) return offlineGrace(context, licenseKey, "empty_body_http_${r.code}")

        val valid = r.body.optBoolean("valid", false)
        val reason = r.body.optString("reason", "").takeIf { it.isNotEmpty() && it != "null" }
        val expiresAt = r.body.optString("expires_at", "").takeIf { it.isNotEmpty() && it != "null" }

        if (valid) {
            AuthManager.touchVerified(context, expiresAt)
            return LicenseResult(true, null, expiresAt)
        }
        return LicenseResult(false, reason, expiresAt)
    }

    private fun offlineGrace(context: Context, licenseKey: String, detail: String? = null): LicenseResult {
        val saved = AuthManager.getLicense(context)
        val lastVerify = AuthManager.getLastVerify(context)
        val expiresAt = AuthManager.getExpiresAt(context)
        val within = System.currentTimeMillis() - lastVerify < OFFLINE_GRACE_MS
        return if (saved == licenseKey && lastVerify > 0 && within) {
            LicenseResult(true, null, expiresAt, usedOfflineGrace = true)
        } else {
            // Surface the real cause to the UI so user can see why it failed.
            val reason = if (!detail.isNullOrBlank()) "net:$detail" else "network_error"
            LicenseResult(false, reason, expiresAt)
        }
    }
}
