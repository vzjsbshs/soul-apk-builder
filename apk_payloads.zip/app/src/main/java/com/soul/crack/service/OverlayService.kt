package com.soul.crack.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.soul.crack.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var collapsedView: View? = null
    private var screenInfoView: View? = null

    private var executeBtn: Button? = null
    private var executeBg: GradientDrawable? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var refreshRunnable: Runnable? = null

    private val scope = CoroutineScope(Dispatchers.Main)
    private var slotObserverJob: Job? = null
    private var apiSuccessJob: Job? = null

    private var savedExpandedX: Int = -1
    private var savedExpandedY: Int = -1

    // Live data TextViews
    private var tvIp: TextView? = null
    private var tvPort: TextView? = null
    private var tvTime: TextView? = null
    private var tvCd: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            removeAllOverlays()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (overlayView == null) {
            showGamingOverlay()
            showFloatingControls()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "overlay_window"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "SoulCrack Gaming Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notif: Notification = Notification.Builder(this, channelId)
            .setContentTitle("SoulCrack v11 Gaming")
            .setContentText("Gaming overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun getScreenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    // ════════════════════════════════════════════════════════════════
    // GAMING STYLE OVERLAY - Clean, minimal, transparent
    // ════════════════════════════════════════════════════════════════
    private fun showGamingOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        // Main container - horizontal layout
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
            setBackgroundColor(0x40000000) // Slightly transparent black
        }

        // IP
        tvIp = createGamingText().apply { 
            text = "—"
            setTextColor(0xFFFFFFFF.toInt())
        }
        container.addView(tvIp)
        container.addView(createSeparator())

        // PORT
        tvPort = createGamingText().apply { 
            text = "—"
            setTextColor(0xFFFFD96A.toInt()) // Yellow/amber
        }
        container.addView(tvPort)
        container.addView(createSeparator())

        // TIME
        tvTime = createGamingText().apply { 
            text = "—"
            setTextColor(0xFF00FF9F.toInt()) // Green
        }
        container.addView(tvTime)
        container.addView(createSeparator())

        // CD (Cooldown)
        tvCd = createGamingText().apply { 
            text = "—"
            setTextColor(0xFF00E5FF.toInt()) // Cyan
        }
        container.addView(tvCd)

        // TG handle
        container.addView(createSeparator())
        container.addView(TextView(this).apply {
            text = "tg-@soulcrack"
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xAA00E5FF.toInt())
            setPadding(dp(4), 0, dp(4), 0)
        })

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        // Top-right position (like gaming overlays)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(40)
        }

        try {
            wm.addView(container, params)
            screenInfoView = container
        } catch (_: Exception) { stopSelf(); return }

        startObserversAndRefresh()
        tryLaunchPubg()
    }

    private fun createGamingText(): TextView {
        return TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), 0, dp(4), 0)
            setShadowLayer(2f, 1f, 1f, Color.BLACK) // Text shadow for visibility
        }
    }

    private fun createSeparator(): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(16)).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            setBackgroundColor(0x66FFFFFF)
        }
    }

    // ════════════════════════════════════════════════════════════════
    // FLOATING CONTROLS - Same as before
    // ════════════════════════════════════════════════════════════════
    private fun showFloatingControls() {
        val wm = windowManager ?: return
        val (screenW, screenH) = getScreenSize()
        val windowW = dp(200)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                colors = intArrayOf(0xF2050308.toInt(), 0xF20F0A18.toInt())
                orientation = GradientDrawable.Orientation.TOP_BOTTOM
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0xCC00E5FF.toInt())
            }
            elevation = dp(16).toFloat()
        }

        // Drag pill
        root.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(3)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(8)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(2).toFloat()
                setColor(0x5500E5FF)
            }
        })

        // Title
        root.addView(TextView(this).apply {
            text = "CONTROLS"
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00E5FF.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        })

        // Button rows
        val btnRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6) }
        }
        
        val (exBtn, exBg) = createButton("EXECUTE", 0xFFFF0844.toInt(),
            intArrayOf(0x33FF0844, 0x10FF0844), 0xFFFF0844.toInt()) {
            startService(Intent(this, VpnCaptureService::class.java).apply { action = "START" })
        }
        executeBtn = exBtn; executeBg = exBg
        
        val (abBtn, _) = createButton("ABORT", 0xFFFFD96A.toInt(),
            intArrayOf(0x33FFB800, 0x10FFB800), 0xFFFFB800.toInt()) {
            startService(Intent(this, VpnCaptureService::class.java).apply { action = "STOP" })
        }
        
        btnRow1.addView(exBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnRow1.addView(spacer(5))
        btnRow1.addView(abBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val btnRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        val (minBtn, _) = createButton("MIN", 0xFF00E5FF.toInt(),
            intArrayOf(0x2400E5FF, 0x0A00E5FF), 0xCC00E5FF.toInt()) { collapseToIcon() }
        
        val (closeBtn, _) = createButton("CLOSE", 0xFFD600FF.toInt(),
            intArrayOf(0x24D600FF, 0x0AD600FF), 0xCCD600FF.toInt()) {
            startService(Intent(this, OverlayService::class.java).apply { action = ACTION_HIDE })
        }
        
        btnRow2.addView(minBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnRow2.addView(spacer(5))
        btnRow2.addView(closeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        root.addView(btnRow1)
        root.addView(btnRow2)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            windowW,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END // Bottom-right position
            x = dp(16)
            y = dp(100)
        }

        // Drag support
        root.setOnTouchListener(object : View.OnTouchListener {
            var initX = 0; var initY = 0
            var touchX = 0f; var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = e.rawX; touchY = e.rawY; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val newX = initX - (e.rawX - touchX).toInt()
                        val newY = initY - (e.rawY - touchY).toInt()
                        params.x = newX.coerceIn(0, screenW - windowW)
                        params.y = newY.coerceIn(0, screenH - dp(200))
                        try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(root, params)
            overlayView = root
        } catch (_: Exception) { stopSelf() }
    }

    private fun startObserversAndRefresh() {
        slotObserverJob = scope.launch {
            ApiSender.slotBusy.collectLatest { busy -> setExecuteEnabled(!busy) }
        }
        apiSuccessJob = scope.launch {
            ApiSender.apiCallSuccess.collectLatest { success ->
                if (success) {
                    ApiSender.resetApiCallSuccess()
                    startService(Intent(this@OverlayService, VpnCaptureService::class.java).apply { action = "STOP" })
                    sendBroadcast(Intent("com.soul.crack.AUTO_CLEAR_DATA"))
                }
            }
        }

        refreshRunnable?.let { mainHandler.removeCallbacks(it) }
        val refresh = object : Runnable {
            override fun run() {
                val ip   = ApiSender.lastFiredIp.value.ifEmpty { "—" }
                val port = ApiSender.lastFiredPort.value.let { if (it == 0) "—" else it.toString() }
                val time = ApiSender.lastFiredTime.value.ifEmpty { "—" }
                val cd   = ApiSender.cooldownSeconds.value

                tvIp?.text   = ip
                tvPort?.text = port
                tvTime?.text = time
                
                if (cd > 0) {
                    tvCd?.text = "${cd}s"
                    tvCd?.setTextColor(0xFFFF0844.toInt()) // Red when cooling down
                } else {
                    tvCd?.text = "READY"
                    tvCd?.setTextColor(0xFF00FF9F.toInt()) // Green when ready
                }

                setExecuteEnabled(!ApiSender.slotBusy.value && cd == 0)
                mainHandler.postDelayed(this, 1500)
            }
        }
        refreshRunnable = refresh
        mainHandler.post(refresh)
    }

    private fun setExecuteEnabled(enabled: Boolean) {
        if (enabled) {
            executeBg?.colors = intArrayOf(0x33FF0844, 0x10FF0844)
            executeBtn?.setTextColor(0xFFFF0844.toInt())
            executeBtn?.alpha = 1.0f
            executeBtn?.isEnabled = true
        } else {
            executeBg?.colors = intArrayOf(0xFF0F0A14.toInt(), 0xFF050308.toInt())
            executeBtn?.setTextColor(0xFF6A6F8A.toInt())
            executeBtn?.alpha = 0.5f
            executeBtn?.isEnabled = false
        }
    }

    private fun createButton(
        label: String,
        textColor: Int,
        bgColors: IntArray,
        strokeColor: Int,
        onClick: () -> Unit
    ): Pair<Button, GradientDrawable> {
        val gd = GradientDrawable().apply {
            colors = bgColors
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            cornerRadius = dp(6).toFloat()
            setStroke(dp(1), strokeColor)
        }
        val btn = Button(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            isAllCaps = true
            stateListAnimator = null
            letterSpacing = 0.12f
            setPadding(dp(4), dp(10), dp(4), dp(10))
            background = gd
            setOnClickListener { onClick() }
        }
        return btn to gd
    }

    private fun spacer(w: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(w), 1)
    }

    private fun tryLaunchPubg() {
        try {
            val intent = packageManager.getLaunchIntentForPackage("com.pubg.imobile")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        } catch (_: Exception) {}
    }

    private fun collapseToIcon() {
        val wm = windowManager ?: return
        try {
            val lp = overlayView?.layoutParams as? WindowManager.LayoutParams
            if (lp != null) { savedExpandedX = lp.x; savedExpandedY = lp.y }
        } catch (_: Exception) {}
        try { overlayView?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlayView = null

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xF2050308.toInt())
            setStroke(dp(2), 0xFF00E5FF.toInt())
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.daemon_logo)
            background = ring
            setPadding(dp(5), dp(5), dp(5), dp(5))
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            scaleType = ImageView.ScaleType.CENTER_CROP
            isClickable = true
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val (screenW, screenH) = getScreenSize()
        val params = WindowManager.LayoutParams(
            dp(52), dp(52), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (if (savedExpandedX >= 0) savedExpandedX else dp(16)).coerceIn(0, screenW - dp(52))
            y = (if (savedExpandedY >= 0) savedExpandedY else dp(100)).coerceIn(0, screenH - dp(52))
        }

        icon.setOnTouchListener(object : View.OnTouchListener {
            var initX = 0; var initY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = -(e.rawX - touchX).toInt()
                        val dy = -(e.rawY - touchY).toInt()
                        if (kotlin.math.abs(dx) > dp(6) || kotlin.math.abs(dy) > dp(6)) moved = true
                        params.x = (initX + dx).coerceIn(0, screenW - dp(52))
                        params.y = (initY + dy).coerceIn(0, screenH - dp(52))
                        try { wm.updateViewLayout(v, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        savedExpandedX = params.x; savedExpandedY = params.y
                        if (!moved) expandFromIcon()
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(icon, params); collapsedView = icon
        } catch (_: Exception) { stopSelf() }
    }

    private fun expandFromIcon() {
        try { collapsedView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        collapsedView = null
        showFloatingControls()
        try {
            val lp = overlayView?.layoutParams as? WindowManager.LayoutParams
            if (lp != null && savedExpandedX >= 0 && savedExpandedY >= 0) {
                lp.x = savedExpandedX; lp.y = savedExpandedY
                windowManager?.updateViewLayout(overlayView, lp)
            }
        } catch (_: Exception) {}
    }

    private fun removeAllOverlays() {
        slotObserverJob?.cancel(); slotObserverJob = null
        apiSuccessJob?.cancel(); apiSuccessJob = null
        refreshRunnable?.let { mainHandler.removeCallbacks(it) }
        refreshRunnable = null
        
        try { overlayView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        overlayView = null
        try { collapsedView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        collapsedView = null
        try { screenInfoView?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        screenInfoView = null
        
        tvIp = null; tvPort = null; tvTime = null; tvCd = null
        executeBtn = null; executeBg = null
    }

    override fun onDestroy() {
        removeAllOverlays()
        super.onDestroy()
    }

    companion object {
        const val ACTION_HIDE = "HIDE"
        private const val NOTIF_ID = 7711
    }
}
