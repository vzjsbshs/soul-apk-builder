package com.soul.crack.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/* ====================================================================
 *  ANIME FORGE v6 — Neo-Tokyo Mech Theme
 *  Dark-only, plasma katana primary, sakura secondary, neon cyan info.
 * ==================================================================== */

private val AnimeForgeScheme = darkColorScheme(
    primary          = PlasmaKatana,        // primary actions
    onPrimary        = AnimeTxtPrimary,
    secondary        = SakuraPink,          // secondary highlights
    onSecondary      = AnimeMidnight,
    tertiary         = NeonCyanA,           // info / license
    onTertiary       = AnimeMidnight,
    background       = AnimeVoid,
    onBackground     = AnimeTxtPrimary,
    surface          = AnimePanel,
    onSurface        = AnimeTxtPrimary,
    surfaceVariant   = AnimeElevated,
    onSurfaceVariant = AnimeTxtSecondary,
    error            = AnimeRed,
    onError          = AnimeTxtPrimary,
    outline          = AnimeEdgeLine,
    outlineVariant   = Color(0x14FFFFFF)
)

@Composable
fun TrafficCaptureTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AnimeForgeScheme,
        typography  = TrafficCaptureTypography,
        content     = content
    )
}
