package com.soul.crack.service

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Utility to check if device is rooted and execute root commands
 */
class RootChecker(private val context: Context) {

    suspend fun isDeviceRooted(): Boolean = withContext(Dispatchers.IO) {
        return@withContext checkRootAvailability()
    }

    private fun checkRootAvailability(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val line = reader.readLine()
            process.waitFor()
            
            reader.close()
            line != null && line.contains("uid=0")
        } catch (e: Exception) {
            Log.d("RootChecker", "Device is not rooted: ${e.message}")
            false
        }
    }

    suspend fun executeRootCommand(command: String): String = withContext(Dispatchers.IO) {
        return@withContext try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            reader.close()
            output
        } catch (e: Exception) {
            Log.e("RootChecker", "Error executing root command", e)
            ""
        }
    }

    suspend fun installTcpdump(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val tcpdumpPath = "/system/bin/tcpdump"
            val checkProcess = Runtime.getRuntime().exec(arrayOf("su", "-c", "test -f $tcpdumpPath && echo 1"))
            val result = BufferedReader(InputStreamReader(checkProcess.inputStream)).readText()
            checkProcess.waitFor()
            
            result.contains("1")
        } catch (e: Exception) {
            Log.e("RootChecker", "Error installing tcpdump", e)
            false
        }
    }
}
