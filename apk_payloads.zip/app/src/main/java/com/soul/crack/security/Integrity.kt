package com.soul.crack.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.soul.crack.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.security.MessageDigest
import kotlin.system.exitProcess

object Integrity {
    private const val TAG = "Integrity"
    
    suspend fun check(context: Context) = withContext(Dispatchers.IO) {
        try {
            var failed = false
            
            // FIXED: Now uses BuildConfig.EXPECTED_SIGNATURE_SHA256 for consistency
            if (!checkSignatureAgainstExpected(context)) {
                Log.e(TAG, "Signature mismatch against expected fingerprint")
                failed = true
            }
            
            if (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0) {
                Log.e(TAG, "App is debuggable")
                failed = true
            }
            
            // FIXED: Use strict root check (without test-keys)
            if (isRootedStrict()) {
                Log.e(TAG, "Device is rooted")
                failed = true
            }
            
            // FIXED: Use boundary-aware Frida check
            if (isFridaPresentSafe()) {
                Log.e(TAG, "Frida/hooking framework detected")
                failed = true
            }
            
            if (isEmulatorStrict()) {
                Log.e(TAG, "Running on emulator")
            }
            
            if (failed) {
                reportTamper(context)
                delay((1000..5000).random().toLong())
                // FIXED: Use non-zero exit code for tamper detection
                exitProcess(10)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Integrity check error", e)
        }
    }
    
    // FIXED: Now compares against BuildConfig.EXPECTED_SIGNATURE_SHA256
    private fun checkSignatureAgainstExpected(context: Context): Boolean {
        return try {
            val expectedSig = BuildConfig.EXPECTED_SIGNATURE_SHA256
            if (expectedSig.isEmpty()) return true  // Skip if not configured
            
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
            }
            
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners ?: arrayOf()
            } else {
                @Suppress("DEPRECATION")
                info.signatures ?: arrayOf()
            }
            
            if (signatures.isEmpty()) return false
            
            // Compute actual fingerprint
            val first = signatures.firstOrNull() ?: return false
            val md = MessageDigest.getInstance("SHA-256")
            md.update(first.toByteArray())
            val actualSig = md.digest().joinToString(":") { "%02X".format(it) }
            
            // Compare
            actualSig.equals(expectedSig, ignoreCase = true)
        } catch (e: Exception) {
            Log.e(TAG, "Signature check failed", e)
            false
        }
    }
    
    // FIXED: Strict root check without test-keys
    private fun isRootedStrict(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        return paths.any { File(it).exists() } || 
               try {
                   Runtime.getRuntime().exec(arrayOf("which", "su"))
                       .inputStream.bufferedReader().readLine() != null
               } catch (_: Throwable) {
                   false
               }
    }
    
    // FIXED: Boundary-aware Frida detection
    private fun isFridaPresentSafe(): Boolean {
        return try {
            val maps = File("/proc/self/maps")
            if (!maps.exists()) return false
            
            BufferedReader(FileReader(maps)).use { reader ->
                reader.lineSequence().any { line ->
                    line.contains(Regex("\\bfrida\\b", RegexOption.IGNORE_CASE)) ||
                    line.contains(Regex("\\bxposed\\b", RegexOption.IGNORE_CASE)) ||
                    line.contains(Regex("\\bgadget\\b", RegexOption.IGNORE_CASE)) ||
                    line.contains(Regex("\\bgum-js\\b", RegexOption.IGNORE_CASE)) ||
                    line.contains(Regex("\\blinjector\\b", RegexOption.IGNORE_CASE))
                }
            }
        } catch (e: Exception) {
            false
        }
    }
    
    // FIXED: Tightened emulator detection
    private fun isEmulatorStrict(): Boolean {
        return Build.FINGERPRINT.startsWith("generic") ||
               Build.FINGERPRINT.contains("vbox") ||
               Build.MODEL.contains("Emulator") ||
               Build.MODEL.contains("Android SDK") ||
               Build.MANUFACTURER.contains("Genymotion") ||
               (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
    }
    
    // TODO: This should POST to /api/x with tamper report + device hash
    private suspend fun reportTamper(context: Context) {
        Log.w(TAG, "Tamper detected, exiting")
        // Future: Send tamper report to server via encrypted endpoint
    }
}
